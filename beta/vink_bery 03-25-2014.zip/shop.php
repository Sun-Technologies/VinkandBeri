<!DOCTYPE html>
<html>
<head>
  <title>Shop \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <style>
	#top-box,
	.carousel-box .next:hover,
	.carousel-box .prev:hover,
	.product .product-hover,
	#footer .up:hover,
    .btn,
    .btn:visited,
    .slider .slider-nav,
    .active .accordion-heading .accordion-toggle,
    .banner-set .pagination a:hover,
    .employee .employee-hover,
    .carousel-box .pagination a:hover,
    .sidebar .menu li.active > a,
    .pagination ul > li > a:hover,
    .sidebar .tags a:hover,
    .sidebar .banners .banner-text,
    #catalog .category-img .description,
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrapper,
    .product-bottom .related-products header:before,
    #slider.rs-slider .tparrows:hover,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .toolbar .grid-list a.grid:hover,
    .toolbar .grid-list a.list:hover,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a,
    .sidebar .menu li.parent > a .open-sub:before,
    .sidebar .menu li.parent > a .open-sub:after,
    .accordion-heading .accordion-toggle:before,
    .accordion-heading .accordion-toggle:after,
    .new-radio.checked span,
	.list .product .actions a:hover,
	.product-page .span7 .actions a:hover,
	.product-page .image-box .thumblist-box .prev:hover,
	.product-page .image-box .thumblist-box .next:hover,
    .btn.btn-inverse:hover,
    .btn.btn-inverse:focus,
    .btn.btn-inverse:active,
    .btn.btn-inverse.active,
    .btn.btn-inverse.disabled,
    .btn.btn-inverse[disabled],
	.accordion-tab > li > a .open-sub:before,
	.accordion-tab > li > a .open-sub:after,
	.products-tab .accordion-tab > li > a .open-sub:before,
	.products-tab .accordion-tab > li > a .open-sub:after {
	  background-color: #40499b;
	}
    .slider .slider-nav {
      background-color: rgba(64,73,155,.97);
    }
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrappe,
	.product .product-hover,
	.rotation .employee-hover {
      background-color: rgba(64,73,155,.9);
    }
    .btn:hover,
    .btn:focus,
    .btn:active,
    .btn.active,
    .btn.disabled,
    .btn[disabled] {
      background-color: #40499b;
      background-color: rgba(64,73,155,.8);
    }
    #catalog .category-img .description,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a {
      background-color: rgba(64,73,155,.7);
    }
    .sidebar .banners .banner-text {
      background-color: rgba(64,73,155,.65);
    }
    #slider.rs-slider .tparrows,
	.product-page .add-cart-form .number .regulator a:hover {
      background-color: rgba(64,73,155,.5);
    }
	.pricing .bottom-box {
	  background-color: rgba(64,73,155,.05);
	}
	.pricing {
	  background-color: rgba(64,73,155,.06);
	}
	.pricing .options li,
	.pricing .bottom-box {
	  border-color: rgba(64,73,155,.1);
	}
	.header .cart-header .dropdown-toggle,
	#footer .newsletter input:focus + .submit,
    .icon,
    .big-icon,
    .big-icon:visited,
    .service .icon,
    .close:hover,
    .close:focus,
    .img-thumbnail:hover .bg-images i:before,
    .box-404 h1,
    .gallery-images:hover .bg-images i:before,
    .features-block .header-box .icon-box,
    .features-block .header-box,
    .sidebar .newsletter input:focus + .submit,
	.sidebar .section .selected .close:hover,
    .package .title a,
    .package .price-box .price,
    .package .price-box .icon,
    .pricing .title a,
    .pricing .options li span,
	.pricing .options li.active {
	  color: #40499b;
	}
	.pricing .bottom-box .more {
	  color: rgba(64,73,155,.7);
	}
	.pricing .options li {
	  color: rgba(64,73,155,.4);
	}
	.phone-header a svg path,
	.search-header a svg path,
	.product .actions a svg path,
    .product-remove:hover path,
    .sidebar .wishlist .add-cart:hover path,
    .header .cart-header .dropdown-toggle .icon svg path,
    .search-active .search-submit svg path,
    .new-checkbox svg polygon,
	.product-bottom .related-products li .button-box .wishlist:hover svg path,
	.jslider .jslider-pointer svg path,
	.rating-box .rating svg polygon {
	  fill: #40499b;
	}
    .carousel-box .pagination a.selected,
    .banner-set .pagination a.selected {
      background: #ccc;
	  background: rgba(0,0,0,.3);
    }
	@media (max-width: 979px) {
	  .header .primary .navbar .nav > .parent.active > a,
	  .header .primary .navbar .nav > .parent.active:hover > a,
	  .header .primary .navbar .nav .open-sub span,
	  .header .primary .navbar .btn-navbar .icon-bar,
	  .header.header-two .primary .navbar .btn-navbar.collapsed .icon-bar,
	  .accordion-tab > .active > a,
	  .accordion-tab > .active:hover > a,
	  .products-tab .accordion-tab > .active > a,
	  .products-tab .accordion-tab > .active:hover > a {
		background-color: #40499b;
	  }
	}
	.navbar-inverse .brand,
	.navbar-inverse .nav > li > a,
	.btn-group.btn-select .dropdown-toggle,
	.product .product-hover,
	.employee .employee-hover,
	.slider .slid-content{
	  color: #fff;
	}
	.product .product-hover ul li {
	  background-image: url("img/svg/check-icon-white.svg"), none;
	}
  </style>
  
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body class="fixed-header hidden-top">
<div class="page-box">
<div class="page-box-content">
  
<div id="top-box">
  <div class="container">
    <div class="pull-left">
      <div class="btn-group language btn-select">
		<a class="btn dropdown-toggle" role="button" data-toggle="dropdown" href="#">
		  <span class="desktop">Language</span><span class="tablet">Lang</span>: English
		  <span class="caret"></span>
		</a>
		<ul class="dropdown-menu">
		  <li><a href="#"><img src="img/eng-flag.png" alt="">English</a></li>
		  <li><a href="#"><img src="img/fra-flag.png" alt="">France</a></li>
		  <li><a href="#"><img src="img/ger-flag.png" alt="">Germany</a></li>
		</ul>
	  </div>

	  <div class="btn-group currency btn-select">
		<a class="btn dropdown-toggle" role="button" data-toggle="dropdown" href="#">
		  <span class="desktop">Currency</span><span class="tablet">Curr</span>: USD
		  <span class="caret"></span>
		</a>
		<ul class="dropdown-menu">
		  <li><a href="#">USD</a></li>
		  <li><a href="#">EUR</a></li>
		  <li><a href="#">GBP</a></li>
		</ul>
      </div>
    </div>
    
    <div class="my-account navbar navbar-inverse pull-right">
      <div class="navbar-inner">
		<nav>
		  <ul class="nav">
			<li><a href="#">My account</a></li>
			<li><a href="#">My Wishlist</a></li>
			<li><a href="#">Checkout</a></li>
			<li><a href="#">Log in</a></li>
		  </ul>
		</nav>
      </div>
    </div><!-- .my-account -->
  </div>
</div><!-- #top-box -->

<header class="header">
  <div class="container">
	<div class="row">
	  <div class="span2 logo-box">
		<a href="index.html" class="logo">
		  <img src="img/logo.svg" class="logo-img" alt="">
		</a>
	  </div>
	  <div class="span7 primary">
		<div class="navbar">
		  <a class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".primary .nav-collapse">
			<span class="text">Menu</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </a>
		  <nav class="nav-collapse collapse">
			<ul class="nav">
			  <li class="parent">
				<a href="index.html">Home</a>
				<ul class="sub">
				  <li><a href="index.html">Creative</a></li>
				  <li><a href="home-2.html">Paralax</a></li>
				  <li><a href="home-3.html">Simple</a></li>
				  <li><a href="home-4.html">Business</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Pages</a>
				<ul class="sub">
				  <li><a href="sidebar-blocks.html">All sidebar blocks</a></li>
				  <li><a href="full-width.html">Full Width</a></li>
				  <li><a href="left-sidebar.html">Left Sidebar</a></li>
				  <li><a href="right-sidebar.html">Right Sidebar</a></li>
				  <li><a href="about-us.html">About Us</a></li>
				  <li><a href="contact.html">Contact Us</a></li>
				  <li><a href="blog-list.html">Blog List</a></li>
				  <li><a href="blog-view.html">Blog Post View</a></li>
				  <li><a href="404.html">Page 404</a></li>
				  <li><a href="404-2.html">Page 404 (2)</a></li>
				  <li class="parent">
					<a href="#">Portfolio</a>
					<ul class="sub">
					  <li><a href="portfolio-1.html">Portfolio (1 column)</a></li>
					  <li><a href="portfolio-2.html">Portfolio (2 column)</a></li>
					  <li><a href="portfolio-3.html">Portfolio (3 column)</a></li>
					  <li><a href="portfolio-4.html">Portfolio (4 column)</a></li>
					  <li><a href="portfolio-slider.html">Portfolio (Slider)</a></li>
					  <li><a href="portfolio-single.html">Single Project</a></li>
					</ul>
				  </li>
				  <li><a href="gallery-modern.html">Modern Gallery</a></li>
				  <li class="parent">
					<a href="#">Gallery</a>
					<ul class="sub">
					  <li><a href="gallery-1.html">Gallery (1 column)</a></li>
					  <li><a href="gallery-2.html">Gallery (2 column)</a></li>
					  <li><a href="gallery-3.html">Gallery (3 column)</a></li>
					  <li><a href="gallery-4.html">Gallery (4 column)</a></li>
					</ul>
				  </li>
				  <li><a href="pricing.html">Pricing</a></li>
				  <li><a href="team.html">Team</a></li>
				  <li><a href="faq.html">FAQ</a></li>
				  <li><a href="services.html">Services</a></li>
				  <li><a href="careers.html">Careers</a></li>
				  <li><a href="coming-soon.html">Coming Soon</a></li>
				  <li><a href="under-construction.html">Under Construction</a></li>
				  <li><a href="sitemap.html">Sitemap</a></li>
				  <li class="parent">
					<a href="#">Newsletter</a>
					<ul class="sub">
					  <li><a href="newsletter-big-intro.html">Newsletter Big Intro</a></li>
					  <li><a href="newsletter-big-portfolio.html">Newsletter Big Portfolio</a></li>
					  <li><a href="newsletter-columns.html">Newsletter Columns</a></li>
					  <li><a href="newsletter-info.html">Newsletter Info</a></li>
					  <li><a href="newsletter-plan.html">Newsletter Plan</a></li>
					  <li><a href="newsletter-portfolio.html">Newsletter Portfolio</a></li>
					  <li><a href="newsletter-product-list.html">Newsletter Product List</a></li>
					  <li><a href="newsletter-story.html">Newsletter Story</a></li>
					</ul>
				  </li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="shop.html">Shop</a>
				<ul class="sub">
				  <li><a href="catalog-grid.html">Catalog (Grid)</a></li>
				  <li><a href="catalog-list.html">Catalog (List)</a></li>
				  <li><a href="product-view.html">Product View</a></li>
				  <li><a href="product-view-variants.html">Product View (Variants)</a></li>
				  <li><a href="cart.html">Shopping Cart</a></li>
				  <li><a href="checkout.html">Proceed to Checkout</a></li>
				  <li><a href="compare.html">Compare Products</a></li>
				  <li><a href="login.html">Login</a></li>
				</ul>
			  </li>
			  <li class="parent megamenu">
				<a href="#">Mega Menu</a>
				<ul class="sub">
				  <li class="promo-block box">
					<a href="#" class="big-image">
					  <img src="img/content/megamenu-big.png" width="240" height="434" alt="">
					</a>
				  </li><!-- .box.promo-block -->
				  
				  <li class="box first">
					<h6 class="title">Savant Apple Integration</h6>
					<ul>
					  <li><a href="#">iPad, iPod touch, iPhone & Mac Control</a></li>
					  <li><a href="#">iPod touch Remote Control</a></li>
					  <li><a href="#">Savant Host (Mac Mini)</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Audio/Video Control</h6>
					<ul>
					  <li><a href="#">Distributed Audio & Video</a></li>
					  <li><a href="#">Matrix Switchers</a></li>
					  <li><a href="#">Audio/Video Processing</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				</ul><!-- .sub -->
			  </li>
			  <li class="parent">
				<a href="#">Elements</a>
				<ul class="sub">
				  <li><a href="elements-accordions.html">Accordions &amp; Toggles</a></li>
				  <li><a href="elements-animations.html">Animations</a></li>
				  <li><a href="elements-buttons.html">Buttons &amp; Social Icons</a></li>
				  <li><a href="elements-carousel.html">Carousels &amp; Sliders</a></li>
				  <li><a href="elements-charts.html">Charts</a></li>
				  <li><a href="elements-container.html">Container</a></li>
				  <li><a href="elements-content-band.html">Content Band</a></li>
				  <li><a href="elements-dividers.html">Dividers & Gaps</a></li>
				  <li><a href="elements-featured-box.html">Featured Box</a></li>
				  <li><a href="elements-icons.html">Font Awesome Icons</a></li>
				  <li><a href="elements-frames.html">Frames</a></li>
				  <li><a href="elements-maps.html">Google Maps</a></li>
				  <li><a href="elements-media.html">Media</a></li>
				  <li><a href="elements-notification.html">Notification</a></li>
				  <li><a href="elements-person.html">Person</a></li>
				  <li><a href="elements-post-sliders.html">Posts Sliders</a></li>
				  <li><a href="elements-pricing.html">Pricing and Data Tables</a></li>
				  <li><a href="elements-sliders.html">Premium Sliders</a></li>
				  <li><a href="elements-progress-bar.html">Progress Bars</a></li>
				  <li><a href="elements-recent-posts.html">Recent Posts</a></li>
				  <li><a href="elements-shop.html">Shop Elements</a></li>
				  <li><a href="elements-tabs.html">Tabs</a></li>
				  <li><a href="elements-testimonials.html">Testimonials</a></li>
				  <li><a href="elements-works.html">Works</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Bootstrap</a>
				<ul class="sub">
				  <li><a href="typography-styles.html">Typography</a></li>
				  <li><a href="tables-styles.html">Tables</a></li>
				  <li><a href="forms-styles.html">Forms</a></li>
				  <li><a href="buttons-styles.html">Buttons</a></li>
				  <li><a href="tabs-styles.html">Tabs</a></li>
				  <li><a href="tooltips-styles.html">Tooltip</a></li>
				  <li><a href="accordions-styles.html">Accordions</a></li>
				</ul>
			  </li>
			</ul>
		  </nav>
		</div>
	  </div><!-- .primary -->
	  
	  <div class="span3">
		<div class="btn-group cart-header">
		  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
			<div class="icon">
			  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
				<g>
				  <path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
				  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
				  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
				  M13.001,14H3V6h10V14z"/>
				  <path fill="#231F20" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
				  <path fill="#231F20" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
				  <path fill="#231F20" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
			   </g>
			  </svg>
			</div>
			Cart <span>0</span>
		  </a>
		  <div class="dropdown-menu">
			<strong>Recently added item(s)</strong>
			<ul class="unstyled">
			  <li>
				<a href="product-view.html" class="product-image"><img src="img/content/product-1.png" width="70" height="70" alt=""></a>
				<a href="#" class="product-remove">
				  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<g>
					  <path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
					  <path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
					  <path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
					  c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
					  H5V2z M12,14H4V5h8V14z"/>
					</g>
				  </svg>
				</a><!-- .product-remove -->
				<h4 class="product-name"><a href="product-view.html" title="">New Apple iPad mini Wi-Fi + with special offer</a></h4>
				<div class="product-price">1 x <span class="price">$1199.00</span></div>
				<div class="clearfix"></div>
			  </li>
			  <li>
				<a href="product-view.html" class="product-image"><img src="img/content/product-2.png" width="70" height="70" alt=""></a>
				<a href="#" class="product-remove">
				  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<g>
					  <path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
					  <path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
					  <path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
					  c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
					  H5V2z M12,14H4V5h8V14z"/>
					</g>
				  </svg>
				</a><!-- .product-remove -->
				<h4 class="product-name"><a href="product-view.html" title="">New Apple iPad mini Wi-Fi + with special offer</a></h4>
				<div class="product-price">1 x <span class="price">$1199.00</span></div>
				<div class="clearfix"></div>
			  </li>
			</ul>
			<div class="cart-button">
			  <button class="btn">View Cart</button>
			  <button class="btn checkout">Checkout</button>
			</div>
		  </div>
		</div><!-- .cart-header -->
		
		<div class="phone-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			  c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
			  M11.001,12H5V2h6V12z"/>
			</svg>
		  </a>
		</div><!-- .phone-header -->
		
		<div class="search-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </a>
		</div><!-- .search-header -->
	  </div>
	  
	  <div class="phone-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<span class="title">Call Us</span> <strong>+1 (777) 123 45 67</strong>
	  </div>
	  <div class="search-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<form name="search-form">
		  <input class="search-string" type="search" placeholder="Search here" name="search-string">
		  <button class="search-submit">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </button>
		</form>
	  </div>
	</div><!--.row -->
  </div>
</header><!-- .header -->

<div id="slider" class="slider load">
  <div class="container">
    <div class="row">
      <div class="sliders-box">
		<div class="slid span12">
		  <img class="slid-img" src="img/content/slide-4.jpg" width="1170" height="550" alt="">
		  <div class="span4 slid-content">
			<h1>Integration & Automation<br> technology to fit any<br> lifestyle</h1>
			<p class="descriptions">At the touch of a button, your drapes or blinds will open and close, your lights turn on and off, your IPod plays music throughout the home!</p>
			<button class="btn btn-large btn-block">More</button>
		  </div>
		</div>
		
		<div class="slid span12">
		  <img class="slid-img" src="img/content/slide-2.jpg" width="1170" height="550" alt="">
		  <div class="span4 slid-content">
			<h1>Integration & Automation<br> technology to fit any<br> lifestyle</h1>
			<p class="descriptions">At the touch of a button, your drapes or blinds will open and close, your lights turn on and off, your IPod plays music throughout the home!</p>
			<button class="btn btn-large btn-block">More</button>
		  </div>
		</div>
		
		<div class="slid span12">
		  <img class="slid-img" src="img/content/slide-3.jpg" width="1170" height="550" alt="">
		  <div class="span4 slid-content">
			<h1>Automation & Integration<br> technology to fit any<br> lifestyle</h1>
			<p class="descriptions">At the touch of a button, your drapes or blinds will open and close, your lights turn on and off, your IPod plays music throughout the home or business whatever suits your needs!</p>
			<button class="btn btn-large btn-block">More</button>
		  </div>
		</div>

		<div class="slid span12">
		  <img class="slid-img" src="img/content/slide-5.jpg" width="1170" height="550" alt="">
		  <div class="span4 slid-content">
			<h1>Automation & Integration<br> technology to fit any<br> lifestyle</h1>
			<p class="descriptions">At the touch of a button, your drapes or blinds will open and close, your lights turn on and off, your IPod plays music throughout the home or business whatever suits your needs!</p>
			<button class="btn btn-large btn-block">More</button>
		  </div>
		</div>
		
		<div class="slid span12">
		  <img class="slid-img" src="img/content/slide-1.jpg" width="1170" height="550" alt="">
		  <div class="span4 slid-content">
			<h1>Automation & Integration<br> technology to fit any<br> lifestyle</h1>
			<p class="descriptions">At the touch of a button, your drapes or blinds will open and close, your lights turn on and off, your IPod plays music throughout the home or business whatever suits your needs!</p>
			<button class="btn btn-large btn-block">More</button>
		  </div>
		</div>
	  </div><!-- .sliders-box -->

      <div class="span4 slider-nav">
		<div class="nav-box">
		  <a class="next" href="#">
			<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			  width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#838383" points="1,0.001 0,1.001 7,8 0,14.999 1,15.999 9,8 "/>
			</svg>
		  </a>
		  <a class="prev" href="#">
			<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			  width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#838383" points="8,15.999 9,14.999 2,8 9,1.001 8,0.001 0,8 "/>
			</svg>
		  </a>
		  <div class="pagination switches"></div>	
		</div>
      </div>
    </div>
  </div>
</div><!-- #slider -->

<div class="banner-set load">
  <div class="container">
    <div class="banners">
      <a href="#" class="banner">
		<img src="img/content/banner1.jpg" width="253" height="158" alt="">
		<h2 class="title">Home Theater</h2>
		<div class="description">Nunc condimentum eros vel nibh consectetur dignissim. Ut ante neque, ullamcorper ac feugiat at, ullamcorper sagittis magna.</div>
      </a>
      <a href="#" class="banner">
		<img src="img/content/banner2.jpg" width="253" height="158" alt="">
		<h2 class="title">Multiroom</h2>
		<div class="description">Maecenas ac leo velit. Aliquam venenatis tellus in erat pellentesque ut dignissim turpis consequat. Fusce sit amet sagittis urna.</div>
      </a>
      <a href="#" class="banner">
		<img src="img/content/banner3.jpg" width="253" height="158" alt="">
		<h2 class="title">Lighting Control</h2>
		<div class="description">Phasellus quis mauris non mauris sceleris vehicula. Vestibulum ipsum odio, placerat sed consequat in, congue non nibh.</div>
      </a>
      <a href="#" class="banner">
		<img src="img/content/banner4.jpg" width="253" height="158" alt="">
		<h2 class="title">Amazing Sound</h2>
		<div class="description">Maecenas et massa odio, tincidunt ultrices sapien. Praesent non tortor quis metus posuere gravida at quis nulla.</div>
      </a>
      <a href="#" class="banner">
		<img src="img/content/banner5.jpg" width="253" height="158" alt="">
		<h2 class="title">Home Theater</h2>
		<div class="description">Nunc condimentum eros vel nibh consectetur dignissim. Ut ante neque, ullamcorper ac feugiat at, ullamcorper sagittis magna.</div>
      </a>
	  <a href="#" class="banner">
		<img src="img/content/banner6.jpg" width="253" height="158" alt="">
		<h2 class="title">Multiroom</h2>
		<div class="description">Maecenas ac leo velit. Aliquam venenatis tellus in erat pellentesque ut dignissim turpis consequat. Fusce sit amet sagittis urna.</div>
      </a>
    </div><!-- .banners -->
	<div class="clearfix"></div>
  </div>
  <div class="nav-box">
    <div class="container">
      <a class="prev" href="#"><i class="icon-arrow-left"></i></a>
      <div class="pagination switches"></div>
      <a class="next" href="#"><i class="icon-arrow-right"></i></a>	
    </div>
  </div>
</div><!-- .banner-set -->

<div class="clearfix"></div>

<section id="main">
  <div class="container">
    <div class="recommended-product row carousel-box bottom-padding load">
      <div class="title-box span12">
		<a class="next" href="#">
		  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="1,0.001 0,1.001 7,8 0,14.999 1,15.999 9,8 "/>
		  </svg>
		</a>
		<a class="prev" href="#">
		  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="8,15.999 9,14.999 2,8 9,1.001 8,0.001 0,8 "/>
		  </svg>
		</a>
		<h2 class="title">Recommended Product</h2>
      </div>
      <div class="clearfix"></div>
      <div class="carousel products">
		<div class="span3">
		  <div class="row">
			<div class="span3 product rotation">
			  <div class="default">
				<span class="sale"></span>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-1.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">Sony Led TV KDL-46HX853</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">Sony Led TV KDL-46HX853</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-1.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
			<div class="span3 product rotation">
			  <div class="default">
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-2.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">Sony 3D TV KD3-46H853</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">Sony 3D TV KD3-46H853</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-2.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
		  </div>
		</div>
		<div class="span3">
		  <div class="row">
			<div class="span3 product rotation">
			  <div class="default">
				<span class="sale top"></span>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-3.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">Projector VPL-VW95ES</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">Projector VPL-VW95ES</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-3.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
			<div class="span3 product rotation">
			  <div class="default">
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-4.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">XA700 Wireless speaker</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">XA700 Wireless speaker</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-4.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
		  </div>
		</div>
		<div class="span3">
		  <div class="row">
			<div class="span3 product rotation">
			  <div class="default">
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-5.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html"> 800 Series Diamond</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html"> 800 Series Diamond</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-5.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
			<div class="span3 product rotation">
			  <div class="default">
				<span class="sale new"></span>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-6.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">AirPlay Hi-Fi system</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">AirPlay Hi-Fi system</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-6.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
		  </div>
		</div>
		<div class="span3">
		  <div class="row">
			<div class="span3 product rotation">
			  <div class="default">
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-7.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">Sony Xperia Z</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">Sony Xperia Z</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-7.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
			<div class="span3 product rotation">
			  <div class="default">
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-8.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">Xperia miro</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">Xperia miro</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-8.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
		  </div>
		</div>
		<div class="span3">
		  <div class="row">
			<div class="span3 product rotation">
			  <div class="default">
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-2.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">Sony Xperia Z</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">Sony Xperia Z</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-2.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
			<div class="span3 product rotation">
			  <div class="default">
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-6.png" alt="" title="" width="270" height="270">
				</a>
				<div class="product-description">
				  <div class="vertical">
					<h3 class="product-name">
					  <a href="product-view.html">Xperia miro</a>
					</h3>
					<div class="price">$1, 449.00</div>	
				  </div>
				</div>
			  </div>
			  <div class="product-hover">
				<h3 class="product-name">
				  <a href="product-view.html">Xperia miro</a>
				</h3>
				<div class="price">$1, 449.00</div>
				<a href="product-view.html" class="product-image">
				  <img src="img/content/product-6.png" alt="" title="" width="60" height="60">
				</a>
				<ul>
				  <li>117 cm / 46"LCD TV</li>
				  <li>Full HD 3D & 2D</li>
				  <li>Sony Internet TV</li>
				  <li>Dynamic Edge LED</li>
				  <li>1X-Reality PRO</li>
				</ul>
				<div class="actions">
				  <a href="product-view.html" class="add-cart">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
						  H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
						  c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
						  M13.001,14H3V6h10V14z"/>
						<path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						<path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						<path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
					  </g>
					</svg>
				  </a>
				  <a href="#" class="add-wishlist">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					<path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
					  s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
					  s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					</svg>
				  </a>
				  <a href="#" class="add-compare">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
					  <path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
					  <path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					</svg>
				  </a>
				</div><!-- .actions -->
			  </div><!-- .product-hover -->
			</div><!-- .product -->
		  </div>
		</div>
      </div>
    </div><!-- .recommended-product -->
    
    <div class="products-tab bottom-padding">
      <ul class="nav nav-tabs">
		<li class="active"><a href="#best-sellers">Best Sellers</a></li>
		<li><a href="#new-products">New Products</a></li>
		<li><a href="#related-products">Related Products</a></li>
      </ul>	
      <div class="tab-content">
		<div class="tab-pane active row" id="best-sellers">
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-6.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-5.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Head Mounted Display
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-4.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Smart TV 3D
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-3.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-2.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
			  <h3 class="product-name">
				Network Media Player
			  </h3>
			  <div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-1.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		</div>
		
		<div class="tab-pane row" id="new-products">
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-3.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-2.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Head Mounted Display
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-1.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Smart TV 3D
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-5.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-4.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-6.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		</div>
		
		<div class="tab-pane row" id="related-products">
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-1.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-2.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Head Mounted Display
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-3.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Smart TV 3D
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-4.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-5.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		  
		  <a href="#" class="span2 product">
			<div class="product-image">
			  <img src="img/content/product-6.png" alt="" title="" width="270" height="270">
			</div>
			<div class="product-description">
			  <div class="vertical">
				<h3 class="product-name">
				  Network Media Player
				</h3>
				<div class="price">$1, 449.00</div>	
			  </div>
			</div>
		  </a><!-- .product -->
		</div>
      </div>
    </div><!-- .products-tab -->
    
    <div class="manufactures row carousel-box bottom-padding load">
      <div class="title-box span12">
		<a class="next" href="#">
		  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="1,0.001 0,1.001 7,8 0,14.999 1,15.999 9,8 "/>
		  </svg>
		</a>
		<a class="prev" href="#">
		  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="8,15.999 9,14.999 2,8 9,1.001 8,0.001 0,8 "/>
		  </svg>
		</a>
		<h2 class="title">Manufactures</h2>
      </div>
      <div class="clearfix"></div>
      <div class="carousel no-responsive">
		<div class="span2">
		  <a href="#" class="make">
			<img src="img/content/make-1.png" width="128" height="128" alt="">
		  </a>
		</div>
		<div class="span2">
		  <a href="#" class="make">
			<img src="img/content/make-2.png" width="128" height="128" alt="">
		  </a>
		</div>
		<div class="span2">
		  <a href="#" class="make">
			<img src="img/content/make-3.png" width="128" height="128" alt="">
		  </a>
		</div>
		<div class="span2">
		  <a href="#" class="make">
			<img src="img/content/make-4.png" width="128" height="128" alt="">
		  </a>
		</div>
		<div class="span2">
		  <a href="#" class="make">
			<img src="img/content/make-5.png" width="128" height="128" alt="">
		  </a>
		</div>
		<div class="span2">
		  <a href="#" class="make">
			<img src="img/content/make-6.png" width="128" height="128" alt="">
		  </a>
		</div>
		<div class="span2">
		  <a href="#" class="make">
			<img src="img/content/make-4.png" width="128" height="128" alt="">
		  </a>
		</div>
      </div>
    </div><!-- .manufactures -->
    
    <div class="row bottom-padding last">
      <div class="about-us span6">
		<div class="title-box">
		  <h2 class="title">About Us</h2>
		</div>
		<p><strong>Cras rhoncus, magna adipiscing viverra ultrices, arcu ipsum fringilla sem, et malesuada sem dolor eu massa. Aliquam erat volutpat. Etiam ultrices sem ligula. Proin nunc odio, commodo id ultrices et, sollicitudin ac arcu.</strong></p>
		<p>Duis bibendum pulvinar laoreet. Ut eu arcu sit amet elit placerat pharetra sit amet a tortor. Fusce vestibulum auctor rhoncus. Nullam rhoncus, tellus a congue elementum, leo ipsum tincidunt justo, ut condimentum velit eros et lectus. Phasellus ultrices rhoncus vehicula. Morbi in nisl metus, sed ultricies eros. Ut a quam nisl. In hac habitasse platea dictumst. Morbi non nunc arcu.</p>
		<p>Integer ultricies semper massa non condimentum. Phasellus eu ipsum justo. Nullam non pulvinar purus. Ut ante ipsum, venenatis at tristique quis, congue vitae felis. Aliquam cursus diam in massa dapibus auctor. In volutpat, risus non egestas luctus, justo tellus laoreet justo, id mattis odio est non lectus.</p>
      </div><!-- .about-us -->
      
      <div class="news span6">
		<div class="title-box">
		  <a href="#" class="btn btn-inverse">All news <i class="icon-arrow-right icon-white"></i></a>
		  <h2 class="title">News</h2>
		</div>
		<div class="row">
		  <div class="span3 news-item">
			<div class="time">Mar 6, 2013</div>
			<h3 class="title"><a href="#">Fusce vestibulum auctor rhoncus</a></h3>
			<div class="news-body">Nullam rhoncus, tellus a congue elementum, leo ipsum tincidunt justo, ut condimentum velit eros et lectus.</div>
			<a href="#" class="more">Read more <span>&#9002;</span></a>
		  </div><!-- .news-item -->
		  <div class="span3 news-item">
			<div class="time">Mar 5, 2013</div>
			<h3 class="title"><a href="#">Vestibulum sollicitudin arcu</a></h3>
			<div class="news-body">Curabitur feugiat congue facilisis. Nam eleifend augue non purus tincidunt faucibus. Praesent egestas turpis ac eros pulvinar tempus.</div>
			<a href="#" class="more">Read more <span>&#9002;</span></a>
		  </div><!-- .news-item -->
		  <div class="span3 news-item">
			<div class="time">Mar 4, 2013</div>
			<h3 class="title"><a href="#">Etiam ultrices sem ligul</a></h3>
			<div class="news-body">Sed cursus massa id nisl faucibus sagittis vitae eget libero. Cras rhoncus, magna adipiscing viverra ultrices, arcu ipsum fringilla sem.</div>
			<a href="#" class="more">Read more <span>&#9002;</span></a>
		  </div><!-- .news-item -->
		  <div class="span3 news-item">
			<div class="time">Mar 3, 2013</div>
			<h3 class="title"><a href="#">Etiam convallis massa risus</a></h3>
			<div class="news-body">Maecenas venenatis ornare est quis tempor. In hac habitasse platea dictumst. Etiam lobortis rutrum arcu.</div>
			<a href="#" class="more">Read more <span>&#9002;</span></a>
		  </div><!-- .news-item -->
		</div>
      </div><!-- .news -->
    </div>
  </div>
</section><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="span3 social">
          <h3>Follow Us</h3>
          <p>Follow us in social media</p>
          <a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a>
        </div>
        <div class="span3 newsletter">
          <h3>Newsletter</h3>
          <p>Sign up for newsletter</p>
          <form>
            <input class="input-block-level" type="email">
            <button class="submit"><i class="fa fa-arrow-circle-o-right"></i></button>
          </form>
        </div>
        <div class="span3 nav-box">
          <h3>Information</h3>
		  <nav>
			<ul>
			  <li><a href="#">About us</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">Terms & Condotions</a></li>
			  <li><a href="#">Secure payment</a></li>
			</ul>
		  </nav>
        </div>
        <div class="span3 nav-box">
          <h3>My account</h3>
		  <nav>
			<ul>
			  <li><a href="#">My account</a></li>
			  <li><a href="#">Order History</a></li>
			  <li><a href="#">Wish List</a></li>
			  <li><a href="#">Newsletter</a></li>
			</ul>
		  </nav>
        </div>
      </div>
    </div>
  </div><!-- .footer-top -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="span3 copyright">Copyright &copy; ItemBridge Inc., 2013</div>
        <div class="span3 phone">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#c6c6c6" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			   c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
				M11.001,12H5V2h6V12z"/>
			</svg>
		  </div>
          <strong class="title">Call Us:</strong> +1 (877) 123-45-67 <br>
          <strong>or</strong> +1 (777) 123-45-67
        </div>
        <div class="span3 address">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <g>
				<g>
				  <path fill="#c6c6c6" d="M8,16c-0.256,0-0.512-0.098-0.707-0.293C7.077,15.491,2,10.364,2,6c0-3.309,2.691-6,6-6
					c3.309,0,6,2.691,6,6c0,4.364-5.077,9.491-5.293,9.707C8.512,15.902,8.256,16,8,16z M8,2C5.795,2,4,3.794,4,6
					c0,2.496,2.459,5.799,4,7.536c1.541-1.737,4-5.04,4-7.536C12.001,3.794,10.206,2,8,2z"/>
				</g>
				<g>
				  <circle fill="#c6c6c6" cx="8.001" cy="6" r="2"/>
				</g>
			  </g>
			</svg>
		  </div>
          49 Archdale, 2B Charleston 5655, Excel Tower<br> OPG Rpad, 4538FH
        </div>
        <div class="span3">
          <a href="#" class="up pull-right"><i class="icon-arrow-up icon-white"></i></a>
        </div>
      </div>
    </div>
  </div><!-- .footer-bottom -->
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>