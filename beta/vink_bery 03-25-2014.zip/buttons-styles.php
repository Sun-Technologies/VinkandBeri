<!DOCTYPE html>
<html>
<head>
  <title>Buttons Styles \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body>
<div class="page-box">
<div class="page-box-content">

<?php include 'header.php'; ?>

<div class="breadcrumb-box">
  <div class="container">
    <ul class="breadcrumb">
      <li><a href="index.html">Home</a> <span class="divider">/</span></li>
      <li><a href="#">Bootstrap</a> <span class="divider">/</span></li>
      <li class="active">Buttons Styles</li>
    </ul>	
  </div>
</div><!-- .breadcrumb-box -->

<div id="main" class="page">
  <header class="page-header">
    <div class="container">
      <h1 class="title">Buttons Styles</h1>
    </div>	
  </header>
  
  <div class="container">
    <div class="row">
	  <article class="content span12">
		<h2>Default buttons</h2>
        <p>Button styles can be applied to anything with the <code>.btn</code> class applied. However, typically you'll want to apply these to only <code>&lt;a&gt;</code> and <code>&lt;button&gt;</code> elements for the best rendering.</p>
		<table class="table table-bordered table-striped">
		  <thead>
			<tr>
			  <th>Button</th>
			  <th>class=""</th>
			  <th>Description</th>
			</tr>
		  </thead>
		  <tbody>
			<tr>
			  <td><button type="button" class="btn">Default</button></td>
			  <td><code>btn</code></td>
			  <td>Standard gray button with gradient</td>
			</tr>
			<tr>
			  <td><button type="button" class="btn btn-primary">Primary</button></td>
			  <td><code>btn btn-primary</code></td>
			  <td>Provides extra visual weight and identifies the primary action in a set of buttons</td>
			</tr>
			<tr>
			  <td><button type="button" class="btn btn-info">Info</button></td>
			  <td><code>btn btn-info</code></td>
			  <td>Used as an alternative to the default styles</td>
			</tr>
			<tr>
			  <td><button type="button" class="btn btn-success">Success</button></td>
			  <td><code>btn btn-success</code></td>
			  <td>Indicates a successful or positive action</td>
			</tr>
			<tr>
			  <td><button type="button" class="btn btn-warning">Warning</button></td>
			  <td><code>btn btn-warning</code></td>
			  <td>Indicates caution should be taken with this action</td>
			</tr>
			<tr>
			  <td><button type="button" class="btn btn-danger">Danger</button></td>
			  <td><code>btn btn-danger</code></td>
			  <td>Indicates a dangerous or potentially negative action</td>
			</tr>
			<tr>
			  <td><button type="button" class="btn btn-link">Link</button></td>
			  <td><code>btn btn-link</code></td>
			  <td>Deemphasize a button by making it look like a link while maintaining button behavior</td>
			</tr>
		  </tbody>
		</table>

		<br>
		<h4>Cross browser compatibility</h4>
		<p>IE9 doesn't crop background gradients on rounded corners, so we remove it. Related, IE9 jankifies disabled <code>button</code> elements, rendering text gray with a nasty text-shadow that we cannot fix.</p>
  
		<br>
		<h2>Example uses</h2>
		<p>Do more with buttons. Control button states or create groups of buttons for more components like toolbars.</p>
  
		<br>
		<h4>Stateful</h4>
		<p>Add <code>data-loading-text="Loading..."</code> to use a loading state on a button.</p>
		<div class="bs-docs-example">
		  <button type="button" class="btn btn-primary btn-loading" data-loading-text="Loading...">Loading state</button>
		</div>
		<pre class="prettyprint linenums">&lt;button type="button" class="btn btn-primary" data-loading-text="Loading..."&gt;Loading state&lt;/button&gt;</pre>
  
		<br>
		<h4>Single toggle</h4>
		<p>Add <code>data-toggle="button"</code> to activate toggling on a single button.</p>
		<div class="bs-docs-example">
		  <button type="button" class="btn btn-primary" data-toggle="button">Single Toggle</button>
		</div>
		<pre class="prettyprint linenums">&lt;button type="button" class="btn btn-primary" data-toggle="button"&gt;Single Toggle&lt;/button&gt;</pre>
  
		<br>
		<h4>Checkbox</h4>
		<p>Add <code>data-toggle="buttons-checkbox"</code> for checkbox style toggling on btn-group.</p>
		<div class="bs-docs-example">
		  <div class="btn-group" data-toggle="buttons-checkbox">
			<button type="button" class="btn btn-primary">Left</button>
			<button type="button" class="btn btn-primary">Middle</button>
			<button type="button" class="btn btn-primary">Right</button>
		  </div>
		</div>
<pre class="prettyprint linenums">
&lt;div class="btn-group" data-toggle="buttons-checkbox"&gt;
&lt;button type="button" class="btn btn-primary"&gt;Left&lt;/button&gt;
&lt;button type="button" class="btn btn-primary"&gt;Middle&lt;/button&gt;
&lt;button type="button" class="btn btn-primary"&gt;Right&lt;/button&gt;
&lt;/div&gt;
</pre>

		<br>
		<h4>Radio</h4>
		<p>Add <code>data-toggle="buttons-radio"</code> for radio style toggling on btn-group.</p>
		<div class="bs-docs-example" style="padding-bottom: 24px;">
		  <div class="btn-group" data-toggle="buttons-radio">
			<button type="button" class="btn btn-primary">Left</button>
			<button type="button" class="btn btn-primary">Middle</button>
			<button type="button" class="btn btn-primary">Right</button>
		  </div>
		</div>
<pre class="prettyprint linenums">
&lt;div class="btn-group" data-toggle="buttons-radio"&gt;
  &lt;button type="button" class="btn btn-primary"&gt;Left&lt;/button&gt;
  &lt;button type="button" class="btn btn-primary"&gt;Middle&lt;/button&gt;
  &lt;button type="button" class="btn btn-primary"&gt;Right&lt;/button&gt;
&lt;/div&gt;
</pre>

		<br>
		<h2>Button sizes</h2>
		<p>Fancy larger or smaller buttons? Add <code>.btn-large</code>, <code>.btn-small</code>, or <code>.btn-mini</code> for additional sizes.</p>
		<div class="bs-docs-example">
		  <p>
			<button type="button" class="btn btn-large btn-primary">Large button</button>
			<button type="button" class="btn btn-large">Large button</button>
		  </p>
		  <p>
			<button type="button" class="btn btn-primary">Default button</button>
			<button type="button" class="btn">Default button</button>
		  </p>
		  <p>
			<button type="button" class="btn btn-small btn-primary">Small button</button>
			<button type="button" class="btn btn-small">Small button</button>
		  </p>
		  <p>
			<button type="button" class="btn btn-mini btn-primary">Mini button</button>
			<button type="button" class="btn btn-mini">Mini button</button>
		  </p>
		</div>
<pre class="prettyprint linenums">
&lt;p&gt;
  &lt;button class="btn btn-large btn-primary" type="button"&gt;Large button&lt;/button&gt;
  &lt;button class="btn btn-large" type="button"&gt;Large button&lt;/button&gt;
&lt;/p&gt;
&lt;p&gt;
  &lt;button class="btn btn-primary" type="button"&gt;Default button&lt;/button&gt;
  &lt;button class="btn" type="button"&gt;Default button&lt;/button&gt;
&lt;/p&gt;
&lt;p&gt;
  &lt;button class="btn btn-small btn-primary" type="button"&gt;Small button&lt;/button&gt;
  &lt;button class="btn btn-small" type="button"&gt;Small button&lt;/button&gt;
&lt;/p&gt;
&lt;p&gt;
  &lt;button class="btn btn-mini btn-primary" type="button"&gt;Mini button&lt;/button&gt;
  &lt;button class="btn btn-mini" type="button"&gt;Mini button&lt;/button&gt;
&lt;/p&gt;
</pre>
		<p>Create block level buttons&mdash;those that span the full width of a parent&mdash; by adding <code>.btn-block</code>.</p>
		<div class="bs-docs-example">
		  <div class="well" style="max-width: 400px; margin: 0 auto 10px;">
			<button type="button" class="btn btn-large btn-block btn-primary">Block level button</button>
			<button type="button" class="btn btn-large btn-block">Block level button</button>
		  </div>
		</div>
<pre class="prettyprint linenums">
&lt;button class="btn btn-large btn-block btn-primary" type="button"&gt;Block level button&lt;/button&gt;
&lt;button class="btn btn-large btn-block" type="button"&gt;Block level button&lt;/button&gt;
</pre>

		<br>
		<h2>Disabled state</h2>
		<p>Make buttons look unclickable by fading them back 50%.</p>

		<br>
		<h3>Anchor element</h3>
		<p>Add the <code>.disabled</code> class to <code>&lt;a&gt;</code> buttons.</p>
		<p class="bs-docs-example">
		  <a href="#" class="btn btn-large btn-primary disabled">Primary link</a>
		  <a href="#" class="btn btn-large disabled">Link</a>
		</p>
<pre class="prettyprint linenums">
&lt;a href="#" class="btn btn-large btn-primary disabled"&gt;Primary link&lt;/a&gt;
&lt;a href="#" class="btn btn-large disabled"&gt;Link&lt;/a&gt;
</pre>
		<p>
		  <span class="label label-info">Heads up!</span>
		  We use <code>.disabled</code> as a utility class here, similar to the common <code>.active</code> class, so no prefix is required. Also, this class is only for aesthetic; you must use custom JavaScript to disable links here.
		</p>

		<br>
		<h3>Button element</h3>
		<p>Add the <code>disabled</code> attribute to <code>&lt;button&gt;</code> buttons.</p>
		<p class="bs-docs-example">
		  <button type="button" class="btn btn-large btn-primary disabled" disabled="disabled">Primary button</button>
		  <button type="button" class="btn btn-large" disabled>Button</button>
		</p>
<pre class="prettyprint linenums">
&lt;button type="button" class="btn btn-large btn-primary disabled" disabled="disabled"&gt;Primary button&lt;/button&gt;
&lt;button type="button" class="btn btn-large" disabled&gt;Button&lt;/button&gt;
</pre>

		<br>
		<h2>One class, multiple tags</h2>
		<p>Use the <code>.btn</code> class on an <code>&lt;a&gt;</code>, <code>&lt;button&gt;</code>, or <code>&lt;input&gt;</code> element.</p>
		<form class="bs-docs-example">
		  <a class="btn" href="#">Link</a>
		  <button class="btn" type="submit">Button</button>
		  <input class="btn" type="button" value="Input">
		  <input class="btn" type="submit" value="Submit">
		</form>
<pre class="prettyprint linenums">
&lt;a class="btn" href=""&gt;Link&lt;/a&gt;
&lt;button class="btn" type="submit"&gt;Button&lt;/button&gt;
&lt;input class="btn" type="button" value="Input"&gt;
&lt;input class="btn" type="submit" value="Submit"&gt;
</pre>
        <p>As a best practice, try to match the element for your context to ensure matching cross-browser rendering. If you have an <code>input</code>, use an <code>&lt;input type="submit"&gt;</code> for your button.</p>
	  
		<br>
		<h2 id="social-icon">Social icons</h2>
		<div class="row icons-preview social">
		  <ul class="pull-left span3">
			<li><i class="icon-duckduckgo"></i> icon-duckduckgo</li>
			<li><i class="icon-aim"></i> icon-aim</li>
			<li><i class="icon-delicious"></i> icon-delicious</li>
			<li><i class="icon-paypal"></i> icon-paypal</li>
			<li><i class="icon-flattr"></i> icon-flattr</li>
			<li><i class="icon-android"></i> icon-android</li>
			<li><i class="icon-eventful"></i> icon-eventful</li>
			<li><i class="icon-smashmag"></i> icon-smashmag</li>
			<li><i class="icon-gplus"></i> icon-gplus</li>
			<li><i class="icon-wikipedia"></i> icon-wikipedia</li>
			<li><i class="icon-lanyrd"></i> icon-lanyrd</li>
			<li><i class="icon-calendar"></i> icon-calendar</li>
			<li><i class="icon-stumbleupon"></i> icon-stumbleupon</li>
			<li><i class="icon-fivehundredpx"></i> icon-fivehundredpx</li>
			<li><i class="icon-pinterest"></i> icon-pinterest</li>
			<li><i class="icon-bitcoin"></i> icon-bitcoin</li>
			<li><i class="icon-w3c"></i> icon-w3c</li>
			<li><i class="icon-foursquare"></i> icon-foursquare</li>
			<li><i class="icon-html5"></i> icon-html5</li>
			<li><i class="icon-ie"></i> icon-ie</li>
			<li><i class="icon-call"></i> icon-call</li>
			<li><i class="icon-grooveshark"></i> icon-grooveshark</li>
			<li><i class="icon-ninetyninedesigns"></i> icon-ninetyninedesigns</li>
			<li><i class="icon-forrst"></i> icon-forrst</li>
			<li><i class="icon-digg"></i> icon-digg</li>
		  </ul>
		  <ul class="pull-left span3">
			<li><i class="icon-spotify"></i> icon-spotify</li>
			<li><i class="icon-reddit"></i> icon-reddit</li>
			<li><i class="icon-guest"></i> icon-guest</li>
			<li><i class="icon-gowalla"></i> icon-gowalla</li>
			<li><i class="icon-appstore"></i> icon-appstore</li>
			<li><i class="icon-blogger"></i> icon-blogger</li>
			<li><i class="icon-cc"></i> icon-cc</li>
			<li><i class="icon-dribbble"></i> icon-dribbble</li>
			<li><i class="icon-evernote"></i> icon-evernote</li>
			<li><i class="icon-flickr"></i> icon-flickr</li>
			<li><i class="icon-google"></i> icon-google</li>
			<li><i class="icon-viadeo"></i> icon-viadeo</li>
			<li><i class="icon-instapaper"></i> icon-instapaper</li>
			<li><i class="icon-weibo"></i> icon-weibo</li>
			<li><i class="icon-klout"></i> icon-klout</li>
			<li><i class="icon-linkedin"></i> icon-linkedin</li>
			<li><i class="icon-meetup"></i> icon-meetup</li>
			<li><i class="icon-vk"></i> icon-vk</li>
			<li><i class="icon-plancast"></i> icon-plancast</li>
			<li><i class="icon-disqus"></i> icon-disqus</li>
			<li><i class="icon-rss"></i> icon-rss</li>
			<li><i class="icon-skype"></i> icon-skype</li>
			<li><i class="icon-twitter"></i> icon-twitter</li>
			<li><i class="icon-youtube"></i> icon-youtube</li>
		  </ul>
		  <ul class="pull-left span3">
			<li><i class="icon-vimeo"></i> icon-vimeo</li>
			<li><i class="icon-windows"></i> icon-windows</li>
			<li><i class="icon-xing"></i> icon-xing</li>
			<li><i class="icon-yahoo"></i> icon-yahoo</li>
			<li><i class="icon-chrome"></i> icon-chrome</li>
			<li><i class="icon-email"></i> icon-email</li>
			<li><i class="icon-macstore"></i> icon-macstore</li>
			<li><i class="icon-myspace"></i> icon-myspace</li>
			<li><i class="icon-podcast"></i> icon-podcast</li>
			<li><i class="icon-amazon"></i> icon-amazon</li>
			<li><i class="icon-steam"></i> icon-steam</li>
			<li><i class="icon-cloudapp"></i> icon-cloudapp</li>
			<li><i class="icon-dropbox"></i> icon-dropbox</li>
			<li><i class="icon-ebay"></i> icon-ebay</li>
			<li><i class="icon-facebook"></i> icon-facebook</li>
			<li><i class="icon-github"></i> icon-github</li>
			<li><i class="icon-googleplay"></i> icon-googleplay</li>
			<li><i class="icon-itunes"></i> icon-itunes</li>
			<li><i class="icon-plurk"></i> icon-plurk</li>
			<li><i class="icon-songkick"></i> icon-songkick</li>
			<li><i class="icon-lastfm"></i> icon-lastfm</li>
			<li><i class="icon-gmail"></i> icon-gmail</li>
			<li><i class="icon-pinboard"></i> icon-pinboard</li>
			<li><i class="icon-openid"></i> icon-openid</li>
		  </ul>
		  <ul class="pull-left span3">
			<li><i class="icon-quora"></i> icon-quora</li>
			<li><i class="icon-soundcloud"></i> icon-soundcloud</li>
			<li><i class="icon-tumblr"></i> icon-tumblr</li>
			<li><i class="icon-eventasaurus"></i> icon-eventasaurus</li>
			<li><i class="icon-wordpress"></i> icon-wordpress</li>
			<li><i class="icon-yelp"></i> icon-yelp</li>
			<li><i class="icon-intensedebate"></i> icon-intensedebate</li>
			<li><i class="icon-eventbrite"></i> icon-eventbrite</li>
			<li><i class="icon-scribd"></i> icon-scribd</li>
			<li><i class="icon-posterous"></i> icon-posterous</li>
			<li><i class="icon-stripe"></i> icon-stripe</li>
			<li><i class="icon-opentable"></i> icon-opentable</li>
			<li><i class="icon-cart"></i> icon-cart</li>
			<li><i class="icon-print"></i> icon-print</li>
			<li><i class="icon-angellist"></i> icon-angellist</li>
			<li><i class="icon-instagram"></i> icon-instagram</li>
			<li><i class="icon-dwolla"></i> icon-dwolla</li>
			<li><i class="icon-appnet"></i> icon-appnet</li>
			<li><i class="icon-statusnet"></i> icon-statusnet</li>
			<li><i class="icon-acrobat"></i> icon-acrobat</li>
			<li><i class="icon-drupal"></i> icon-drupal</li>
			<li><i class="icon-buffer"></i> icon-buffer</li>
			<li><i class="icon-pocket"></i> icon-pocket</li>
			<li><i class="icon-bitbucket"></i> icon-bitbucket</li>
		  </ul>
		</div>
		<div class="clearfix"></div>
		  
		<br>
		<h3>Squere</h3>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
<pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
    ...
</pre>
	    <br>

	    <h3>Rounded</h3>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
	    <pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
    ...
            </pre>
	    <br>
	      
	    <h3>Circule</h3>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-vk" href="#">vkontakte</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
	    <pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
    ...
            </pre>
	    <br>

	    <h2>Social icons &#8211; Colored</h2>
	    <h3>Squere</h3>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
<pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
  ...
</pre>
	    <br>

	    <h3>Rounded</h3>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
<pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
  ...
</pre>
	    <br>

	    <h3>Circle</h3>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
<pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
  ...
</pre>
	    <br>
	    
	    <h2>Social icons &#8211; Colored only on :hover</h2>
	    <h3>Squere</h3>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
<pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-squere sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
  ...
</pre>
	    <br>
	      
	    <h3>Rounded</h3>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
<pre class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-rounded sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
  ...
</pre>
	    <br>
	    
	    <h3>Circle</h3>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-duckduckgo" href="#">duckduckgo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-aim" href="#">aim</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-delicious" href="#">delicious</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-paypal" href="#">paypal</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-flattr" href="#">flattr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-android" href="#">android</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventful" href="#">eventful</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-smashmag" href="#">smashmag</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gplus" href="#">gplus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-wikipedia" href="#">wikipedia</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-lanyrd" href="#">lanyrd</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-calendar" href="#">calendar</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-stumbleupon" href="#">stumbleupon</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-fivehundredpx" href="#">fivehundredpx</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pinterest" href="#">pinterest</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitcoin" href="#">bitcoin</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-w3c" href="#">w3c</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-foursquare" href="#">foursquare</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-html5" href="#">html5</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ie" href="#">ie</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-call" href="#">call</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-grooveshark" href="#">grooveshark</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ninetyninedesigns" href="#">ninetyninedesigns</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-forrst" href="#">forrst</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-digg" href="#">digg</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-spotify" href="#">spotify</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-reddit" href="#">reddit</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-guest" href="#">guest</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gowalla" href="#">gowalla</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-appstore" href="#">appstore</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-blogger" href="#">blogger</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cc" href="#">cc</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dribbble" href="#">dribbble</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-evernote" href="#">evernote</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-flickr" href="#">flickr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-google" href="#">google</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-viadeo" href="#">viadeo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-instapaper" href="#">instapaper</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-weibo" href="#">weibo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-klout" href="#">klout</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-linkedin" href="#">linkedin</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-meetup" href="#">meetup</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-vk" href="#">vk</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-plancast" href="#">plancast</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-disqus" href="#">disqus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-rss" href="#">rss</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-skype" href="#">skype</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-twitter" href="#">twitter</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-youtube" href="#">youtube</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-vimeo" href="#">vimeo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-windows" href="#">windows</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-xing" href="#">xing</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-yahoo" href="#">yahoo</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-chrome" href="#">chrome</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-email" href="#">email</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-macstore" href="#">macstore</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-myspace" href="#">myspace</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-podcast" href="#">podcast</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-amazon" href="#">amazon</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-steam" href="#">steam</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cloudapp" href="#">cloudapp</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dropbox" href="#">dropbox</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-ebay" href="#">ebay</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-facebook" href="#">facebook</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-github" href="#">github</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-googleplay" href="#">googleplay</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-itunes" href="#">itunes</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-plurk" href="#">plurk</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-songkick" href="#">songkick</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-lastfm" href="#">lastfm</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-gmail" href="#">gmail</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pinboard" href="#">pinboard</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-openid" href="#">openid</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-quora" href="#">quora</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-soundcloud" href="#">soundcloud</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-tumblr" href="#">tumblr</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventasaurus" href="#">eventasaurus</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-wordpress" href="#">wordpress</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-yelp" href="#">yelp</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-intensedebate" href="#">intensedebate</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-eventbrite" href="#">eventbrite</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-scribd" href="#">scribd</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-posterous" href="#">posterous</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-stripe" href="#">stripe</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-opentable" href="#">opentable</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-cart" href="#">cart</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-print" href="#">print</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-angellist" href="#">angellist</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-instagram" href="#">instagram</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-dwolla" href="#">dwolla</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-appnet" href="#">appnet</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-statusnet" href="#">statusnet</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-acrobat" href="#">acrobat</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-drupal" href="#">drupal</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-buffer" href="#">buffer</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-pocket" href="#">pocket</a>
	    <a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitbucket" href="#">bitbucket</a>
	    <div class="clearfix button-preview-margin"></div>
	    <br>
<pre style="WHITE-SPACE: pre" class="prettyprint linenums">
&lt;a class="sbtnf sbtnf-circle sbtnf-icon-white sbtnf-icon-bg-black color-hover icon-bitbucket" href="#"&gt;bitbucket&lt;/a&gt;
    ...
        </pre>

	  </article>
    </div>
  </div>
</div><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="span3 social">
          <h3>Follow Us</h3>
          <p>Follow us in social media</p>
          <a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a>
        </div>
        <div class="span3 newsletter">
          <h3>Newsletter</h3>
          <p>Sign up for newsletter</p>
          <form>
            <input class="input-block-level" type="email">
            <button class="submit"><i class="fa fa-arrow-circle-o-right"></i></button>
          </form>
        </div>
        <div class="span3 nav-box">
          <h3>Information</h3>
		  <nav>
			<ul>
			  <li><a href="#">About us</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">Terms & Condotions</a></li>
			  <li><a href="#">Secure payment</a></li>
			</ul>
		  </nav>
        </div>
        <div class="span3 nav-box">
          <h3>My account</h3>
		  <nav>
			<ul>
			  <li><a href="#">My account</a></li>
			  <li><a href="#">Order History</a></li>
			  <li><a href="#">Wish List</a></li>
			  <li><a href="#">Newsletter</a></li>
			</ul>
		  </nav>
        </div>
      </div>
    </div>
  </div><!-- .footer-top -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="span3 copyright">Copyright &copy; ItemBridge Inc., 2013</div>
        <div class="span3 phone">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#c6c6c6" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			   c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
				M11.001,12H5V2h6V12z"/>
			</svg>
		  </div>
          <strong class="title">Call Us:</strong> +1 (877) 123-45-67 <br>
          <strong>or</strong> +1 (777) 123-45-67
        </div>
        <div class="span3 address">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <g>
				<g>
				  <path fill="#c6c6c6" d="M8,16c-0.256,0-0.512-0.098-0.707-0.293C7.077,15.491,2,10.364,2,6c0-3.309,2.691-6,6-6
					c3.309,0,6,2.691,6,6c0,4.364-5.077,9.491-5.293,9.707C8.512,15.902,8.256,16,8,16z M8,2C5.795,2,4,3.794,4,6
					c0,2.496,2.459,5.799,4,7.536c1.541-1.737,4-5.04,4-7.536C12.001,3.794,10.206,2,8,2z"/>
				</g>
				<g>
				  <circle fill="#c6c6c6" cx="8.001" cy="6" r="2"/>
				</g>
			  </g>
			</svg>
		  </div>
          49 Archdale, 2B Charleston 5655, Excel Tower<br> OPG Rpad, 4538FH
        </div>
        <div class="span3">
          <a href="#" class="up pull-right"><i class="icon-arrow-up icon-white"></i></a>
        </div>
      </div>
    </div>
  </div><!-- .footer-bottom -->
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>