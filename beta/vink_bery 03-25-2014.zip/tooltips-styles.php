<!DOCTYPE html>
<html>
<head>
  <title>Tooltips \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body>
<div class="page-box">
<div class="page-box-content">

<header class="header header-two">
  <div class="container">
	<div class="row">
	  <div class="span2 logo-box">
		<a href="index.html" class="logo">
		  <img src="img/logo.svg" class="logo-img" alt="">
		</a>
	  </div>
	  <div class="span7 primary">
		<div class="navbar">
		  <a class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".primary .nav-collapse">
			<span class="text">Menu</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </a>
		  <nav class="nav-collapse collapse">
			<ul class="nav">
			  <li class="parent">
				<a href="index.html">Home</a>
				<ul class="sub">
				  <li><a href="index.html">Creative</a></li>
				  <li><a href="home-2.html">Paralax</a></li>
				  <li><a href="home-3.html">Simple</a></li>
				  <li><a href="home-4.html">Business</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Pages</a>
				<ul class="sub">
				  <li><a href="sidebar-blocks.html">All sidebar blocks</a></li>
				  <li><a href="full-width.html">Full Width</a></li>
				  <li><a href="left-sidebar.html">Left Sidebar</a></li>
				  <li><a href="right-sidebar.html">Right Sidebar</a></li>
				  <li><a href="about-us.html">About Us</a></li>
				  <li><a href="contact.html">Contact Us</a></li>
				  <li><a href="blog-list.html">Blog List</a></li>
				  <li><a href="blog-view.html">Blog Post View</a></li>
				  <li><a href="404.html">Page 404</a></li>
				  <li><a href="404-2.html">Page 404 (2)</a></li>
				  <li class="parent">
					<a href="#">Portfolio</a>
					<ul class="sub">
					  <li><a href="portfolio-1.html">Portfolio (1 column)</a></li>
					  <li><a href="portfolio-2.html">Portfolio (2 column)</a></li>
					  <li><a href="portfolio-3.html">Portfolio (3 column)</a></li>
					  <li><a href="portfolio-4.html">Portfolio (4 column)</a></li>
					  <li><a href="portfolio-slider.html">Portfolio (Slider)</a></li>
					  <li><a href="portfolio-single.html">Single Project</a></li>
					</ul>
				  </li>
				  <li><a href="gallery-modern.html">Modern Gallery</a></li>
				  <li class="parent">
					<a href="#">Gallery</a>
					<ul class="sub">
					  <li><a href="gallery-1.html">Gallery (1 column)</a></li>
					  <li><a href="gallery-2.html">Gallery (2 column)</a></li>
					  <li><a href="gallery-3.html">Gallery (3 column)</a></li>
					  <li><a href="gallery-4.html">Gallery (4 column)</a></li>
					</ul>
				  </li>
				  <li><a href="pricing.html">Pricing</a></li>
				  <li><a href="team.html">Team</a></li>
				  <li><a href="faq.html">FAQ</a></li>
				  <li><a href="services.html">Services</a></li>
				  <li><a href="careers.html">Careers</a></li>
				  <li><a href="coming-soon.html">Coming Soon</a></li>
				  <li><a href="under-construction.html">Under Construction</a></li>
				  <li><a href="sitemap.html">Sitemap</a></li>
				  <li class="parent">
					<a href="#">Newsletter</a>
					<ul class="sub">
					  <li><a href="newsletter-big-intro.html">Newsletter Big Intro</a></li>
					  <li><a href="newsletter-big-portfolio.html">Newsletter Big Portfolio</a></li>
					  <li><a href="newsletter-columns.html">Newsletter Columns</a></li>
					  <li><a href="newsletter-info.html">Newsletter Info</a></li>
					  <li><a href="newsletter-plan.html">Newsletter Plan</a></li>
					  <li><a href="newsletter-portfolio.html">Newsletter Portfolio</a></li>
					  <li><a href="newsletter-product-list.html">Newsletter Product List</a></li>
					  <li><a href="newsletter-story.html">Newsletter Story</a></li>
					</ul>
				  </li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="shop.html">Shop</a>
				<ul class="sub">
				  <li><a href="catalog-grid.html">Catalog (Grid)</a></li>
				  <li><a href="catalog-list.html">Catalog (List)</a></li>
				  <li><a href="product-view.html">Product View</a></li>
				  <li><a href="product-view-variants.html">Product View (Variants)</a></li>
				  <li><a href="cart.html">Shopping Cart</a></li>
				  <li><a href="checkout.html">Proceed to Checkout</a></li>
				  <li><a href="compare.html">Compare Products</a></li>
				  <li><a href="login.html">Login</a></li>
				</ul>
			  </li>
			  <li class="parent megamenu">
				<a href="#">Mega Menu</a>
				<ul class="sub">
				  <li class="promo-block box">
					<a href="#" class="big-image">
					  <img src="img/content/megamenu-big.png" width="240" height="434" alt="">
					</a>
				  </li><!-- .box.promo-block -->
				  
				  <li class="box first">
					<h6 class="title">Savant Apple Integration</h6>
					<ul>
					  <li><a href="#">iPad, iPod touch, iPhone & Mac Control</a></li>
					  <li><a href="#">iPod touch Remote Control</a></li>
					  <li><a href="#">Savant Host (Mac Mini)</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Audio/Video Control</h6>
					<ul>
					  <li><a href="#">Distributed Audio & Video</a></li>
					  <li><a href="#">Matrix Switchers</a></li>
					  <li><a href="#">Audio/Video Processing</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				</ul><!-- .sub -->
			  </li>
			  <li class="parent">
				<a href="#">Elements</a>
				<ul class="sub">
				  <li><a href="elements-accordions.html">Accordions &amp; Toggles</a></li>
				  <li><a href="elements-animations.html">Animations</a></li>
				  <li><a href="elements-buttons.html">Buttons &amp; Social Icons</a></li>
				  <li><a href="elements-carousel.html">Carousels &amp; Sliders</a></li>
				  <li><a href="elements-charts.html">Charts</a></li>
				  <li><a href="elements-container.html">Container</a></li>
				  <li><a href="elements-content-band.html">Content Band</a></li>
				  <li><a href="elements-dividers.html">Dividers & Gaps</a></li>
				  <li><a href="elements-featured-box.html">Featured Box</a></li>
				  <li><a href="elements-icons.html">Font Awesome Icons</a></li>
				  <li><a href="elements-frames.html">Frames</a></li>
				  <li><a href="elements-maps.html">Google Maps</a></li>
				  <li><a href="elements-media.html">Media</a></li>
				  <li><a href="elements-notification.html">Notification</a></li>
				  <li><a href="elements-person.html">Person</a></li>
				  <li><a href="elements-post-sliders.html">Posts Sliders</a></li>
				  <li><a href="elements-pricing.html">Pricing and Data Tables</a></li>
				  <li><a href="elements-sliders.html">Premium Sliders</a></li>
				  <li><a href="elements-progress-bar.html">Progress Bars</a></li>
				  <li><a href="elements-recent-posts.html">Recent Posts</a></li>
				  <li><a href="elements-shop.html">Shop Elements</a></li>
				  <li><a href="elements-tabs.html">Tabs</a></li>
				  <li><a href="elements-testimonials.html">Testimonials</a></li>
				  <li><a href="elements-works.html">Works</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Bootstrap</a>
				<ul class="sub">
				  <li><a href="typography-styles.html">Typography</a></li>
				  <li><a href="tables-styles.html">Tables</a></li>
				  <li><a href="forms-styles.html">Forms</a></li>
				  <li><a href="buttons-styles.html">Buttons</a></li>
				  <li><a href="tabs-styles.html">Tabs</a></li>
				  <li><a href="tooltips-styles.html">Tooltip</a></li>
				  <li><a href="accordions-styles.html">Accordions</a></li>
				</ul>
			  </li>
			</ul>
		  </nav>
		</div>
	  </div><!-- .primary -->
	  
	  <div class="span3">
		<div class="phone-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			  c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
			  M11.001,12H5V2h6V12z"/>
			</svg>
		  </a>
		</div><!-- .phone-header -->
		
		<div class="search-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </a>
		</div><!-- .search-header -->
	  </div>
	  
	  <div class="phone-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<span class="title">Call Us</span> <strong>+1 (777) 123 45 67</strong>
	  </div>
	  <div class="search-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<form name="search-form">
		  <input class="search-string" type="search" placeholder="Search here" name="search-string">
		  <button class="search-submit">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </button>
		</form>
	  </div>
	</div><!--.row -->
  </div>
</header><!-- .header -->

<div class="breadcrumb-box">
  <div class="container">
    <ul class="breadcrumb">
      <li><a href="index.html">Home</a> <span class="divider">/</span></li>
      <li><a href="#">Bootstrap</a> <span class="divider">/</span></li>
      <li class="active">Tooltips Styles</li>
    </ul>	
  </div>
</div><!-- .breadcrumb-box -->

<div id="main" class="page">
  <header class="page-header">
    <div class="container">
      <h1 class="title">Tooltips</h1>
    </div>	
  </header>
  
  <div class="container">
    <div class="row">
	  <article class="content span12">
		<h2>Examples</h2>
		<p>Inspired by the excellent jQuery.tipsy plugin written by Jason Frame; Tooltips are an updated version, which don't rely on images, use CSS3 for animations, and data-attributes for local title storage.</p>
		<p>For performance reasons, the tooltip and popover data-apis are opt in, meaning <strong>you must initialize them yourself</strong>.</p>
		<p>Hover over the links below to see tooltips:</p>
		<div class="bs-docs-example tooltip-demo">
		  <p class="muted" style="margin-bottom: 0;">Tight pants next level keffiyeh <a href="#" data-toggle="tooltip" title="Default tooltip">you probably</a> haven't heard of them. Photo booth beard raw denim letterpress vegan messenger bag stumptown. Farm-to-table seitan, mcsweeney's fixie sustainable quinoa 8-bit american apparel <a href="#" data-toggle="tooltip" title="Another tooltip">have a</a> terry richardson vinyl chambray. Beard stumptown, cardigans banh mi lomo thundercats. Tofu biodiesel williamsburg marfa, four loko mcsweeney's cleanse vegan chambray. A really ironic artisan <a href="#" data-toggle="tooltip" title="A much longer tooltip belongs right here to demonstrate the max-width we apply.">whatever keytar</a>, scenester farm-to-table banksy Austin <a href="#" data-toggle="tooltip" title="The last tip!">twitter handle</a> freegan cred raw denim single-origin coffee viral.
		  </p>
		</div>

		<br>
		<h3>Four directions</h3>
		<div class="bs-docs-example tooltip-demo">
		  <ul class="bs-docs-tooltip-examples">
			<li><a href="#" data-toggle="tooltip" data-placement="top" title="" data-original-title="Tooltip on top">Tooltip on top</a></li>
			<li><a href="#" data-toggle="tooltip" data-placement="right" title="Tooltip on right">Tooltip on right</a></li>
			<li><a href="#" data-toggle="tooltip" data-placement="bottom" title="Tooltip on bottom">Tooltip on bottom</a></li>
			<li><a href="#" data-toggle="tooltip" data-placement="left" title="Tooltip on left">Tooltip on left</a></li>
		  </ul>
		</div>

		<br>
		<h3>Tooltips in input groups</h3>
		<p>When using tooltips and popovers with the Bootstrap input groups, you'll have to set the <code>container</code> (documented below) option to avoid unwanted side effects.</p>

		<hr class="bs-docs-separator">


		<h2>Usage</h2>
		<p>Trigger the tooltip via JavaScript:</p>
		<pre class="prettyprint linenums"><ol class="linenums"><li class="L0"><span class="pln">$</span><span class="pun">(</span><span class="str">'#example'</span><span class="pun">).</span><span class="pln">tooltip</span><span class="pun">(</span><span class="pln">options</span><span class="pun">)</span></li></ol></pre>

		<br>
		<h3>Options</h3>
		<p>Options can be passed via data attributes or JavaScript. For data attributes, append the option name to <code>data-</code>, as in <code>data-animation=""</code>.</p>
		<table class="table table-bordered table-striped">
		  <thead>
		   <tr>
			 <th style="width: 100px;">Name</th>
			 <th style="width: 100px;">type</th>
			 <th style="width: 50px;">default</th>
			 <th>description</th>
		   </tr>
		  </thead>
		  <tbody>
		   <tr>
			 <td>animation</td>
			 <td>boolean</td>
			 <td>true</td>
			 <td>apply a css fade transition to the tooltip</td>
		   </tr>
		   <tr>
			 <td>html</td>
			 <td>boolean</td>
			 <td>false</td>
			 <td>Insert html into the tooltip. If false, jquery's <code>text</code> method will be used to insert content into the dom. Use text if you're worried about XSS attacks.</td>
		   </tr>
		   <tr>
			 <td>placement</td>
			 <td>string | function</td>
			 <td>'top'</td>
			 <td>how to position the tooltip - top | bottom | left | right</td>
		   </tr>
		   <tr>
			 <td>selector</td>
			 <td>string</td>
			 <td>false</td>
			 <td>If a selector is provided, tooltip objects will be delegated to the specified targets.</td>
		   </tr>
		   <tr>
			 <td>title</td>
			 <td>string | function</td>
			 <td>''</td>
			 <td>default title value if `title` tag isn't present</td>
		   </tr>
		   <tr>
			 <td>trigger</td>
			 <td>string</td>
			 <td>'hover focus'</td>
			 <td>how tooltip is triggered - click | hover | focus | manual. Note you case pass trigger mutliple, space seperated, trigger types.</td>
		   </tr>
		   <tr>
			 <td>delay</td>
			 <td>number | object</td>
			 <td>0</td>
			 <td>
			  <p>delay showing and hiding the tooltip (ms) - does not apply to manual trigger type</p>
			  <p>If a number is supplied, delay is applied to both hide/show</p>
			  <p>Object structure is: <code>delay: { show: 500, hide: 100 }</code></p>
			 </td>
		   </tr>
		   <tr>
			 <td>container</td>
			 <td>string | false</td>
			 <td>false</td>
			 <td>
			  <p>Appends the tooltip to a specific element <code>container: 'body'</code></p>
			 </td>
		   </tr>
		  </tbody>
		</table>
	  
        <div class="alert">
		  <i class="fa fa-volume-up alert-icon"></i>
		  <button type="button" class="close" data-dismiss="alert">&times;</button>
		  Proin vel ultrices erat. Etiam et enim libero. Duis sollicitudin dignissim. Duis suscipit  faucibus. Duis tristique feugiat velit quis lobortis. Phasellus dignissim mollis massa, sit amet accumsan urna euismod quis. Tiam mollis volutpat odio, id euismod justo grada. Integer volutpat scelerisque massa sit amet tristique. Nam id fringilla turpis. Donec faucibus fringilla dui, sit amet eleifend augue luctus id.
        </div>
		
		<div class="alert alert-black">
		  <i class="fa fa-volume-up alert-icon"></i>
		  <button type="button" class="close" data-dismiss="alert">&times;</button>
          Proin vel ultrices erat. Etiam et enim libero. Duis sollicitudin dignissim. Duis suscipit  faucibus. Duis tristique feugiat velit quis lobortis. Phasellus dignissim mollis massa, sit amet accumsan urna euismod quis. Tiam mollis volutpat odio, id euismod justo grada. Integer volutpat scelerisque massa sit amet tristique. Nam id fringilla turpis. Donec faucibus fringilla dui, sit amet eleifend augue luctus id.
        </div>
		
		<div class="alert alert-error">
		  <i class="fa fa-volume-up alert-icon"></i>
		  <button type="button" class="close" data-dismiss="alert">&times;</button>
          Proin vel ultrices erat. Etiam et enim libero. Duis sollicitudin dignissim. Duis suscipit  faucibus. Duis tristique feugiat velit quis lobortis. Phasellus dignissim mollis massa, sit amet accumsan urna euismod quis. Tiam mollis volutpat odio, id euismod justo grada. Integer volutpat scelerisque massa sit amet tristique. Nam id fringilla turpis. Donec faucibus fringilla dui, sit amet eleifend augue luctus id.
        </div>
		
		<div class="alert alert-success">
		  <i class="fa fa-volume-up alert-icon"></i>
		  <button type="button" class="close" data-dismiss="alert">&times;</button>
          Proin vel ultrices erat. Etiam et enim libero. Duis sollicitudin dignissim. Duis suscipit  faucibus. Duis tristique feugiat velit quis lobortis. Phasellus dignissim mollis massa, sit amet accumsan urna euismod quis. Tiam mollis volutpat odio, id euismod justo grada. Integer volutpat scelerisque massa sit amet tristique. Nam id fringilla turpis. Donec faucibus fringilla dui, sit amet eleifend augue luctus id.
        </div>
		
		<div class="alert alert-info">
		  <i class="fa fa-volume-up alert-icon"></i>
		  <button type="button" class="close" data-dismiss="alert">&times;</button>
          Proin vel ultrices erat. Etiam et enim libero. Duis sollicitudin dignissim. Duis suscipit  faucibus. Duis tristique feugiat velit quis lobortis. Phasellus dignissim mollis massa, sit amet accumsan urna euismod quis. Tiam mollis volutpat odio, id euismod justo grada. Integer volutpat scelerisque massa sit amet tristique. Nam id fringilla turpis. Donec faucibus fringilla dui, sit amet eleifend augue luctus id.
        </div>

		<br>
		<h3>Markup</h3>
        <pre class="prettyprint linenums"><ol class="linenums"><li class="L0"><span class="tag">&lt;a</span><span class="pln"> </span><span class="atn">href</span><span class="pun">=</span><span class="atv">"#"</span><span class="pln"> </span><span class="atn">data-toggle</span><span class="pun">=</span><span class="atv">"tooltip"</span><span class="pln"> </span><span class="atn">title</span><span class="pun">=</span><span class="atv">"first tooltip"</span><span class="tag">&gt;</span><span class="pln">hover over me</span><span class="tag">&lt;/a&gt;</span></li></ol></pre>

		<br>
		<h3>Methods</h3>
		<h4>$().tooltip(options)</h4>
		<p>Attaches a tooltip handler to an element collection.</p>
		<h4>.tooltip('show')</h4>
		<p>Reveals an element's tooltip.</p>
		<pre class="prettyprint linenums"><ol class="linenums"><li class="L0"><span class="pln">$</span><span class="pun">(</span><span class="str">'#element'</span><span class="pun">).</span><span class="pln">tooltip</span><span class="pun">(</span><span class="str">'show'</span><span class="pun">)</span></li></ol></pre>
		<h4>.tooltip('hide')</h4>
		<p>Hides an element's tooltip.</p>
		<pre class="prettyprint linenums"><ol class="linenums"><li class="L0"><span class="pln">$</span><span class="pun">(</span><span class="str">'#element'</span><span class="pun">).</span><span class="pln">tooltip</span><span class="pun">(</span><span class="str">'hide'</span><span class="pun">)</span></li></ol></pre>
		<h4>.tooltip('toggle')</h4>
		<p>Toggles an element's tooltip.</p>
		<pre class="prettyprint linenums"><ol class="linenums"><li class="L0"><span class="pln">$</span><span class="pun">(</span><span class="str">'#element'</span><span class="pun">).</span><span class="pln">tooltip</span><span class="pun">(</span><span class="str">'toggle'</span><span class="pun">)</span></li></ol></pre>
		<h4>.tooltip('destroy')</h4>
		<p>Hides and destroys an element's tooltip.</p>
		<pre class="prettyprint linenums"><ol class="linenums"><li class="L0"><span class="pln">$</span><span class="pun">(</span><span class="str">'#element'</span><span class="pun">).</span><span class="pln">tooltip</span><span class="pun">(</span><span class="str">'destroy'</span><span class="pun">)</span></li></ol></pre>
	  
		<div class="clearfix"></div>
	  </article><!-- .content -->
    </div>
  </div>
</div><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="span3 social">
          <h3>Follow Us</h3>
          <p>Follow us in social media</p>
          <a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a>
        </div>
        <div class="span3 newsletter">
          <h3>Newsletter</h3>
          <p>Sign up for newsletter</p>
          <form>
            <input class="input-block-level" type="email">
            <button class="submit"><i class="fa fa-arrow-circle-o-right"></i></button>
          </form>
        </div>
        <div class="span3 nav-box">
          <h3>Information</h3>
		  <nav>
			<ul>
			  <li><a href="#">About us</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">Terms & Condotions</a></li>
			  <li><a href="#">Secure payment</a></li>
			</ul>
		  </nav>
        </div>
        <div class="span3 nav-box">
          <h3>My account</h3>
		  <nav>
			<ul>
			  <li><a href="#">My account</a></li>
			  <li><a href="#">Order History</a></li>
			  <li><a href="#">Wish List</a></li>
			  <li><a href="#">Newsletter</a></li>
			</ul>
		  </nav>
        </div>
      </div>
    </div>
  </div><!-- .footer-top -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="span3 copyright">Copyright &copy; ItemBridge Inc., 2013</div>
        <div class="span3 phone">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#c6c6c6" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			   c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
				M11.001,12H5V2h6V12z"/>
			</svg>
		  </div>
          <strong class="title">Call Us:</strong> +1 (877) 123-45-67 <br>
          <strong>or</strong> +1 (777) 123-45-67
        </div>
        <div class="span3 address">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <g>
				<g>
				  <path fill="#c6c6c6" d="M8,16c-0.256,0-0.512-0.098-0.707-0.293C7.077,15.491,2,10.364,2,6c0-3.309,2.691-6,6-6
					c3.309,0,6,2.691,6,6c0,4.364-5.077,9.491-5.293,9.707C8.512,15.902,8.256,16,8,16z M8,2C5.795,2,4,3.794,4,6
					c0,2.496,2.459,5.799,4,7.536c1.541-1.737,4-5.04,4-7.536C12.001,3.794,10.206,2,8,2z"/>
				</g>
				<g>
				  <circle fill="#c6c6c6" cx="8.001" cy="6" r="2"/>
				</g>
			  </g>
			</svg>
		  </div>
          49 Archdale, 2B Charleston 5655, Excel Tower<br> OPG Rpad, 4538FH
        </div>
        <div class="span3">
          <a href="#" class="up pull-right"><i class="icon-arrow-up icon-white"></i></a>
        </div>
      </div>
    </div>
  </div><!-- .footer-bottom -->
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>