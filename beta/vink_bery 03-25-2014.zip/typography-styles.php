<!DOCTYPE html>
<html>
<head>
  <title>Typography and Basic Styles \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body>
<div class="page-box">
<div class="page-box-content">

<header class="header header-two">
  <div class="container">
	<div class="row">
	  <div class="span2 logo-box">
		<a href="index.html" class="logo">
		  <img src="img/logo.svg" class="logo-img" alt="">
		</a>
	  </div>
	  <div class="span7 primary">
		<div class="navbar">
		  <a class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".primary .nav-collapse">
			<span class="text">Menu</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </a>
		  <nav class="nav-collapse collapse">
			<ul class="nav">
			  <li class="parent">
				<a href="index.html">Home</a>
				<ul class="sub">
				  <li><a href="index.html">Creative</a></li>
				  <li><a href="home-2.html">Paralax</a></li>
				  <li><a href="home-3.html">Simple</a></li>
				  <li><a href="home-4.html">Business</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Pages</a>
				<ul class="sub">
				  <li><a href="sidebar-blocks.html">All sidebar blocks</a></li>
				  <li><a href="full-width.html">Full Width</a></li>
				  <li><a href="left-sidebar.html">Left Sidebar</a></li>
				  <li><a href="right-sidebar.html">Right Sidebar</a></li>
				  <li><a href="about-us.html">About Us</a></li>
				  <li><a href="contact.html">Contact Us</a></li>
				  <li><a href="blog-list.html">Blog List</a></li>
				  <li><a href="blog-view.html">Blog Post View</a></li>
				  <li><a href="404.html">Page 404</a></li>
				  <li><a href="404-2.html">Page 404 (2)</a></li>
				  <li class="parent">
					<a href="#">Portfolio</a>
					<ul class="sub">
					  <li><a href="portfolio-1.html">Portfolio (1 column)</a></li>
					  <li><a href="portfolio-2.html">Portfolio (2 column)</a></li>
					  <li><a href="portfolio-3.html">Portfolio (3 column)</a></li>
					  <li><a href="portfolio-4.html">Portfolio (4 column)</a></li>
					  <li><a href="portfolio-slider.html">Portfolio (Slider)</a></li>
					  <li><a href="portfolio-single.html">Single Project</a></li>
					</ul>
				  </li>
				  <li><a href="gallery-modern.html">Modern Gallery</a></li>
				  <li class="parent">
					<a href="#">Gallery</a>
					<ul class="sub">
					  <li><a href="gallery-1.html">Gallery (1 column)</a></li>
					  <li><a href="gallery-2.html">Gallery (2 column)</a></li>
					  <li><a href="gallery-3.html">Gallery (3 column)</a></li>
					  <li><a href="gallery-4.html">Gallery (4 column)</a></li>
					</ul>
				  </li>
				  <li><a href="pricing.html">Pricing</a></li>
				  <li><a href="team.html">Team</a></li>
				  <li><a href="faq.html">FAQ</a></li>
				  <li><a href="services.html">Services</a></li>
				  <li><a href="careers.html">Careers</a></li>
				  <li><a href="coming-soon.html">Coming Soon</a></li>
				  <li><a href="under-construction.html">Under Construction</a></li>
				  <li><a href="sitemap.html">Sitemap</a></li>
				  <li class="parent">
					<a href="#">Newsletter</a>
					<ul class="sub">
					  <li><a href="newsletter-big-intro.html">Newsletter Big Intro</a></li>
					  <li><a href="newsletter-big-portfolio.html">Newsletter Big Portfolio</a></li>
					  <li><a href="newsletter-columns.html">Newsletter Columns</a></li>
					  <li><a href="newsletter-info.html">Newsletter Info</a></li>
					  <li><a href="newsletter-plan.html">Newsletter Plan</a></li>
					  <li><a href="newsletter-portfolio.html">Newsletter Portfolio</a></li>
					  <li><a href="newsletter-product-list.html">Newsletter Product List</a></li>
					  <li><a href="newsletter-story.html">Newsletter Story</a></li>
					</ul>
				  </li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="shop.html">Shop</a>
				<ul class="sub">
				  <li><a href="catalog-grid.html">Catalog (Grid)</a></li>
				  <li><a href="catalog-list.html">Catalog (List)</a></li>
				  <li><a href="product-view.html">Product View</a></li>
				  <li><a href="product-view-variants.html">Product View (Variants)</a></li>
				  <li><a href="cart.html">Shopping Cart</a></li>
				  <li><a href="checkout.html">Proceed to Checkout</a></li>
				  <li><a href="compare.html">Compare Products</a></li>
				  <li><a href="login.html">Login</a></li>
				</ul>
			  </li>
			  <li class="parent megamenu">
				<a href="#">Mega Menu</a>
				<ul class="sub">
				  <li class="promo-block box">
					<a href="#" class="big-image">
					  <img src="img/content/megamenu-big.png" width="240" height="434" alt="">
					</a>
				  </li><!-- .box.promo-block -->
				  
				  <li class="box first">
					<h6 class="title">Savant Apple Integration</h6>
					<ul>
					  <li><a href="#">iPad, iPod touch, iPhone & Mac Control</a></li>
					  <li><a href="#">iPod touch Remote Control</a></li>
					  <li><a href="#">Savant Host (Mac Mini)</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Audio/Video Control</h6>
					<ul>
					  <li><a href="#">Distributed Audio & Video</a></li>
					  <li><a href="#">Matrix Switchers</a></li>
					  <li><a href="#">Audio/Video Processing</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				</ul><!-- .sub -->
			  </li>
			  <li class="parent">
				<a href="#">Elements</a>
				<ul class="sub">
				  <li><a href="elements-accordions.html">Accordions &amp; Toggles</a></li>
				  <li><a href="elements-animations.html">Animations</a></li>
				  <li><a href="elements-buttons.html">Buttons &amp; Social Icons</a></li>
				  <li><a href="elements-carousel.html">Carousels &amp; Sliders</a></li>
				  <li><a href="elements-charts.html">Charts</a></li>
				  <li><a href="elements-container.html">Container</a></li>
				  <li><a href="elements-content-band.html">Content Band</a></li>
				  <li><a href="elements-dividers.html">Dividers & Gaps</a></li>
				  <li><a href="elements-featured-box.html">Featured Box</a></li>
				  <li><a href="elements-icons.html">Font Awesome Icons</a></li>
				  <li><a href="elements-frames.html">Frames</a></li>
				  <li><a href="elements-maps.html">Google Maps</a></li>
				  <li><a href="elements-media.html">Media</a></li>
				  <li><a href="elements-notification.html">Notification</a></li>
				  <li><a href="elements-person.html">Person</a></li>
				  <li><a href="elements-post-sliders.html">Posts Sliders</a></li>
				  <li><a href="elements-pricing.html">Pricing and Data Tables</a></li>
				  <li><a href="elements-sliders.html">Premium Sliders</a></li>
				  <li><a href="elements-progress-bar.html">Progress Bars</a></li>
				  <li><a href="elements-recent-posts.html">Recent Posts</a></li>
				  <li><a href="elements-shop.html">Shop Elements</a></li>
				  <li><a href="elements-tabs.html">Tabs</a></li>
				  <li><a href="elements-testimonials.html">Testimonials</a></li>
				  <li><a href="elements-works.html">Works</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Bootstrap</a>
				<ul class="sub">
				  <li><a href="typography-styles.html">Typography</a></li>
				  <li><a href="tables-styles.html">Tables</a></li>
				  <li><a href="forms-styles.html">Forms</a></li>
				  <li><a href="buttons-styles.html">Buttons</a></li>
				  <li><a href="tabs-styles.html">Tabs</a></li>
				  <li><a href="tooltips-styles.html">Tooltip</a></li>
				  <li><a href="accordions-styles.html">Accordions</a></li>
				</ul>
			  </li>
			</ul>
		  </nav>
		</div>
	  </div><!-- .primary -->
	  
	  <div class="span3">
		<div class="phone-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			  c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
			  M11.001,12H5V2h6V12z"/>
			</svg>
		  </a>
		</div><!-- .phone-header -->
		
		<div class="search-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </a>
		</div><!-- .search-header -->
	  </div>
	  
	  <div class="phone-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<span class="title">Call Us</span> <strong>+1 (777) 123 45 67</strong>
	  </div>
	  <div class="search-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<form name="search-form">
		  <input class="search-string" type="search" placeholder="Search here" name="search-string">
		  <button class="search-submit">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </button>
		</form>
	  </div>
	</div><!--.row -->
  </div>
</header><!-- .header -->

<div class="breadcrumb-box">
  <div class="container">
    <ul class="breadcrumb">
      <li><a href="index.html">Home</a> <span class="divider">/</span></li>
      <li><a href="#">Bootstrap</a> <span class="divider">/</span></li>
      <li class="active">Typography and Basic Styles</li>
    </ul>	
  </div>
</div><!-- .breadcrumb-box -->

<div id="main" class="page">
  <header class="page-header">
    <div class="container">
      <h1 class="title">Typography and Basic Styles</h1>
    </div>	
  </header>
  <div class="container">
    <div class="row">
	  <article class="content span12">
		<h2>Headings</h2>
		<p>All HTML headings, <code>&lt;h1&gt;</code> through <code>&lt;h6&gt;</code> are available.</p>
		<div class="bs-docs-example">
		  <h1>h1. Heading 1</h1>
		  <h2>h2. Heading 2</h2>
		  <h3>h3. Heading 3</h3>
		  <h4>h4. Heading 4</h4>
		  <h5>h5. Heading 5</h5>
		  <h6>h6. Heading 6</h6>
		</div>
		<br><br>
		<h2>Body copy</h2>
		<p>Bootstrap's global default <code>font-size</code> is <strong>14px</strong>, with a <code>line-height</code> of <strong>20px</strong>. This is applied to the <code>&lt;body&gt;</code> and all paragraphs. In addition, <code>&lt;p&gt;</code> (paragraphs) receive a bottom margin of half their line-height (10px by default).</p>
		<div class="bs-docs-example">
		  <p>Nullam quis risus eget urna mollis ornare vel eu leo. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam id dolor id nibh ultricies vehicula.</p>
		  <p>Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec ullamcorper nulla non metus auctor fringilla. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Donec ullamcorper nulla non metus auctor fringilla.</p>
		  <p>Maecenas sed diam eget risus varius blandit sit amet non magna. Donec id elit non mi porta gravida at eget metus. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.</p>
		</div>
		<pre class="prettyprint">&lt;p&gt;...&lt;/p&gt;</pre>
		<br><br>

		<h3>Lead body copy</h3>
		<p>Make a paragraph stand out by adding <code>.lead</code>.</p>
		<div class="bs-docs-example">
		  <p class="lead">Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Duis mollis, est non commodo luctus.</p>
		</div>
		<pre class="prettyprint">&lt;p class="lead"&gt;...&lt;/p&gt;</pre>
		<br><br>

		<h3>Built with Less</h3>
		<p>The typographic scale is based on two LESS variables in <strong>variables.less</strong>: <code>@baseFontSize</code> and <code>@baseLineHeight</code>. The first is the base font-size used throughout and the second is the base line-height. We use those variables and some simple math to create the margins, paddings, and line-heights of all our type and more. Customize them and Bootstrap adapts.</p>

		<hr class="bs-docs-separator">
	    
		<h2>Emphasis</h2>
		<p>Make use of HTML's default emphasis tags with lightweight styles.</p>
		<p><code>&lt;small&gt;</code></p>
		<p>For de-emphasizing inline or blocks of text, <small>use the small tag.</small></p>
		<div class="bs-docs-example">
		  <p><small>This line of text is meant to be treated as fine print.</small></p>
		</div>
<pre class="prettyprint">
&lt;p&gt;
  &lt;small&gt;This line of text is meant to be treated as fine print.&lt;/small&gt;
&lt;/p&gt;
</pre>
		<br>
		<br>

		<h3>Bold</h3>
		<p>For emphasizing a snippet of text with a heavier font-weight.</p>
		<div class="bs-docs-example">
		  <p>The following snippet of text is <strong>rendered as bold text</strong>.</p>
		</div>
		<pre class="prettyprint">&lt;strong&gt;rendered as bold text&lt;/strong&gt;</pre>
		<br><br>

		<h3>Italics</h3>
		<p>For emphasizing a snippet of text with italics.</p>
		<div class="bs-docs-example">
		  <p>The following snippet of text is <em>rendered as italicized text</em>.</p>
		</div>
		<pre class="prettyprint">&lt;em&gt;rendered as italicized text&lt;/em&gt;</pre>
		<p><span class="label label-info">Heads up!</span> Feel free to use <code>&lt;b&gt;</code> and <code>&lt;i&gt;</code> in HTML5. <code>&lt;b&gt;</code> is meant to highlight words or phrases without conveying additional importance while <code>&lt;i&gt;</code> is mostly for voice, technical terms, etc.</p>
		<br><br>

		<h3>Alignment classes</h3>
		<p>Easily realign text to components with text alignment classes.</p>
		<div class="bs-docs-example">
		  <p class="text-left">Left aligned text.</p>
		  <p class="text-center">Center aligned text.</p>
		  <p class="text-right">Right aligned text.</p>
		</div>
<pre class="prettyprint linenums">
&lt;p class="text-left"&gt;Left aligned text.&lt;/p&gt;
&lt;p class="text-center"&gt;Center aligned text.&lt;/p&gt;
&lt;p class="text-right"&gt;Right aligned text.&lt;/p&gt;
</pre><br><br>

		<h3>Emphasis classes</h3>
		<p>Convey meaning through color with a handful of emphasis utility classes.</p>
		<div class="bs-docs-example">
		  <p class="muted">Fusce dapibus, tellus ac cursus commodo, tortor mauris nibh.</p>
		  <p class="text-warning">Etiam porta sem malesuada magna mollis euismod.</p>
		  <p class="text-error">Donec ullamcorper nulla non metus auctor fringilla.</p>
		  <p class="text-info">Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis.</p>
		  <p class="text-success">Duis mollis, est non commodo luctus, nisi erat porttitor ligula.</p>
		</div>
<pre class="prettyprint linenums">
&lt;p class="muted"&gt;Fusce dapibus, tellus ac cursus commodo, tortor mauris nibh.&lt;/p&gt;
&lt;p class="text-warning"&gt;Etiam porta sem malesuada magna mollis euismod.&lt;/p&gt;
&lt;p class="text-error"&gt;Donec ullamcorper nulla non metus auctor fringilla.&lt;/p&gt;
&lt;p class="text-info"&gt;Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis.&lt;/p&gt;
&lt;p class="text-success"&gt;Duis mollis, est non commodo luctus, nisi erat porttitor ligula.&lt;/p&gt;
</pre>

        <hr class="bs-docs-separator">
		<br>
	  
		<h2>Abbreviations</h2>
		<p>Stylized implementation of HTML's <code>&lt;abbr&gt;</code> element for abbreviations and acronyms to show the expanded version on hover. Abbreviations with a <code>title</code> attribute have a light dotted bottom border and a help cursor on hover, providing additional context on hover.</p>
		<p><code>&lt;abbr&gt;</code></p>
		<p>For expanded text on long hover of an abbreviation, include the <code>title</code> attribute.</p>
		<div class="bs-docs-example">
		  <p>An abbreviation of the word attribute is <abbr title="attribute">attr</abbr>.</p>
		</div>
		<pre class="prettyprint">&lt;abbr title="attribute"&gt;attr&lt;/abbr&gt;</pre>

		<h3><code>&lt;abbr class="initialism"&gt;</code></h3>
		<p>Add <code>.initialism</code> to an abbreviation for a slightly smaller font-size.</p>
		<div class="bs-docs-example">
		  <p><abbr title="HyperText Markup Language" class="initialism">HTML</abbr> is the best thing since sliced bread.</p>
		</div>
		<pre class="prettyprint">&lt;abbr title="HyperText Markup Language" class="initialism"&gt;HTML&lt;/abbr&gt;</pre>

		<hr class="bs-docs-separator">
		<br>
	  
		<h2 id="addresses">Addresses</h2>
		<p>Present contact information for the nearest ancestor or the entire body of work.</p>
		<p><code>&lt;address&gt;</code></p>
		<p>Preserve formatting by ending all lines with <code>&lt;br&gt;</code>.</p>
		<div class="bs-docs-example">
		  <address>
			<strong>Twitter, Inc.</strong><br>
			795 Folsom Ave, Suite 600<br>
			San Francisco, CA 94107<br>
			<abbr title="Phone">P:</abbr> (123) 456-7890
		  </address>
		  <address>
			<strong>Full Name</strong><br>
			<a href="mailto:#">first.last@example.com</a>
		  </address>
		</div>
<pre class="prettyprint linenums">
&lt;address&gt;
  &lt;strong&gt;Twitter, Inc.&lt;/strong&gt;&lt;br&gt;
  795 Folsom Ave, Suite 600&lt;br&gt;
  San Francisco, CA 94107&lt;br&gt;
  &lt;abbr title="Phone"&gt;P:&lt;/abbr&gt; (123) 456-7890
&lt;/address&gt;

&lt;address&gt;
  &lt;strong&gt;Full Name&lt;/strong&gt;&lt;br&gt;
  &lt;a href="mailto:#"&gt;first.last@example.com&lt;/a&gt;
&lt;/address&gt;
</pre>

        <hr class="bs-docs-separator">
		<br>

		<h2>Blockquotes</h2>
		<p>For quoting blocks of content from another source within your document.</p>

		<br>
		<h3>Default blockquote</h3>
		<p>Wrap <code>&lt;blockquote&gt;</code> around any <abbr title="HyperText Markup Language">HTML</abbr> as the quote. For straight quotes we recommend a <code>&lt;p&gt;</code>.</p>
		<div class="bs-docs-example">
		  <blockquote>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
		  </blockquote>
		</div>
<pre class="prettyprint linenums">
&lt;blockquote&gt;
  &lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.&lt;/p&gt;
&lt;/blockquote&gt;
</pre>

		<br>
		<h3>Blockquote options</h3>
		<p>Style and content changes for simple variations on a standard blockquote.</p>

		<h4>Naming a source</h4>
		<p>Add <code>&lt;small&gt;</code> tag for identifying the source. Wrap the name of the source work in <code>&lt;cite&gt;</code>.</p>
		<div class="bs-docs-example">
		  <blockquote>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
			<small>Someone famous in <cite title="Source Title">Source Title</cite></small>
		  </blockquote>
		</div>
<pre class="prettyprint linenums">
&lt;blockquote&gt;
  &lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.&lt;/p&gt;
  &lt;small&gt;Someone famous &lt;cite title="Source Title"&gt;Source Title&lt;/cite&gt;&lt;/small&gt;
&lt;/blockquote&gt;
</pre>

		<h4>Alternate displays</h4>
		<p>Use <code>.pull-right</code> for a floated, right-aligned blockquote.</p>
		<div class="bs-docs-example" style="overflow: hidden;">
		  <blockquote class="pull-right">
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
			<small>Someone famous in <cite title="Source Title">Source Title</cite></small>
		  </blockquote>
		</div>
<pre class="prettyprint linenums">
&lt;blockquote class="pull-right"&gt;
  ...
&lt;/blockquote&gt;
</pre>

        <hr class="bs-docs-separator">
		<br>
  
		<h2>Lists</h2>

		<h3>Unordered</h3>
		<p>A list of items in which the order does <em>not</em> explicitly matter.</p>
		<div class="bs-docs-example">
		  <ul>
			<li>Lorem ipsum dolor sit amet</li>
			<li>Consectetur adipiscing elit</li>
			<li>Integer molestie lorem at massa</li>
			<li>Facilisis in pretium nisl aliquet</li>
			<li>Nulla volutpat aliquam velit
			  <ul>
				<li>Phasellus iaculis neque</li>
				<li>Purus sodales ultricies</li>
				<li>Vestibulum laoreet porttitor sem</li>
				<li>Ac tristique libero volutpat at</li>
			  </ul>
			</li>
			<li>Faucibus porta lacus fringilla vel</li>
			<li>Aenean sit amet erat nunc</li>
			<li>Eget porttitor lorem</li>
		  </ul>
		</div>
<pre class="prettyprint linenums">
&lt;ul&gt;
  &lt;li&gt;...&lt;/li&gt;
&lt;/ul&gt;
</pre>

		<br>
		<h3>Ordered</h3>
		<p>A list of items in which the order <em>does</em> explicitly matter.</p>
		<div class="bs-docs-example">
		  <ol>
			<li>Lorem ipsum dolor sit amet</li>
			<li>Consectetur adipiscing elit</li>
			<li>Integer molestie lorem at massa</li>
			<li>Facilisis in pretium nisl aliquet</li>
			<li>Nulla volutpat aliquam velit</li>
			<li>Faucibus porta lacus fringilla vel</li>
			<li>Aenean sit amet erat nunc</li>
			<li>Eget porttitor lorem</li>
		  </ol>
		</div>
<pre class="prettyprint linenums">
&lt;ol&gt;
  &lt;li&gt;...&lt;/li&gt;
&lt;/ol&gt;
</pre>

		<br>
		<h3>Unstyled</h3>
		<p>Remove the default <code>list-style</code> and left padding on list items (immediate children only).</p>
		<div class="bs-docs-example">
		  <ul class="unstyled">
			<li>Lorem ipsum dolor sit amet</li>
			<li>Consectetur adipiscing elit</li>
			<li>Integer molestie lorem at massa</li>
			<li>Facilisis in pretium nisl aliquet</li>
			<li>Nulla volutpat aliquam velit
		  <ul>
			<li>Phasellus iaculis neque</li>
			<li>Purus sodales ultricies</li>
			<li>Vestibulum laoreet porttitor sem</li>
			<li>Ac tristique libero volutpat at</li>
		  </ul>
			</li>
			<li>Faucibus porta lacus fringilla vel</li>
			<li>Aenean sit amet erat nunc</li>
			<li>Eget porttitor lorem</li>
		  </ul>
		</div>
<pre class="prettyprint linenums">
&lt;ul class="unstyled"&gt;
  &lt;li&gt;...&lt;/li&gt;
&lt;/ul&gt;
</pre>

		<br>
		<h3>Inline</h3>
		<p>Place all list items on a single line with <code>inline-block</code> and some light padding.</p>
		<div class="bs-docs-example">
		  <ul class="inline">
			<li>Lorem ipsum</li>
			<li>Phasellus iaculis</li>
			<li>Nulla volutpat</li>
		  </ul>
		</div>
<pre class="prettyprint linenums">
&lt;ul class="inline"&gt;
  &lt;li&gt;...&lt;/li&gt;
&lt;/ul&gt;
</pre>

		<br>
		<h3>Description</h3>
		<p>A list of terms with their associated descriptions.</p>
		<div class="bs-docs-example">
		  <dl>
			<dt>Description lists</dt>
			<dd>A description list is perfect for defining terms.</dd>
			<dt>Euismod</dt>
			<dd>Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.</dd>
			<dd>Donec id elit non mi porta gravida at eget metus.</dd>
			<dt>Malesuada porta</dt>
			<dd>Etiam porta sem malesuada magna mollis euismod.</dd>
		  </dl>
		</div>
<pre class="prettyprint linenums">
&lt;dl&gt;
  &lt;dt&gt;...&lt;/dt&gt;
  &lt;dd&gt;...&lt;/dd&gt;
&lt;/dl&gt;
</pre>

		<br>
		<h4>Horizontal description</h4>
		<p>Make terms and descriptions in <code>&lt;dl&gt;</code> line up side-by-side.</p>
		<div class="bs-docs-example">
		  <dl class="dl-horizontal">
			<dt>Description lists</dt>
			<dd>A description list is perfect for defining terms.</dd>
			<dt>Euismod</dt>
			<dd>Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.</dd>
			<dd>Donec id elit non mi porta gravida at eget metus.</dd>
			<dt>Malesuada porta</dt>
			<dd>Etiam porta sem malesuada magna mollis euismod.</dd>
			<dt>Felis euismod semper eget lacinia</dt>
			<dd>Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</dd>
		  </dl>
		</div>
<pre class="prettyprint linenums">
&lt;dl class="dl-horizontal"&gt;
  &lt;dt&gt;...&lt;/dt&gt;
  &lt;dd&gt;...&lt;/dd&gt;
&lt;/dl&gt;
</pre>
		<p>
		  <span class="label label-info">Heads up!</span>
		  Horizontal description lists will truncate terms that are too long to fit in the left column fix <code>text-overflow</code>. In narrower viewports, they will change to the default stacked layout.
		</p>
		<hr>
		<br>
	
        <header class="page-header">
		  <h1>Code</h1>
		</header>

		<h2>Inline</h2>
		<p>Wrap inline snippets of code with <code>&lt;code&gt;</code>.</p>
<div class="bs-docs-example">
  For example, <code>&lt;section&gt;</code> should be wrapped as inline.
</div>
<pre class="prettyprint linenums">
For example, &lt;code&gt;&amp;lt;section&amp;gt;&lt;/code&gt; should be wrapped as inline.
</pre>

		<br>
		<h2>Basic block</h2>
		<p>Use <code>&lt;pre&gt;</code> for multiple lines of code. Be sure to escape any angle brackets in the code for proper rendering.</p>
<div class="bs-docs-example">
  <pre>&lt;p&gt;Sample text here...&lt;/p&gt;</pre>
</div>
<pre class="prettyprint linenums" style="margin-bottom: 9px;">
&lt;pre&gt;
  &amp;lt;p&amp;gt;Sample text here...&amp;lt;/p&amp;gt;
&lt;/pre&gt;
</pre>
		<p><span class="label label-info">Heads up!</span> Be sure to keep code within <code>&lt;pre&gt;</code> tags as close to the left as possible; it will render all tabs.</p>
		<p>You may optionally add the <code>.pre-scrollable</code> class which will set a max-height of 350px and provide a y-axis scrollbar.</p>
	  
		<hr>
		<br>

		<div class="page-header">
          <h1>Images</h1>
        </div>
		<p>Add classes to an <code>&lt;img&gt;</code> element to easily style images in any project.</p>
        <div class="bs-docs-example bs-docs-example-images">
		  <img class="img-rounded" src="http://placehold.it/140x140" alt="" title="">
		  <img class="img-circle" src="http://placehold.it/140x140" alt="" title="">
		  <img class="img-polaroid" src="http://placehold.it/140x140" alt="" title="">
        </div>
<pre class="prettyprint linenums">
&lt;img src="..." class="img-rounded"&gt;
&lt;img src="..." class="img-circle"&gt;
&lt;img src="..." class="img-polaroid"&gt;
</pre>
        <p><span class="label label-info">Heads up!</span> <code>.img-rounded</code> and <code>.img-circle</code> do not work in IE7-8 due to lack of <code>border-radius</code> support.</p>
		<hr>
		<br>
  
		<h1>Icons</h1>
		
		<h2>The complete set of 369 icons in Font Awesome 4.0.3</h2>
	  
		<h3>11 New Icons in 4.0</h3>
	  
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-rub"></i> fa-rub</div>
		  <div class="span3"><i class="fa fa-ruble"></i> fa-ruble <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-rouble"></i> fa-rouble <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-pagelines"></i> fa-pagelines</div>
		  <div class="span3"><i class="fa fa-stack-exchange"></i> fa-stack-exchange</div>
		  <div class="span3"><i class="fa fa-arrow-circle-o-right"></i> fa-arrow-circle-o-right</div>
		  <div class="span3"><i class="fa fa-arrow-circle-o-left"></i> fa-arrow-circle-o-left</div>
		  <div class="span3"><i class="fa fa-caret-square-o-left"></i> fa-caret-square-o-left</div>
		  <div class="span3"><i class="fa fa-toggle-left"></i> fa-toggle-left <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-dot-circle-o"></i> fa-dot-circle-o</div>
		  <div class="span3"><i class="fa fa-wheelchair"></i> fa-wheelchair</div>
		  <div class="span3"><i class="fa fa-vimeo-square"></i> fa-vimeo-square</div>
		  <div class="span3"><i class="fa fa-try"></i> fa-try</div>
		  <div class="span3"><i class="fa fa-turkish-lira"></i> fa-turkish-lira <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-plus-square-o"></i> fa-plus-square-o</div>
		</div>
		<br><br>
	  
		<h3>Web Application Icons</h3>
	  
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-adjust"></i> fa-adjust</div>
		  <div class="span3"><i class="fa fa-anchor"></i> fa-anchor</div>
		  <div class="span3"><i class="fa fa-archive"></i> fa-archive</div>
		  <div class="span3"><i class="fa fa-arrows"></i> fa-arrows</div>
		  <div class="span3"><i class="fa fa-arrows-h"></i> fa-arrows-h</div>
		  <div class="span3"><i class="fa fa-arrows-v"></i> fa-arrows-v</div>
		  <div class="span3"><i class="fa fa-asterisk"></i> fa-asterisk</div>
		  <div class="span3"><i class="fa fa-ban"></i> fa-ban</div>
		  <div class="span3"><i class="fa fa-bar-chart-o"></i> fa-bar-chart-o</div>
		  <div class="span3"><i class="fa fa-barcode"></i> fa-barcode</div>
		  <div class="span3"><i class="fa fa-bars"></i> fa-bars</div>
		  <div class="span3"><i class="fa fa-beer"></i> fa-beer</div>
		  <div class="span3"><i class="fa fa-bell"></i> fa-bell</div>
		  <div class="span3"><i class="fa fa-bell-o"></i> fa-bell-o</div>
		  <div class="span3"><i class="fa fa-bolt"></i> fa-bolt</div>
		  <div class="span3"><i class="fa fa-book"></i> fa-book</div>
		  <div class="span3"><i class="fa fa-bookmark"></i> fa-bookmark</div>
		  <div class="span3"><i class="fa fa-bookmark-o"></i> fa-bookmark-o</div>
		  <div class="span3"><i class="fa fa-briefcase"></i> fa-briefcase</div>
		  <div class="span3"><i class="fa fa-bug"></i> fa-bug</div>
		  <div class="span3"><i class="fa fa-building-o"></i> fa-building-o</div>
		  <div class="span3"><i class="fa fa-bullhorn"></i> fa-bullhorn</div>
		  <div class="span3"><i class="fa fa-bullseye"></i> fa-bullseye</div>
		  <div class="span3"><i class="fa fa-calendar"></i> fa-calendar</div>
		  <div class="span3"><i class="fa fa-calendar-o"></i> fa-calendar-o</div>
		  <div class="span3"><i class="fa fa-camera"></i> fa-camera</div>
		  <div class="span3"><i class="fa fa-camera-retro"></i> fa-camera-retro</div>
		  <div class="span3"><i class="fa fa-caret-square-o-down"></i> fa-caret-square-o-down</div>
		  <div class="span3"><i class="fa fa-caret-square-o-left"></i> fa-caret-square-o-left</div>
		  <div class="span3"><i class="fa fa-caret-square-o-right"></i> fa-caret-square-o-right</div>
		  <div class="span3"><i class="fa fa-caret-square-o-up"></i> fa-caret-square-o-up</div>
		  <div class="span3"><i class="fa fa-certificate"></i> fa-certificate</div>
		  <div class="span3"><i class="fa fa-check"></i> fa-check</div>
		  <div class="span3"><i class="fa fa-check-circle"></i> fa-check-circle</div>
		  <div class="span3"><i class="fa fa-check-circle-o"></i> fa-check-circle-o</div>
		  <div class="span3"><i class="fa fa-check-square"></i> fa-check-square</div>
		  <div class="span3"><i class="fa fa-check-square-o"></i> fa-check-square-o</div>
		  <div class="span3"><i class="fa fa-circle"></i> fa-circle</div>
		  <div class="span3"><i class="fa fa-circle-o"></i> fa-circle-o</div>
		  <div class="span3"><i class="fa fa-clock-o"></i> fa-clock-o</div>
		  <div class="span3"><i class="fa fa-cloud"></i> fa-cloud</div>
		  <div class="span3"><i class="fa fa-cloud-download"></i> fa-cloud-download</div>
		  <div class="span3"><i class="fa fa-cloud-upload"></i> fa-cloud-upload</div>
		  <div class="span3"><i class="fa fa-code"></i> fa-code</div>
		  <div class="span3"><i class="fa fa-code-fork"></i> fa-code-fork</div>
		  <div class="span3"><i class="fa fa-coffee"></i> fa-coffee</div>
		  <div class="span3"><i class="fa fa-cog"></i> fa-cog</div>
		  <div class="span3"><i class="fa fa-cogs"></i> fa-cogs</div>
		  <div class="span3"><i class="fa fa-comment"></i> fa-comment</div>
		  <div class="span3"><i class="fa fa-comment-o"></i> fa-comment-o</div>
		  <div class="span3"><i class="fa fa-comments"></i> fa-comments</div>
		  <div class="span3"><i class="fa fa-comments-o"></i> fa-comments-o</div>
		  <div class="span3"><i class="fa fa-compass"></i> fa-compass</div>
		  <div class="span3"><i class="fa fa-credit-card"></i> fa-credit-card</div>
		  <div class="span3"><i class="fa fa-crop"></i> fa-crop</div>
		  <div class="span3"><i class="fa fa-crosshairs"></i> fa-crosshairs</div>
		  <div class="span3"><i class="fa fa-cutlery"></i> fa-cutlery</div>
		  <div class="span3"><i class="fa fa-dashboard"></i> fa-dashboard <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-desktop"></i> fa-desktop</div>
		  <div class="span3"><i class="fa fa-dot-circle-o"></i> fa-dot-circle-o</div>
		  <div class="span3"><i class="fa fa-download"></i> fa-download</div>
		  <div class="span3"><i class="fa fa-edit"></i> fa-edit <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-ellipsis-h"></i> fa-ellipsis-h</div>
		  <div class="span3"><i class="fa fa-ellipsis-v"></i> fa-ellipsis-v</div>
		  <div class="span3"><i class="fa fa-envelope"></i> fa-envelope</div>
		  <div class="span3"><i class="fa fa-envelope-o"></i> fa-envelope-o</div>
		  <div class="span3"><i class="fa fa-eraser"></i> fa-eraser</div>
		  <div class="span3"><i class="fa fa-exchange"></i> fa-exchange</div>
		  <div class="span3"><i class="fa fa-exclamation"></i> fa-exclamation</div>
		  <div class="span3"><i class="fa fa-exclamation-circle"></i> fa-exclamation-circle</div>
		  <div class="span3"><i class="fa fa-exclamation-triangle"></i> fa-exclamation-triangle</div>
		  <div class="span3"><i class="fa fa-external-link"></i> fa-external-link</div>
		  <div class="span3"><i class="fa fa-external-link-square"></i> fa-external-link-square</div>
		  <div class="span3"><i class="fa fa-eye"></i> fa-eye</div>
		  <div class="span3"><i class="fa fa-eye-slash"></i> fa-eye-slash</div>
		  <div class="span3"><i class="fa fa-female"></i> fa-female</div>
		  <div class="span3"><i class="fa fa-fighter-jet"></i> fa-fighter-jet</div>
		  <div class="span3"><i class="fa fa-film"></i> fa-film</div>
		  <div class="span3"><i class="fa fa-filter"></i> fa-filter</div>
		  <div class="span3"><i class="fa fa-fire"></i> fa-fire</div>
		  <div class="span3"><i class="fa fa-fire-extinguisher"></i> fa-fire-extinguisher</div>
		  <div class="span3"><i class="fa fa-flag"></i> fa-flag</div>
		  <div class="span3"><i class="fa fa-flag-checkered"></i> fa-flag-checkered</div>
		  <div class="span3"><i class="fa fa-flag-o"></i> fa-flag-o</div>
		  <div class="span3"><i class="fa fa-flash"></i> fa-flash <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-flask"></i> fa-flask</div>
		  <div class="span3"><i class="fa fa-folder"></i> fa-folder</div>
		  <div class="span3"><i class="fa fa-folder-o"></i> fa-folder-o</div>
		  <div class="span3"><i class="fa fa-folder-open"></i> fa-folder-open</div>
		  <div class="span3"><i class="fa fa-folder-open-o"></i> fa-folder-open-o</div>
		  <div class="span3"><i class="fa fa-frown-o"></i> fa-frown-o</div>
		  <div class="span3"><i class="fa fa-gamepad"></i> fa-gamepad</div>
		  <div class="span3"><i class="fa fa-gavel"></i> fa-gavel</div>
		  <div class="span3"><i class="fa fa-gear"></i> fa-gear <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-gears"></i> fa-gears <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-gift"></i> fa-gift</div>
		  <div class="span3"><i class="fa fa-glass"></i> fa-glass</div>
		  <div class="span3"><i class="fa fa-globe"></i> fa-globe</div>
		  <div class="span3"><i class="fa fa-group"></i> fa-group <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-hdd-o"></i> fa-hdd-o</div>
		  <div class="span3"><i class="fa fa-headphones"></i> fa-headphones</div>
		  <div class="span3"><i class="fa fa-heart"></i> fa-heart</div>
		  <div class="span3"><i class="fa fa-heart-o"></i> fa-heart-o</div>
		  <div class="span3"><i class="fa fa-home"></i> fa-home</div>
		  <div class="span3"><i class="fa fa-inbox"></i> fa-inbox</div>
		  <div class="span3"><i class="fa fa-info"></i> fa-info</div>
		  <div class="span3"><i class="fa fa-info-circle"></i> fa-info-circle</div>
		  <div class="span3"><i class="fa fa-key"></i> fa-key</div>
		  <div class="span3"><i class="fa fa-keyboard-o"></i> fa-keyboard-o</div>
		  <div class="span3"><i class="fa fa-laptop"></i> fa-laptop</div>
		  <div class="span3"><i class="fa fa-leaf"></i> fa-leaf</div>
		  <div class="span3"><i class="fa fa-legal"></i> fa-legal <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-lemon-o"></i> fa-lemon-o</div>
		  <div class="span3"><i class="fa fa-level-down"></i> fa-level-down</div>
		  <div class="span3"><i class="fa fa-level-up"></i> fa-level-up</div>
		  <div class="span3"><i class="fa fa-lightbulb-o"></i> fa-lightbulb-o</div>
		  <div class="span3"><i class="fa fa-location-arrow"></i> fa-location-arrow</div>
		  <div class="span3"><i class="fa fa-lock"></i> fa-lock</div>
		  <div class="span3"><i class="fa fa-magic"></i> fa-magic</div>
		  <div class="span3"><i class="fa fa-magnet"></i> fa-magnet</div>
		  <div class="span3"><i class="fa fa-mail-forward"></i> fa-mail-forward <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-mail-reply"></i> fa-mail-reply <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-mail-reply-all"></i> fa-mail-reply-all</div>
		  <div class="span3"><i class="fa fa-male"></i> fa-male</div>
		  <div class="span3"><i class="fa fa-map-marker"></i> fa-map-marker</div>
		  <div class="span3"><i class="fa fa-meh-o"></i> fa-meh-o</div>
		  <div class="span3"><i class="fa fa-microphone"></i> fa-microphone</div>
		  <div class="span3"><i class="fa fa-microphone-slash"></i> fa-microphone-slash</div>
		  <div class="span3"><i class="fa fa-minus"></i> fa-minus</div>
		  <div class="span3"><i class="fa fa-minus-circle"></i> fa-minus-circle</div>
		  <div class="span3"><i class="fa fa-minus-square"></i> fa-minus-square</div>
		  <div class="span3"><i class="fa fa-minus-square-o"></i> fa-minus-square-o</div>
		  <div class="span3"><i class="fa fa-mobile"></i> fa-mobile</div>
		  <div class="span3"><i class="fa fa-mobile-phone"></i> fa-mobile-phone <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-money"></i> fa-money</div>
		  <div class="span3"><i class="fa fa-moon-o"></i> fa-moon-o</div>
		  <div class="span3"><i class="fa fa-music"></i> fa-music</div>
		  <div class="span3"><i class="fa fa-pencil"></i> fa-pencil</div>
		  <div class="span3"><i class="fa fa-pencil-square"></i> fa-pencil-square</div>
		  <div class="span3"><i class="fa fa-pencil-square-o"></i> fa-pencil-square-o</div>
		  <div class="span3"><i class="fa fa-phone"></i> fa-phone</div>
		  <div class="span3"><i class="fa fa-phone-square"></i> fa-phone-square</div>
		  <div class="span3"><i class="fa fa-picture-o"></i> fa-picture-o</div>
		  <div class="span3"><i class="fa fa-plane"></i> fa-plane</div>
		  <div class="span3"><i class="fa fa-plus"></i> fa-plus</div>
		  <div class="span3"><i class="fa fa-plus-circle"></i> fa-plus-circle</div>
		  <div class="span3"><i class="fa fa-plus-square"></i> fa-plus-square</div>
		  <div class="span3"><i class="fa fa-plus-square-o"></i> fa-plus-square-o</div>
		  <div class="span3"><i class="fa fa-power-off"></i> fa-power-off</div>
		  <div class="span3"><i class="fa fa-print"></i> fa-print</div>
		  <div class="span3"><i class="fa fa-puzzle-piece"></i> fa-puzzle-piece</div>
		  <div class="span3"><i class="fa fa-qrcode"></i> fa-qrcode</div>
		  <div class="span3"><i class="fa fa-question"></i> fa-question</div>
		  <div class="span3"><i class="fa fa-question-circle"></i> fa-question-circle</div>
		  <div class="span3"><i class="fa fa-quote-left"></i> fa-quote-left</div>
		  <div class="span3"><i class="fa fa-quote-right"></i> fa-quote-right</div>
		  <div class="span3"><i class="fa fa-random"></i> fa-random</div>
		  <div class="span3"><i class="fa fa-refresh"></i> fa-refresh</div>
		  <div class="span3"><i class="fa fa-reply"></i> fa-reply</div>
		  <div class="span3"><i class="fa fa-reply-all"></i> fa-reply-all</div>
		  <div class="span3"><i class="fa fa-retweet"></i> fa-retweet</div>
		  <div class="span3"><i class="fa fa-road"></i> fa-road</div>
		  <div class="span3"><i class="fa fa-rocket"></i> fa-rocket</div>
		  <div class="span3"><i class="fa fa-rss"></i> fa-rss</div>
		  <div class="span3"><i class="fa fa-rss-square"></i> fa-rss-square</div>
		  <div class="span3"><i class="fa fa-search"></i> fa-search</div>
		  <div class="span3"><i class="fa fa-search-minus"></i> fa-search-minus</div>
		  <div class="span3"><i class="fa fa-search-plus"></i> fa-search-plus</div>
		  <div class="span3"><i class="fa fa-share"></i> fa-share</div>
		  <div class="span3"><i class="fa fa-share-square"></i> fa-share-square</div>
		  <div class="span3"><i class="fa fa-share-square-o"></i> fa-share-square-o</div>
		  <div class="span3"><i class="fa fa-shield"></i> fa-shield</div>
		  <div class="span3"><i class="fa fa-shopping-cart"></i> fa-shopping-cart</div>
		  <div class="span3"><i class="fa fa-sign-in"></i> fa-sign-in</div>
		  <div class="span3"><i class="fa fa-sign-out"></i> fa-sign-out</div>
		  <div class="span3"><i class="fa fa-signal"></i> fa-signal</div>
		  <div class="span3"><i class="fa fa-sitemap"></i> fa-sitemap</div>
		  <div class="span3"><i class="fa fa-smile-o"></i> fa-smile-o</div>
		  <div class="span3"><i class="fa fa-sort"></i> fa-sort</div>
		  <div class="span3"><i class="fa fa-sort-alpha-asc"></i> fa-sort-alpha-asc</div>
		  <div class="span3"><i class="fa fa-sort-alpha-desc"></i> fa-sort-alpha-desc</div>
		  <div class="span3"><i class="fa fa-sort-amount-asc"></i> fa-sort-amount-asc</div>
		  <div class="span3"><i class="fa fa-sort-amount-desc"></i> fa-sort-amount-desc</div>
		  <div class="span3"><i class="fa fa-sort-asc"></i> fa-sort-asc</div>
		  <div class="span3"><i class="fa fa-sort-desc"></i> fa-sort-desc</div>
		  <div class="span3"><i class="fa fa-sort-down"></i> fa-sort-down <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-sort-numeric-asc"></i> fa-sort-numeric-asc</div>
		  <div class="span3"><i class="fa fa-sort-numeric-desc"></i> fa-sort-numeric-desc</div>
		  <div class="span3"><i class="fa fa-sort-up"></i> fa-sort-up <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-spinner"></i> fa-spinner</div>
		  <div class="span3"><i class="fa fa-square"></i> fa-square</div>
		  <div class="span3"><i class="fa fa-square-o"></i> fa-square-o</div>
		  <div class="span3"><i class="fa fa-star"></i> fa-star</div>
		  <div class="span3"><i class="fa fa-star-half"></i> fa-star-half</div>
		  <div class="span3"><i class="fa fa-star-half-empty"></i> fa-star-half-empty <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-star-half-full"></i> fa-star-half-full <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-star-half-o"></i> fa-star-half-o</div>
		  <div class="span3"><i class="fa fa-star-o"></i> fa-star-o</div>
		  <div class="span3"><i class="fa fa-subscript"></i> fa-subscript</div>
		  <div class="span3"><i class="fa fa-suitcase"></i> fa-suitcase</div>
		  <div class="span3"><i class="fa fa-sun-o"></i> fa-sun-o</div>
		  <div class="span3"><i class="fa fa-superscript"></i> fa-superscript</div>
		  <div class="span3"><i class="fa fa-tablet"></i> fa-tablet</div>
		  <div class="span3"><i class="fa fa-tachometer"></i> fa-tachometer</div>
		  <div class="span3"><i class="fa fa-tag"></i> fa-tag</div>
		  <div class="span3"><i class="fa fa-tags"></i> fa-tags</div>
		  <div class="span3"><i class="fa fa-tasks"></i> fa-tasks</div>
		  <div class="span3"><i class="fa fa-terminal"></i> fa-terminal</div>
		  <div class="span3"><i class="fa fa-thumb-tack"></i> fa-thumb-tack</div>
		  <div class="span3"><i class="fa fa-thumbs-down"></i> fa-thumbs-down</div>
		  <div class="span3"><i class="fa fa-thumbs-o-down"></i> fa-thumbs-o-down</div>
		  <div class="span3"><i class="fa fa-thumbs-o-up"></i> fa-thumbs-o-up</div>
		  <div class="span3"><i class="fa fa-thumbs-up"></i> fa-thumbs-up</div>
		  <div class="span3"><i class="fa fa-ticket"></i> fa-ticket</div>
		  <div class="span3"><i class="fa fa-times"></i> fa-times</div>
		  <div class="span3"><i class="fa fa-times-circle"></i> fa-times-circle</div>
		  <div class="span3"><i class="fa fa-times-circle-o"></i> fa-times-circle-o</div>
		  <div class="span3"><i class="fa fa-tint"></i> fa-tint</div>
		  <div class="span3"><i class="fa fa-toggle-down"></i> fa-toggle-down <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-toggle-left"></i> fa-toggle-left <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-toggle-right"></i> fa-toggle-right <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-toggle-up"></i> fa-toggle-up <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-trash-o"></i> fa-trash-o</div>
		  <div class="span3"><i class="fa fa-trophy"></i> fa-trophy</div>
		  <div class="span3"><i class="fa fa-truck"></i> fa-truck</div>
		  <div class="span3"><i class="fa fa-umbrella"></i> fa-umbrella</div>
		  <div class="span3"><i class="fa fa-unlock"></i> fa-unlock</div>
		  <div class="span3"><i class="fa fa-unlock-alt"></i> fa-unlock-alt</div>
		  <div class="span3"><i class="fa fa-unsorted"></i> fa-unsorted <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-upload"></i> fa-upload</div>
		  <div class="span3"><i class="fa fa-user"></i> fa-user</div>
		  <div class="span3"><i class="fa fa-users"></i> fa-users</div>
		  <div class="span3"><i class="fa fa-video-camera"></i> fa-video-camera</div>
		  <div class="span3"><i class="fa fa-volume-down"></i> fa-volume-down</div>
		  <div class="span3"><i class="fa fa-volume-off"></i> fa-volume-off</div>
		  <div class="span3"><i class="fa fa-volume-up"></i> fa-volume-up</div>
		  <div class="span3"><i class="fa fa-warning"></i> fa-warning <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-wheelchair"></i> fa-wheelchair</div>
		  <div class="span3"><i class="fa fa-wrench"></i> fa-wrench</div>
		</div>
		<br>
		  
		<h3>Form Control Icons</h3>
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-check-square"></i> fa-check-square</div>
		  <div class="span3"><i class="fa fa-check-square-o"></i> fa-check-square-o</div>
		  <div class="span3"><i class="fa fa-circle"></i> fa-circle</div>
		  <div class="span3"><i class="fa fa-circle-o"></i> fa-circle-o</div>
		  <div class="span3"><i class="fa fa-dot-circle-o"></i> fa-dot-circle-o</div>
		  <div class="span3"><i class="fa fa-minus-square"></i> fa-minus-square</div>
		  <div class="span3"><i class="fa fa-minus-square-o"></i> fa-minus-square-o</div>
		  <div class="span3"><i class="fa fa-plus-square"></i> fa-plus-square</div>
		  <div class="span3"><i class="fa fa-plus-square-o"></i> fa-plus-square-o</div>
		  <div class="span3"><i class="fa fa-square"></i> fa-square</div>
		  <div class="span3"><i class="fa fa-square-o"></i> fa-square-o</div>
		</div>
		<br>
		<h3>Currency Icons</h3>
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-bitcoin"></i> fa-bitcoin <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-btc"></i> fa-btc</div>
		  <div class="span3"><i class="fa fa-cny"></i> fa-cny <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-dollar"></i> fa-dollar <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-eur"></i> fa-eur</div>
		  <div class="span3"><i class="fa fa-euro"></i> fa-euro <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-gbp"></i> fa-gbp</div>
		  <div class="span3"><i class="fa fa-inr"></i> fa-inr</div>
		  <div class="span3"><i class="fa fa-jpy"></i> fa-jpy</div>
		  <div class="span3"><i class="fa fa-krw"></i> fa-krw</div>
		  <div class="span3"><i class="fa fa-money"></i> fa-money</div>
		  <div class="span3"><i class="fa fa-rmb"></i> fa-rmb <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-rouble"></i> fa-rouble <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-rub"></i> fa-rub</div>
		  <div class="span3"><i class="fa fa-ruble"></i> fa-ruble <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-rupee"></i> fa-rupee <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-try"></i> fa-try</div>
		  <div class="span3"><i class="fa fa-turkish-lira"></i> fa-turkish-lira <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-usd"></i> fa-usd</div>
		  <div class="span3"><i class="fa fa-won"></i> fa-won <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-yen"></i> fa-yen <span class="text-muted">(alias)</span></div>
		</div>
		<br>
		
		<h3>Text Editor Icons</h3>
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-align-center"></i> fa-align-center</div>
		  <div class="span3"><i class="fa fa-align-justify"></i> fa-align-justify</div>
		  <div class="span3"><i class="fa fa-align-left"></i> fa-align-left</div>
		  <div class="span3"><i class="fa fa-align-right"></i> fa-align-right</div>
		  <div class="span3"><i class="fa fa-bold"></i> fa-bold</div>
		  <div class="span3"><i class="fa fa-chain"></i> fa-chain <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-chain-broken"></i> fa-chain-broken</div>
		  <div class="span3"><i class="fa fa-clipboard"></i> fa-clipboard</div>
		  <div class="span3"><i class="fa fa-columns"></i> fa-columns</div>
		  <div class="span3"><i class="fa fa-copy"></i> fa-copy <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-cut"></i> fa-cut <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-dedent"></i> fa-dedent <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-eraser"></i> fa-eraser</div>
		  <div class="span3"><i class="fa fa-file"></i> fa-file</div>
		  <div class="span3"><i class="fa fa-file-o"></i> fa-file-o</div>
		  <div class="span3"><i class="fa fa-file-text"></i> fa-file-text</div>
		  <div class="span3"><i class="fa fa-file-text-o"></i> fa-file-text-o</div>
		  <div class="span3"><i class="fa fa-files-o"></i> fa-files-o</div>
		  <div class="span3"><i class="fa fa-floppy-o"></i> fa-floppy-o</div>
		  <div class="span3"><i class="fa fa-font"></i> fa-font</div>
		  <div class="span3"><i class="fa fa-indent"></i> fa-indent</div>
		  <div class="span3"><i class="fa fa-italic"></i> fa-italic</div>
		  <div class="span3"><i class="fa fa-link"></i> fa-link</div>
		  <div class="span3"><i class="fa fa-list"></i> fa-list</div>
		  <div class="span3"><i class="fa fa-list-alt"></i> fa-list-alt</div>
		  <div class="span3"><i class="fa fa-list-ol"></i> fa-list-ol</div>
		  <div class="span3"><i class="fa fa-list-ul"></i> fa-list-ul</div>
		  <div class="span3"><i class="fa fa-outdent"></i> fa-outdent</div>
		  <div class="span3"><i class="fa fa-paperclip"></i> fa-paperclip</div>
		  <div class="span3"><i class="fa fa-paste"></i> fa-paste <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-repeat"></i> fa-repeat</div>
		  <div class="span3"><i class="fa fa-rotate-left"></i> fa-rotate-left <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-rotate-right"></i> fa-rotate-right <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-save"></i> fa-save <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-scissors"></i> fa-scissors</div>
		  <div class="span3"><i class="fa fa-strikethrough"></i> fa-strikethrough</div>
		  <div class="span3"><i class="fa fa-table"></i> fa-table</div>
		  <div class="span3"><i class="fa fa-text-height"></i> fa-text-height</div>
		  <div class="span3"><i class="fa fa-text-width"></i> fa-text-width</div>
		  <div class="span3"><i class="fa fa-th"></i> fa-th</div>
		  <div class="span3"><i class="fa fa-th-large"></i> fa-th-large</div>
		  <div class="span3"><i class="fa fa-th-list"></i> fa-th-list</div>
		  <div class="span3"><i class="fa fa-underline"></i> fa-underline</div>
		  <div class="span3"><i class="fa fa-undo"></i> fa-undo</div>
		  <div class="span3"><i class="fa fa-unlink"></i> fa-unlink <span class="text-muted">(alias)</span></div>
		</div>
		<br>
		
		<h3>Directional Icons</h3>
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-angle-double-down"></i> fa-angle-double-down</div>
		  <div class="span3"><i class="fa fa-angle-double-left"></i> fa-angle-double-left</div>
		  <div class="span3"><i class="fa fa-angle-double-right"></i> fa-angle-double-right</div>
		  <div class="span3"><i class="fa fa-angle-double-up"></i> fa-angle-double-up</div>
		  <div class="span3"><i class="fa fa-angle-down"></i> fa-angle-down</div>
		  <div class="span3"><i class="fa fa-angle-left"></i> fa-angle-left</div>
		  <div class="span3"><i class="fa fa-angle-right"></i> fa-angle-right</div>
		  <div class="span3"><i class="fa fa-angle-up"></i> fa-angle-up</div>
		  <div class="span3"><i class="fa fa-arrow-circle-down"></i> fa-arrow-circle-down</div>
		  <div class="span3"><i class="fa fa-arrow-circle-left"></i> fa-arrow-circle-left</div>
		  <div class="span3"><i class="fa fa-arrow-circle-o-down"></i> fa-arrow-circle-o-down</div>
		  <div class="span3"><i class="fa fa-arrow-circle-o-left"></i> fa-arrow-circle-o-left</div>
		  <div class="span3"><i class="fa fa-arrow-circle-o-right"></i> fa-arrow-circle-o-right</div>
		  <div class="span3"><i class="fa fa-arrow-circle-o-up"></i> fa-arrow-circle-o-up</div>
		  <div class="span3"><i class="fa fa-arrow-circle-right"></i> fa-arrow-circle-right</div>
		  <div class="span3"><i class="fa fa-arrow-circle-up"></i> fa-arrow-circle-up</div>
		  <div class="span3"><i class="fa fa-arrow-down"></i> fa-arrow-down</div>
		  <div class="span3"><i class="fa fa-arrow-left"></i> fa-arrow-left</div>
		  <div class="span3"><i class="fa fa-arrow-right"></i> fa-arrow-right</div>
		  <div class="span3"><i class="fa fa-arrow-up"></i> fa-arrow-up</div>
		  <div class="span3"><i class="fa fa-arrows"></i> fa-arrows</div>
		  <div class="span3"><i class="fa fa-arrows-alt"></i> fa-arrows-alt</div>
		  <div class="span3"><i class="fa fa-arrows-h"></i> fa-arrows-h</div>
		  <div class="span3"><i class="fa fa-arrows-v"></i> fa-arrows-v</div>
		  <div class="span3"><i class="fa fa-caret-down"></i> fa-caret-down</div>
		  <div class="span3"><i class="fa fa-caret-left"></i> fa-caret-left</div>
		  <div class="span3"><i class="fa fa-caret-right"></i> fa-caret-right</div>
		  <div class="span3"><i class="fa fa-caret-square-o-down"></i> fa-caret-square-o-down</div>
		  <div class="span3"><i class="fa fa-caret-square-o-left"></i> fa-caret-square-o-left</div>
		  <div class="span3"><i class="fa fa-caret-square-o-right"></i> fa-caret-square-o-right</div>
		  <div class="span3"><i class="fa fa-caret-square-o-up"></i> fa-caret-square-o-up</div>
		  <div class="span3"><i class="fa fa-caret-up"></i> fa-caret-up</div>
		  <div class="span3"><i class="fa fa-chevron-circle-down"></i> fa-chevron-circle-down</div>
		  <div class="span3"><i class="fa fa-chevron-circle-left"></i> fa-chevron-circle-left</div>
		  <div class="span3"><i class="fa fa-chevron-circle-right"></i> fa-chevron-circle-right</div>
		  <div class="span3"><i class="fa fa-chevron-circle-up"></i> fa-chevron-circle-up</div>
		  <div class="span3"><i class="fa fa-chevron-down"></i> fa-chevron-down</div>
		  <div class="span3"><i class="fa fa-chevron-left"></i> fa-chevron-left</div>
		  <div class="span3"><i class="fa fa-chevron-right"></i> fa-chevron-right</div>
		  <div class="span3"><i class="fa fa-chevron-up"></i> fa-chevron-up</div>
		  <div class="span3"><i class="fa fa-hand-o-down"></i> fa-hand-o-down</div>
		  <div class="span3"><i class="fa fa-hand-o-left"></i> fa-hand-o-left</div>
		  <div class="span3"><i class="fa fa-hand-o-right"></i> fa-hand-o-right</div>
		  <div class="span3"><i class="fa fa-hand-o-up"></i> fa-hand-o-up</div>
		  <div class="span3"><i class="fa fa-long-arrow-down"></i> fa-long-arrow-down</div>
		  <div class="span3"><i class="fa fa-long-arrow-left"></i> fa-long-arrow-left</div>
		  <div class="span3"><i class="fa fa-long-arrow-right"></i> fa-long-arrow-right</div>
		  <div class="span3"><i class="fa fa-long-arrow-up"></i> fa-long-arrow-up</div>
		  <div class="span3"><i class="fa fa-toggle-down"></i> fa-toggle-down <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-toggle-left"></i> fa-toggle-left <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-toggle-right"></i> fa-toggle-right <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-toggle-up"></i> fa-toggle-up <span class="text-muted">(alias)</span></div>
		</div>
		<br>
		
		<h3>Video Player Icons</h3>
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-arrows-alt"></i> fa-arrows-alt</div>
		  <div class="span3"><i class="fa fa-backward"></i> fa-backward</div>
		  <div class="span3"><i class="fa fa-compress"></i> fa-compress</div>
		  <div class="span3"><i class="fa fa-eject"></i> fa-eject</div>
		  <div class="span3"><i class="fa fa-expand"></i> fa-expand</div>
		  <div class="span3"><i class="fa fa-fast-backward"></i> fa-fast-backward</div>
		  <div class="span3"><i class="fa fa-fast-forward"></i> fa-fast-forward</div>
		  <div class="span3"><i class="fa fa-forward"></i> fa-forward</div>
		  <div class="span3"><i class="fa fa-pause"></i> fa-pause</div>
		  <div class="span3"><i class="fa fa-play"></i> fa-play</div>
		  <div class="span3"><i class="fa fa-play-circle"></i> fa-play-circle</div>
		  <div class="span3"><i class="fa fa-play-circle-o"></i> fa-play-circle-o</div>
		  <div class="span3"><i class="fa fa-step-backward"></i> fa-step-backward</div>
		  <div class="span3"><i class="fa fa-step-forward"></i> fa-step-forward</div>
		  <div class="span3"><i class="fa fa-stop"></i> fa-stop</div>
		  <div class="span3"><i class="fa fa-youtube-play"></i> fa-youtube-play</div>
		</div>
		<br>
		
		<h3>Brand Icons</h3>
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-adn"></i> fa-adn</div>
		  <div class="span3"><i class="fa fa-android"></i> fa-android</div>
		  <div class="span3"><i class="fa fa-apple"></i> fa-apple</div>
		  <div class="span3"><i class="fa fa-bitbucket"></i> fa-bitbucket</div>
		  <div class="span3"><i class="fa fa-bitbucket-square"></i> fa-bitbucket-square</div>
		  <div class="span3"><i class="fa fa-bitcoin"></i> fa-bitcoin <span class="text-muted">(alias)</span></div>
		  <div class="span3"><i class="fa fa-btc"></i> fa-btc</div>
		  <div class="span3"><i class="fa fa-css3"></i> fa-css3</div>
		  <div class="span3"><i class="fa fa-dribbble"></i> fa-dribbble</div>
		  <div class="span3"><i class="fa fa-dropbox"></i> fa-dropbox</div>
		  <div class="span3"><i class="fa fa-facebook"></i> fa-facebook</div>
		  <div class="span3"><i class="fa fa-facebook-square"></i> fa-facebook-square</div>
		  <div class="span3"><i class="fa fa-flickr"></i> fa-flickr</div>
		  <div class="span3"><i class="fa fa-foursquare"></i> fa-foursquare</div>
		  <div class="span3"><i class="fa fa-github"></i> fa-github</div>
		  <div class="span3"><i class="fa fa-github-alt"></i> fa-github-alt</div>
		  <div class="span3"><i class="fa fa-github-square"></i> fa-github-square</div>
		  <div class="span3"><i class="fa fa-gittip"></i> fa-gittip</div>
		  <div class="span3"><i class="fa fa-google-plus"></i> fa-google-plus</div>
		  <div class="span3"><i class="fa fa-google-plus-square"></i> fa-google-plus-square</div>
		  <div class="span3"><i class="fa fa-html5"></i> fa-html5</div>
		  <div class="span3"><i class="fa fa-instagram"></i> fa-instagram</div>
		  <div class="span3"><i class="fa fa-linkedin"></i> fa-linkedin</div>
		  <div class="span3"><i class="fa fa-linkedin-square"></i> fa-linkedin-square</div>
		  <div class="span3"><i class="fa fa-linux"></i> fa-linux</div>
		  <div class="span3"><i class="fa fa-maxcdn"></i> fa-maxcdn</div>
		  <div class="span3"><i class="fa fa-pagelines"></i> fa-pagelines</div>
		  <div class="span3"><i class="fa fa-pinterest"></i> fa-pinterest</div>
		  <div class="span3"><i class="fa fa-pinterest-square"></i> fa-pinterest-square</div>
		  <div class="span3"><i class="fa fa-renren"></i> fa-renren</div>
		  <div class="span3"><i class="fa fa-skype"></i> fa-skype</div>
		  <div class="span3"><i class="fa fa-stack-exchange"></i> fa-stack-exchange</div>
		  <div class="span3"><i class="fa fa-stack-overflow"></i> fa-stack-overflow</div>
		  <div class="span3"><i class="fa fa-trello"></i> fa-trello</div>
		  <div class="span3"><i class="fa fa-tumblr"></i> fa-tumblr</div>
		  <div class="span3"><i class="fa fa-tumblr-square"></i> fa-tumblr-square</div>
		  <div class="span3"><i class="fa fa-twitter"></i> fa-twitter</div>
		  <div class="span3"><i class="fa fa-twitter-square"></i> fa-twitter-square</div>
		  <div class="span3"><i class="fa fa-vimeo-square"></i> fa-vimeo-square</div>
		  <div class="span3"><i class="fa fa-vk"></i> fa-vk</div>
		  <div class="span3"><i class="fa fa-weibo"></i> fa-weibo</div>
		  <div class="span3"><i class="fa fa-windows"></i> fa-windows</div>
		  <div class="span3"><i class="fa fa-xing"></i> fa-xing</div>
		  <div class="span3"><i class="fa fa-xing-square"></i> fa-xing-square</div>
		  <div class="span3"><i class="fa fa-youtube"></i> fa-youtube</div>
		  <div class="span3"><i class="fa fa-youtube-play"></i> fa-youtube-play</div>
		  <div class="span3"><i class="fa fa-youtube-square"></i> fa-youtube-square</div>
		</div>
		<br>
		
		<h3>Medical Icons</h3>
  
		<div class="row fontawesome-icon-list">
		  <div class="span3"><i class="fa fa-ambulance"></i> fa-ambulance</div>
		  <div class="span3"><i class="fa fa-h-square"></i> fa-h-square</div>
		  <div class="span3"><i class="fa fa-hospital-o"></i> fa-hospital-o</div>
		  <div class="span3"><i class="fa fa-medkit"></i> fa-medkit</div>
		  <div class="span3"><i class="fa fa-plus-square"></i> fa-plus-square</div>
		  <div class="span3"><i class="fa fa-stethoscope"></i> fa-stethoscope</div>
		  <div class="span3"><i class="fa fa-user-md"></i> fa-user-md</div>
		  <div class="span3"><i class="fa fa-wheelchair"></i> fa-wheelchair</div>
		</div>
  
		<br>
		<h2>Icons <small>by <a href="http://glyphicons.com/" target="_blank">Glyphicons</a></small></h2>
		
		<h3>Icon glyphs</h3>
		<p>140 icons in sprite form, available in dark gray (default) and white, provided by <a href="http://glyphicons.com/" target="_blank">Glyphicons</a>.</p>
		<ul class="the-icons clearfix row">
		  <li class="span3"><i class="icon-glass"></i> icon-glass</li>
		  <li class="span3"><i class="icon-music"></i> icon-music</li>
		  <li class="span3"><i class="icon-search"></i> icon-search</li>
		  <li class="span3"><i class="icon-envelope"></i> icon-envelope</li>
		  <li class="span3"><i class="icon-heart"></i> icon-heart</li>
		  <li class="span3"><i class="icon-star"></i> icon-star</li>
		  <li class="span3"><i class="icon-star-empty"></i> icon-star-empty</li>
		  <li class="span3"><i class="icon-user"></i> icon-user</li>
		  <li class="span3"><i class="icon-film"></i> icon-film</li>
		  <li class="span3"><i class="icon-th-large"></i> icon-th-large</li>
		  <li class="span3"><i class="icon-th"></i> icon-th</li>
		  <li class="span3"><i class="icon-th-list"></i> icon-th-list</li>
		  <li class="span3"><i class="icon-ok"></i> icon-ok</li>
		  <li class="span3"><i class="icon-remove"></i> icon-remove</li>
		  <li class="span3"><i class="icon-zoom-in"></i> icon-zoom-in</li>
		  <li class="span3"><i class="icon-zoom-out"></i> icon-zoom-out</li>
		  <li class="span3"><i class="icon-off"></i> icon-off</li>
		  <li class="span3"><i class="icon-signal"></i> icon-signal</li>
		  <li class="span3"><i class="icon-cog"></i> icon-cog</li>
		  <li class="span3"><i class="icon-trash"></i> icon-trash</li>
		  <li class="span3"><i class="icon-home"></i> icon-home</li>
		  <li class="span3"><i class="icon-file"></i> icon-file</li>
		  <li class="span3"><i class="icon-time"></i> icon-time</li>
		  <li class="span3"><i class="icon-road"></i> icon-road</li>
		  <li class="span3"><i class="icon-download-alt"></i> icon-download-alt</li>
		  <li class="span3"><i class="icon-download"></i> icon-download</li>
		  <li class="span3"><i class="icon-upload"></i> icon-upload</li>
		  <li class="span3"><i class="icon-inbox"></i> icon-inbox</li>

		  <li class="span3"><i class="icon-play-circle"></i> icon-play-circle</li>
		  <li class="span3"><i class="icon-repeat"></i> icon-repeat</li>
		  <li class="span3"><i class="icon-refresh"></i> icon-refresh</li>
		  <li class="span3"><i class="icon-list-alt"></i> icon-list-alt</li>
		  <li class="span3"><i class="icon-lock"></i> icon-lock</li>
		  <li class="span3"><i class="icon-flag"></i> icon-flag</li>
		  <li class="span3"><i class="icon-headphones"></i> icon-headphones</li>
		  <li class="span3"><i class="icon-volume-off"></i> icon-volume-off</li>
		  <li class="span3"><i class="icon-volume-down"></i> icon-volume-down</li>
		  <li class="span3"><i class="icon-volume-up"></i> icon-volume-up</li>
		  <li class="span3"><i class="icon-qrcode"></i> icon-qrcode</li>
		  <li class="span3"><i class="icon-barcode"></i> icon-barcode</li>
		  <li class="span3"><i class="icon-tag"></i> icon-tag</li>
		  <li class="span3"><i class="icon-tags"></i> icon-tags</li>
		  <li class="span3"><i class="icon-book"></i> icon-book</li>
		  <li class="span3"><i class="icon-bookmark"></i> icon-bookmark</li>
		  <li class="span3"><i class="icon-print"></i> icon-print</li>
		  <li class="span3"><i class="icon-camera"></i> icon-camera</li>
		  <li class="span3"><i class="icon-font"></i> icon-font</li>
		  <li class="span3"><i class="icon-bold"></i> icon-bold</li>
		  <li class="span3"><i class="icon-italic"></i> icon-italic</li>
		  <li class="span3"><i class="icon-text-height"></i> icon-text-height</li>
		  <li class="span3"><i class="icon-text-width"></i> icon-text-width</li>
		  <li class="span3"><i class="icon-align-left"></i> icon-align-left</li>
		  <li class="span3"><i class="icon-align-center"></i> icon-align-center</li>
		  <li class="span3"><i class="icon-align-right"></i> icon-align-right</li>
		  <li class="span3"><i class="icon-align-justify"></i> icon-align-justify</li>
		  <li class="span3"><i class="icon-list"></i> icon-list</li>

		  <li class="span3"><i class="icon-indent-left"></i> icon-indent-left</li>
		  <li class="span3"><i class="icon-indent-right"></i> icon-indent-right</li>
		  <li class="span3"><i class="icon-facetime-video"></i> icon-facetime-video</li>
		  <li class="span3"><i class="icon-picture"></i> icon-picture</li>
		  <li class="span3"><i class="icon-pencil"></i> icon-pencil</li>
		  <li class="span3"><i class="icon-map-marker"></i> icon-map-marker</li>
		  <li class="span3"><i class="icon-adjust"></i> icon-adjust</li>
		  <li class="span3"><i class="icon-tint"></i> icon-tint</li>
		  <li class="span3"><i class="icon-edit"></i> icon-edit</li>
		  <li class="span3"><i class="icon-share"></i> icon-share</li>
		  <li class="span3"><i class="icon-check"></i> icon-check</li>
		  <li class="span3"><i class="icon-move"></i> icon-move</li>
		  <li class="span3"><i class="icon-step-backward"></i> icon-step-backward</li>
		  <li class="span3"><i class="icon-fast-backward"></i> icon-fast-backward</li>
		  <li class="span3"><i class="icon-backward"></i> icon-backward</li>
		  <li class="span3"><i class="icon-play"></i> icon-play</li>
		  <li class="span3"><i class="icon-pause"></i> icon-pause</li>
		  <li class="span3"><i class="icon-stop"></i> icon-stop</li>
		  <li class="span3"><i class="icon-forward"></i> icon-forward</li>
		  <li class="span3"><i class="icon-fast-forward"></i> icon-fast-forward</li>
		  <li class="span3"><i class="icon-step-forward"></i> icon-step-forward</li>
		  <li class="span3"><i class="icon-eject"></i> icon-eject</li>
		  <li class="span3"><i class="icon-chevron-left"></i> icon-chevron-left</li>
		  <li class="span3"><i class="icon-chevron-right"></i> icon-chevron-right</li>
		  <li class="span3"><i class="icon-plus-sign"></i> icon-plus-sign</li>
		  <li class="span3"><i class="icon-minus-sign"></i> icon-minus-sign</li>
		  <li class="span3"><i class="icon-remove-sign"></i> icon-remove-sign</li>
		  <li class="span3"><i class="icon-ok-sign"></i> icon-ok-sign</li>

		  <li class="span3"><i class="icon-question-sign"></i> icon-question-sign</li>
		  <li class="span3"><i class="icon-info-sign"></i> icon-info-sign</li>
		  <li class="span3"><i class="icon-screenshot"></i> icon-screenshot</li>
		  <li class="span3"><i class="icon-remove-circle"></i> icon-remove-circle</li>
		  <li class="span3"><i class="icon-ok-circle"></i> icon-ok-circle</li>
		  <li class="span3"><i class="icon-ban-circle"></i> icon-ban-circle</li>
		  <li class="span3"><i class="icon-arrow-left"></i> icon-arrow-left</li>
		  <li class="span3"><i class="icon-arrow-right"></i> icon-arrow-right</li>
		  <li class="span3"><i class="icon-arrow-up"></i> icon-arrow-up</li>
		  <li class="span3"><i class="icon-arrow-down"></i> icon-arrow-down</li>
		  <li class="span3"><i class="icon-share-alt"></i> icon-share-alt</li>
		  <li class="span3"><i class="icon-resize-full"></i> icon-resize-full</li>
		  <li class="span3"><i class="icon-resize-small"></i> icon-resize-small</li>
		  <li class="span3"><i class="icon-plus"></i> icon-plus</li>
		  <li class="span3"><i class="icon-minus"></i> icon-minus</li>
		  <li class="span3"><i class="icon-asterisk"></i> icon-asterisk</li>
		  <li class="span3"><i class="icon-exclamation-sign"></i> icon-exclamation-sign</li>
		  <li class="span3"><i class="icon-gift"></i> icon-gift</li>
		  <li class="span3"><i class="icon-leaf"></i> icon-leaf</li>
		  <li class="span3"><i class="icon-fire"></i> icon-fire</li>
		  <li class="span3"><i class="icon-eye-open"></i> icon-eye-open</li>
		  <li class="span3"><i class="icon-eye-close"></i> icon-eye-close</li>
		  <li class="span3"><i class="icon-warning-sign"></i> icon-warning-sign</li>
		  <li class="span3"><i class="icon-plane"></i> icon-plane</li>
		  <li class="span3"><i class="icon-calendar"></i> icon-calendar</li>
		  <li class="span3"><i class="icon-random"></i> icon-random</li>
		  <li class="span3"><i class="icon-comment"></i> icon-comment</li>
		  <li class="span3"><i class="icon-magnet"></i> icon-magnet</li>

		  <li class="span3"><i class="icon-chevron-up"></i> icon-chevron-up</li>
		  <li class="span3"><i class="icon-chevron-down"></i> icon-chevron-down</li>
		  <li class="span3"><i class="icon-retweet"></i> icon-retweet</li>
		  <li class="span3"><i class="icon-shopping-cart"></i> icon-shopping-cart</li>
		  <li class="span3"><i class="icon-folder-close"></i> icon-folder-close</li>
		  <li class="span3"><i class="icon-folder-open"></i> icon-folder-open</li>
		  <li class="span3"><i class="icon-resize-vertical"></i> icon-resize-vertical</li>
		  <li class="span3"><i class="icon-resize-horizontal"></i> icon-resize-horizontal</li>
		  <li class="span3"><i class="icon-hdd"></i> icon-hdd</li>
		  <li class="span3"><i class="icon-bullhorn"></i> icon-bullhorn</li>
		  <li class="span3"><i class="icon-bell"></i> icon-bell</li>
		  <li class="span3"><i class="icon-certificate"></i> icon-certificate</li>
		  <li class="span3"><i class="icon-thumbs-up"></i> icon-thumbs-up</li>
		  <li class="span3"><i class="icon-thumbs-down"></i> icon-thumbs-down</li>
		  <li class="span3"><i class="icon-hand-right"></i> icon-hand-right</li>
		  <li class="span3"><i class="icon-hand-left"></i> icon-hand-left</li>
		  <li class="span3"><i class="icon-hand-up"></i> icon-hand-up</li>
		  <li class="span3"><i class="icon-hand-down"></i> icon-hand-down</li>
		  <li class="span3"><i class="icon-circle-arrow-right"></i> icon-circle-arrow-right</li>
		  <li class="span3"><i class="icon-circle-arrow-left"></i> icon-circle-arrow-left</li>
		  <li class="span3"><i class="icon-circle-arrow-up"></i> icon-circle-arrow-up</li>
		  <li class="span3"><i class="icon-circle-arrow-down"></i> icon-circle-arrow-down</li>
		  <li class="span3"><i class="icon-globe"></i> icon-globe</li>
		  <li class="span3"><i class="icon-wrench"></i> icon-wrench</li>
		  <li class="span3"><i class="icon-tasks"></i> icon-tasks</li>
		  <li class="span3"><i class="icon-filter"></i> icon-filter</li>
		  <li class="span3"><i class="icon-briefcase"></i> icon-briefcase</li>
		  <li class="span3"><i class="icon-fullscreen"></i> icon-fullscreen</li>
		</ul>

		<br>
		<h4>Glyphicons attribution</h4>
		<p><a href="http://glyphicons.com/">Glyphicons</a> Halflings are normally not available for free, but an arrangement between Bootstrap and the Glyphicons creators have made this possible at no cost to you as developers. As a thank you, we ask you to include an optional link back to <a href="http://glyphicons.com/">Glyphicons</a> whenever practical.</p>

		<hr class="bs-docs-separator">

		<h2>How to use</h2>
        <p>All icons require an <code>&lt;i&gt;</code> tag with a unique class, prefixed with <code>icon-</code>. To use, place the following code just about anywhere:</p>
<pre class="prettyprint linenums">
&lt;i class="icon-search"&gt;&lt;/i&gt;
</pre>
        <p>There are also styles available for inverted (white) icons, made ready with one extra class. We will specifically enforce this class on hover and active states for nav and dropdown links.</p>
<pre class="prettyprint linenums">
&lt;i class="icon-search icon-white"&gt;&lt;/i&gt;
</pre>
		<p>
		  <span class="label label-info">Heads up!</span>
		  When using beside strings of text, as in buttons or nav links, be sure to leave a space after the <code>&lt;i&gt;</code> tag for proper spacing.
		</p>
	  </article><!-- .content -->
    </div>
  </div>
</div><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="span3 social">
          <h3>Follow Us</h3>
          <p>Follow us in social media</p>
          <a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a>
        </div>
        <div class="span3 newsletter">
          <h3>Newsletter</h3>
          <p>Sign up for newsletter</p>
          <form>
            <input class="input-block-level" type="email">
            <button class="submit"><i class="fa fa-arrow-circle-o-right"></i></button>
          </form>
        </div>
        <div class="span3 nav-box">
          <h3>Information</h3>
		  <nav>
			<ul>
			  <li><a href="#">About us</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">Terms & Condotions</a></li>
			  <li><a href="#">Secure payment</a></li>
			</ul>
		  </nav>
        </div>
        <div class="span3 nav-box">
          <h3>My account</h3>
		  <nav>
			<ul>
			  <li><a href="#">My account</a></li>
			  <li><a href="#">Order History</a></li>
			  <li><a href="#">Wish List</a></li>
			  <li><a href="#">Newsletter</a></li>
			</ul>
		  </nav>
        </div>
      </div>
    </div>
  </div><!-- .footer-top -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="span3 copyright">Copyright &copy; ItemBridge Inc., 2013</div>
        <div class="span3 phone">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#c6c6c6" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			   c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
				M11.001,12H5V2h6V12z"/>
			</svg>
		  </div>
          <strong class="title">Call Us:</strong> +1 (877) 123-45-67 <br>
          <strong>or</strong> +1 (777) 123-45-67
        </div>
        <div class="span3 address">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <g>
				<g>
				  <path fill="#c6c6c6" d="M8,16c-0.256,0-0.512-0.098-0.707-0.293C7.077,15.491,2,10.364,2,6c0-3.309,2.691-6,6-6
					c3.309,0,6,2.691,6,6c0,4.364-5.077,9.491-5.293,9.707C8.512,15.902,8.256,16,8,16z M8,2C5.795,2,4,3.794,4,6
					c0,2.496,2.459,5.799,4,7.536c1.541-1.737,4-5.04,4-7.536C12.001,3.794,10.206,2,8,2z"/>
				</g>
				<g>
				  <circle fill="#c6c6c6" cx="8.001" cy="6" r="2"/>
				</g>
			  </g>
			</svg>
		  </div>
          49 Archdale, 2B Charleston 5655, Excel Tower<br> OPG Rpad, 4538FH
        </div>
        <div class="span3">
          <a href="#" class="up pull-right"><i class="icon-arrow-up icon-white"></i></a>
        </div>
      </div>
    </div>
  </div><!-- .footer-bottom -->
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>