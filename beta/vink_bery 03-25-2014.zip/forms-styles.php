<!DOCTYPE html>
<html>
<head>
  <title>Forms Styles \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body>
<div class="page-box">
<div class="page-box-content">

<header class="header header-two">
  <div class="container">
	<div class="row">
	  <div class="span2 logo-box">
		<a href="index.html" class="logo">
		  <img src="img/logo.svg" class="logo-img" alt="">
		</a>
	  </div>
	  <div class="span7 primary">
		<div class="navbar">
		  <a class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".primary .nav-collapse">
			<span class="text">Menu</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </a>
		  <nav class="nav-collapse collapse">
			<ul class="nav">
			  <li class="parent">
				<a href="index.html">Home</a>
				<ul class="sub">
				  <li><a href="index.html">Creative</a></li>
				  <li><a href="home-2.html">Paralax</a></li>
				  <li><a href="home-3.html">Simple</a></li>
				  <li><a href="home-4.html">Business</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Pages</a>
				<ul class="sub">
				  <li><a href="sidebar-blocks.html">All sidebar blocks</a></li>
				  <li><a href="full-width.html">Full Width</a></li>
				  <li><a href="left-sidebar.html">Left Sidebar</a></li>
				  <li><a href="right-sidebar.html">Right Sidebar</a></li>
				  <li><a href="about-us.html">About Us</a></li>
				  <li><a href="contact.html">Contact Us</a></li>
				  <li><a href="blog-list.html">Blog List</a></li>
				  <li><a href="blog-view.html">Blog Post View</a></li>
				  <li><a href="404.html">Page 404</a></li>
				  <li><a href="404-2.html">Page 404 (2)</a></li>
				  <li class="parent">
					<a href="#">Portfolio</a>
					<ul class="sub">
					  <li><a href="portfolio-1.html">Portfolio (1 column)</a></li>
					  <li><a href="portfolio-2.html">Portfolio (2 column)</a></li>
					  <li><a href="portfolio-3.html">Portfolio (3 column)</a></li>
					  <li><a href="portfolio-4.html">Portfolio (4 column)</a></li>
					  <li><a href="portfolio-slider.html">Portfolio (Slider)</a></li>
					  <li><a href="portfolio-single.html">Single Project</a></li>
					</ul>
				  </li>
				  <li><a href="gallery-modern.html">Modern Gallery</a></li>
				  <li class="parent">
					<a href="#">Gallery</a>
					<ul class="sub">
					  <li><a href="gallery-1.html">Gallery (1 column)</a></li>
					  <li><a href="gallery-2.html">Gallery (2 column)</a></li>
					  <li><a href="gallery-3.html">Gallery (3 column)</a></li>
					  <li><a href="gallery-4.html">Gallery (4 column)</a></li>
					</ul>
				  </li>
				  <li><a href="pricing.html">Pricing</a></li>
				  <li><a href="team.html">Team</a></li>
				  <li><a href="faq.html">FAQ</a></li>
				  <li><a href="services.html">Services</a></li>
				  <li><a href="careers.html">Careers</a></li>
				  <li><a href="coming-soon.html">Coming Soon</a></li>
				  <li><a href="under-construction.html">Under Construction</a></li>
				  <li><a href="sitemap.html">Sitemap</a></li>
				  <li class="parent">
					<a href="#">Newsletter</a>
					<ul class="sub">
					  <li><a href="newsletter-big-intro.html">Newsletter Big Intro</a></li>
					  <li><a href="newsletter-big-portfolio.html">Newsletter Big Portfolio</a></li>
					  <li><a href="newsletter-columns.html">Newsletter Columns</a></li>
					  <li><a href="newsletter-info.html">Newsletter Info</a></li>
					  <li><a href="newsletter-plan.html">Newsletter Plan</a></li>
					  <li><a href="newsletter-portfolio.html">Newsletter Portfolio</a></li>
					  <li><a href="newsletter-product-list.html">Newsletter Product List</a></li>
					  <li><a href="newsletter-story.html">Newsletter Story</a></li>
					</ul>
				  </li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="shop.html">Shop</a>
				<ul class="sub">
				  <li><a href="catalog-grid.html">Catalog (Grid)</a></li>
				  <li><a href="catalog-list.html">Catalog (List)</a></li>
				  <li><a href="product-view.html">Product View</a></li>
				  <li><a href="product-view-variants.html">Product View (Variants)</a></li>
				  <li><a href="cart.html">Shopping Cart</a></li>
				  <li><a href="checkout.html">Proceed to Checkout</a></li>
				  <li><a href="compare.html">Compare Products</a></li>
				  <li><a href="login.html">Login</a></li>
				</ul>
			  </li>
			  <li class="parent megamenu">
				<a href="#">Mega Menu</a>
				<ul class="sub">
				  <li class="promo-block box">
					<a href="#" class="big-image">
					  <img src="img/content/megamenu-big.png" width="240" height="434" alt="">
					</a>
				  </li><!-- .box.promo-block -->
				  
				  <li class="box first">
					<h6 class="title">Savant Apple Integration</h6>
					<ul>
					  <li><a href="#">iPad, iPod touch, iPhone & Mac Control</a></li>
					  <li><a href="#">iPod touch Remote Control</a></li>
					  <li><a href="#">Savant Host (Mac Mini)</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Audio/Video Control</h6>
					<ul>
					  <li><a href="#">Distributed Audio & Video</a></li>
					  <li><a href="#">Matrix Switchers</a></li>
					  <li><a href="#">Audio/Video Processing</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				</ul><!-- .sub -->
			  </li>
			  <li class="parent">
				<a href="#">Elements</a>
				<ul class="sub">
				  <li><a href="elements-accordions.html">Accordions &amp; Toggles</a></li>
				  <li><a href="elements-animations.html">Animations</a></li>
				  <li><a href="elements-buttons.html">Buttons &amp; Social Icons</a></li>
				  <li><a href="elements-carousel.html">Carousels &amp; Sliders</a></li>
				  <li><a href="elements-charts.html">Charts</a></li>
				  <li><a href="elements-container.html">Container</a></li>
				  <li><a href="elements-content-band.html">Content Band</a></li>
				  <li><a href="elements-dividers.html">Dividers & Gaps</a></li>
				  <li><a href="elements-featured-box.html">Featured Box</a></li>
				  <li><a href="elements-icons.html">Font Awesome Icons</a></li>
				  <li><a href="elements-frames.html">Frames</a></li>
				  <li><a href="elements-maps.html">Google Maps</a></li>
				  <li><a href="elements-media.html">Media</a></li>
				  <li><a href="elements-notification.html">Notification</a></li>
				  <li><a href="elements-person.html">Person</a></li>
				  <li><a href="elements-post-sliders.html">Posts Sliders</a></li>
				  <li><a href="elements-pricing.html">Pricing and Data Tables</a></li>
				  <li><a href="elements-sliders.html">Premium Sliders</a></li>
				  <li><a href="elements-progress-bar.html">Progress Bars</a></li>
				  <li><a href="elements-recent-posts.html">Recent Posts</a></li>
				  <li><a href="elements-shop.html">Shop Elements</a></li>
				  <li><a href="elements-tabs.html">Tabs</a></li>
				  <li><a href="elements-testimonials.html">Testimonials</a></li>
				  <li><a href="elements-works.html">Works</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Bootstrap</a>
				<ul class="sub">
				  <li><a href="typography-styles.html">Typography</a></li>
				  <li><a href="tables-styles.html">Tables</a></li>
				  <li><a href="forms-styles.html">Forms</a></li>
				  <li><a href="buttons-styles.html">Buttons</a></li>
				  <li><a href="tabs-styles.html">Tabs</a></li>
				  <li><a href="tooltips-styles.html">Tooltip</a></li>
				  <li><a href="accordions-styles.html">Accordions</a></li>
				</ul>
			  </li>
			</ul>
		  </nav>
		</div>
	  </div><!-- .primary -->
	  
	  <div class="span3">
		<div class="phone-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			  c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
			  M11.001,12H5V2h6V12z"/>
			</svg>
		  </a>
		</div><!-- .phone-header -->
		
		<div class="search-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </a>
		</div><!-- .search-header -->
	  </div>
	  
	  <div class="phone-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<span class="title">Call Us</span> <strong>+1 (777) 123 45 67</strong>
	  </div>
	  <div class="search-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<form name="search-form">
		  <input class="search-string" type="search" placeholder="Search here" name="search-string">
		  <button class="search-submit">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </button>
		</form>
	  </div>
	</div><!--.row -->
  </div>
</header><!-- .header -->

<div class="breadcrumb-box">
  <div class="container">
    <ul class="breadcrumb">
      <li><a href="index.html">Home</a> <span class="divider">/</span></li>
      <li><a href="#">Bootstrap</a> <span class="divider">/</span></li>
      <li class="active">Forms Styles</li>
    </ul>	
  </div>
</div><!-- .breadcrumb-box -->

<section id="main" class="page">
  <header class="page-header">
    <div class="container">
      <h1 class="title">Forms Styles</h1>
    </div>	
  </header>
  <div class="container">
    <div class="row">
	  <article class="content span12">
		<h2>Default styles</h2>
		<p>Individual form controls receive styling, but without any required base class on the <code>&lt;form&gt;</code> or large changes in markup. Results in stacked, left-aligned labels on top of form controls.</p>
		<form class="bs-docs-example">
		  <fieldset>
			<legend>Legend</legend>
			<label>Label name</label>
			<input type="text" placeholder="Type something...">
			<span class="help-block">Example block-level help text here.</span>
			<label class="checkbox">
			  <input type="checkbox" class="checked"> Check me out
			</label>
			<button type="submit" class="btn">Submit</button>
		  </fieldset>
		</form>
<pre class="prettyprint linenums">
&lt;form&gt;
  &lt;fieldset&gt;
    &lt;legend&gt;Legend&lt;/legend&gt;
    &lt;label&gt;Label name&lt;/label&gt;
    &lt;input type="text" placeholder="Type something…"&gt;
    &lt;span class="help-block"&gt;Example block-level help text here.&lt;/span&gt;
    &lt;label class="checkbox"&gt;
      &lt;input type="checkbox"&gt; Check me out
    &lt;/label&gt;
    &lt;button type="submit" class="btn"&gt;Submit&lt;/button&gt;
  &lt;/fieldset&gt;
&lt;/form&gt;
</pre>
		<hr class="bs-docs-separator">
		<br>
		  
		<h3>Search form</h3>
		<p>Add <code>.form-search</code> to the form and <code>.search-query</code> to the <code>&lt;input&gt;</code> for an extra-rounded text input.</p>
		<form class="bs-docs-example form-search">
		  <input type="text" class="input-medium search-query">
		  <button type="submit" class="btn">Search</button>
		</form>
<pre class="prettyprint linenums">
&lt;form class="form-search"&gt;
  &lt;input type="text" class="input-medium search-query"&gt;
  &lt;button type="submit" class="btn"&gt;Search&lt;/button&gt;
&lt;/form&gt;
</pre>

		<br>
		<h3>Inline form</h3>
		<p>Add <code>.form-inline</code> for left-aligned labels and inline-block controls for a compact layout.</p>
		<form class="bs-docs-example form-inline">
		  <input type="text" class="input-small" placeholder="Email">
		  <input type="password" class="input-small" placeholder="Password">
		  <label class="checkbox">
			<input type="checkbox"> Remember me
		  </label>
		  <button type="submit" class="btn">Sign in</button>
		</form>
<pre class="prettyprint linenums">
&lt;form class="form-inline"&gt;
  &lt;input type="text" class="input-small" placeholder="Email"&gt;
  &lt;input type="password" class="input-small" placeholder="Password"&gt;
  &lt;label class="checkbox"&gt;
    &lt;input type="checkbox"&gt; Remember me
  &lt;/label&gt;
  &lt;button type="submit" class="btn"&gt;Sign in&lt;/button&gt;
&lt;/form&gt;
</pre>

		<br>
		<h3>Horizontal form</h3>
		<p>Right align labels and float them to the left to make them appear on the same line as controls. Requires the most markup changes from a default form:</p>
		<ul>
		  <li>Add <code>.form-horizontal</code> to the form</li>
		  <li>Wrap labels and controls in <code>.control-group</code></li>
		  <li>Add <code>.control-label</code> to the label</li>
		  <li>Wrap any associated controls in <code>.controls</code> for proper alignment</li>
		</ul>
		<form class="bs-docs-example form-horizontal">
		  <div class="control-group">
			<label class="control-label" for="inputEmail">Email</label>
			<div class="controls">
			  <input type="text" id="inputEmail" placeholder="Email">
			</div>
		  </div>
		  <div class="control-group">
			<label class="control-label" for="inputPassword">Password</label>
			<div class="controls">
			  <input type="password" id="inputPassword" placeholder="Password">
			</div>
		  </div>
		  <div class="control-group">
			<div class="controls">
			  <label class="checkbox">
				<input type="checkbox"> Remember me
			  </label>
			  <button type="submit" class="btn">Sign in</button>
			</div>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;form class="form-horizontal"&gt;
  &lt;div class="control-group"&gt;
    &lt;label class="control-label" for="inputEmail"&gt;Email&lt;/label&gt;
    &lt;div class="controls"&gt;
      &lt;input type="text" id="inputEmail" placeholder="Email"&gt;
    &lt;/div&gt;
  &lt;/div&gt;
  &lt;div class="control-group"&gt;
    &lt;label class="control-label" for="inputPassword"&gt;Password&lt;/label&gt;
    &lt;div class="controls"&gt;
      &lt;input type="password" id="inputPassword" placeholder="Password"&gt;
    &lt;/div&gt;
  &lt;/div&gt;
  &lt;div class="control-group"&gt;
    &lt;div class="controls"&gt;
      &lt;label class="checkbox"&gt;
        &lt;input type="checkbox"&gt; Remember me
      &lt;/label&gt;
      &lt;button type="submit" class="btn"&gt;Sign in&lt;/button&gt;
    &lt;/div&gt;
  &lt;/div&gt;
&lt;/form&gt;
</pre>

        <hr class="bs-docs-separator">
		<br>
		
		<h2>Supported form controls</h2>
		<p>Examples of standard form controls supported in an example form layout.</p>
		
		<h3>Inputs</h3>
		<p>Most common form control, text-based input fields. Includes support for all HTML5 types: text, password, datetime, datetime-local, date, month, time, week, number, email, url, search, tel, and color.</p>
		<p>Requires the use of a specified <code>type</code> at all times.</p>
		<form class="bs-docs-example form-inline">
		  <input type="text" placeholder="Text input">
		</form>
<pre class="prettyprint linenums">
&lt;input type="text" placeholder="Text input"&gt;
</pre>

		<br>
		<h3>Textarea</h3>
		<p>Form control which supports multiple lines of text. Change <code>rows</code> attribute as necessary.</p>
		<form class="bs-docs-example form-inline">
		  <textarea rows="3"></textarea>
		</form>
<pre class="prettyprint linenums">
&lt;textarea rows="3"&gt;&lt;/textarea&gt;
</pre>

		<br>
		<h3>Checkboxes and radios</h3>
		<p>Checkboxes are for selecting one or several options in a list while radios are for selecting one option from many.</p>
		<br>
		<h4>Default (stacked)</h4>
		<form class="bs-docs-example">
		  <label class="checkbox">
			<input type="checkbox" value="">
			Option one is this and that&mdash;be sure to include why it's great
		  </label>
		  <br>
		  <label class="radio">
			<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>
			Option one is this and that&mdash;be sure to include why it's great
		  </label>
		  <label class="radio">
			<input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
			Option two can be something else and selecting it will deselect option one
		  </label>
		</form>
<pre class="prettyprint linenums">
&lt;label class="checkbox"&gt;
  &lt;input type="checkbox" value=""&gt;
  Option one is this and that&mdash;be sure to include why it's great
&lt;/label&gt;

&lt;label class="radio"&gt;
  &lt;input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked&gt;
  Option one is this and that&mdash;be sure to include why it's great
&lt;/label&gt;
&lt;label class="radio"&gt;
  &lt;input type="radio" name="optionsRadios" id="optionsRadios2" value="option2"&gt;
  Option two can be something else and selecting it will deselect option one
&lt;/label&gt;
</pre>

		<br>
		<h4>Inline checkboxes</h4>
		<p>Add the <code>.inline</code> class to a series of checkboxes or radios for controls appear on the same line.</p>
		<form class="bs-docs-example">
		  <label class="checkbox inline">
			<input type="checkbox" id="inlineCheckbox1" value="option1"> 1
		  </label>
		  <label class="checkbox inline">
			<input type="checkbox" id="inlineCheckbox2" value="option2"> 2
		  </label>
		  <label class="checkbox inline">
			<input type="checkbox" id="inlineCheckbox3" value="option3"> 3
		  </label>
		</form>
<pre class="prettyprint linenums">
&lt;label class="checkbox inline"&gt;
  &lt;input type="checkbox" id="inlineCheckbox1" value="option1"&gt; 1
&lt;/label&gt;
&lt;label class="checkbox inline"&gt;
  &lt;input type="checkbox" id="inlineCheckbox2" value="option2"&gt; 2
&lt;/label&gt;
&lt;label class="checkbox inline"&gt;
  &lt;input type="checkbox" id="inlineCheckbox3" value="option3"&gt; 3
&lt;/label&gt;
</pre>

		<br>
		<h3>Selects</h3>
		<p>Use the default option or specify a <code>multiple="multiple"</code> to show multiple options at once.</p>
		<form class="bs-docs-example">
		  <select>
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option>
			<option>5</option>
			<option>6</option>
		  </select>
		  <br>
		  <select multiple="multiple">
			<option>1</option>
			<option>2</option>
			<option>3</option>
			<option>4</option>
			<option>5</option>
			<option>6</option>
		  </select>
		</form>
<pre class="prettyprint linenums">
&lt;select&gt;
  &lt;option&gt;1&lt;/option&gt;
  &lt;option&gt;2&lt;/option&gt;
  &lt;option&gt;3&lt;/option&gt;
  &lt;option&gt;4&lt;/option&gt;
  &lt;option&gt;5&lt;/option&gt;
  &lt;option&gt;6&lt;/option&gt;
&lt;/select&gt;

&lt;select multiple="multiple"&gt;
  &lt;option&gt;1&lt;/option&gt;
  &lt;option&gt;2&lt;/option&gt;
  &lt;option&gt;3&lt;/option&gt;
  &lt;option&gt;4&lt;/option&gt;
  &lt;option&gt;5&lt;/option&gt;
  &lt;option&gt;6&lt;/option&gt;
&lt;/select&gt;
</pre>

        <hr class="bs-docs-separator">
	    
		<h2>Extending form controls</h2>
		<p>Adding on top of existing browser controls, Bootstrap includes other useful form components.</p>

		<br>
		<h3>Prepended and appended inputs</h3>
		<p>Add text or buttons before or after any text-based input. Do note that <code>select</code> elements are not supported here.</p>

		<br>
		<h4>Default options</h4>
		<p>Wrap an <code>.add-on</code> and an <code>input</code> with one of two classes to prepend or append text to an input.</p>
		<form class="bs-docs-example">
		  <div class="input-prepend">
			<span class="add-on">@</span>
			<input class="span2" id="prependedInput" type="text" placeholder="Username">
		  </div>
		  <br>
		  <div class="input-append">
			<input class="span2" id="appendedInput" type="text">
			<span class="add-on">.00</span>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;div class="input-prepend"&gt;
  &lt;span class="add-on"&gt;@&lt;/span&gt;
  &lt;input class="span2" id="prependedInput" type="text" placeholder="Username"&gt;
&lt;/div&gt;
&lt;div class="input-append"&gt;
  &lt;input class="span2" id="appendedInput" type="text"&gt;
  &lt;span class="add-on"&gt;.00&lt;/span&gt;
&lt;/div&gt;
</pre>

		<br>
		<h4>Combined</h4>
		<p>Use both classes and two instances of <code>.add-on</code> to prepend and append an input.</p>
		<form class="bs-docs-example form-inline">
		  <div class="input-prepend input-append">
			<span class="add-on">$</span>
			<input class="span2" id="appendedPrependedInput" type="text">
			<span class="add-on">.00</span>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;div class="input-prepend input-append"&gt;
  &lt;span class="add-on"&gt;$&lt;/span&gt;
  &lt;input class="span2" id="appendedPrependedInput" type="text"&gt;
  &lt;span class="add-on"&gt;.00&lt;/span&gt;
&lt;/div&gt;
</pre>

		<br>
		<h4>Buttons instead of text</h4>
		<p>Instead of a <code>&lt;span&gt;</code> with text, use a <code>.btn</code> to attach a button (or two) to an input.</p>
		<form class="bs-docs-example">
		  <div class="input-append">
			<input class="span2" id="appendedInputButton" type="text">
			<button class="btn" type="button">Go!</button>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;div class="input-append"&gt;
  &lt;input class="span2" id="appendedInputButton" type="text"&gt;
  &lt;button class="btn" type="button"&gt;Go!&lt;/button&gt;
&lt;/div&gt;
</pre>
		<form class="bs-docs-example">
		  <div class="input-append">
			<input class="span2" id="appendedInputButtons" type="text">
			<button class="btn" type="button">Search</button>
			<button class="btn" type="button">Options</button>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;div class="input-append"&gt;
  &lt;input class="span2" id="appendedInputButtons" type="text"&gt;
  &lt;button class="btn" type="button"&gt;Search&lt;/button&gt;
  &lt;button class="btn" type="button"&gt;Options&lt;/button&gt;
&lt;/div&gt;
</pre>

		<br>
		<h4>Button dropdowns</h4>
		<p></p>
		<form class="bs-docs-example">
		  <div class="input-append">
			<input class="span2" id="appendedDropdownButton" type="text">
			<div class="btn-group">
			  <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
			  <ul class="dropdown-menu">
				<li><a href="#">Action</a></li>
				<li><a href="#">Another action</a></li>
				<li><a href="#">Something else here</a></li>
				<li class="divider"></li>
				<li><a href="#">Separated link</a></li>
			  </ul>
			</div><!-- /btn-group -->
		  </div><!-- /input-append -->
		</form>
<pre class="prettyprint linenums">
&lt;div class="input-append"&gt;
  &lt;input class="span2" id="appendedDropdownButton" type="text"&gt;
  &lt;div class="btn-group"&gt;
    &lt;button class="btn dropdown-toggle" data-toggle="dropdown"&gt;
      Action
      &lt;span class="caret"&gt;&lt;/span&gt;
    &lt;/button&gt;
    &lt;ul class="dropdown-menu"&gt;
      ...
    &lt;/ul&gt;
  &lt;/div&gt;
&lt;/div&gt;
</pre>

		<form class="bs-docs-example">
		  <div class="input-prepend">
			<div class="btn-group">
			  <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
			  <ul class="dropdown-menu">
				<li><a href="#">Action</a></li>
				<li><a href="#">Another action</a></li>
				<li><a href="#">Something else here</a></li>
				<li class="divider"></li>
				<li><a href="#">Separated link</a></li>
			  </ul>
			</div><!-- /btn-group -->
			<input class="span2" id="prependedDropdownButton" type="text">
		  </div><!-- /input-prepend -->
		</form>
<pre class="prettyprint linenums">
&lt;div class="input-prepend"&gt;
  &lt;div class="btn-group"&gt;
    &lt;button class="btn dropdown-toggle" data-toggle="dropdown"&gt;
      Action
      &lt;span class="caret"&gt;&lt;/span&gt;
    &lt;/button&gt;
    &lt;ul class="dropdown-menu"&gt;
      ...
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;input class="span2" id="prependedDropdownButton" type="text"&gt;
&lt;/div&gt;
</pre>

		<form class="bs-docs-example">
		  <div class="input-prepend input-append">
			<div class="btn-group">
			  <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
			  <ul class="dropdown-menu">
				<li><a href="#">Action</a></li>
				<li><a href="#">Another action</a></li>
				<li><a href="#">Something else here</a></li>
				<li class="divider"></li>
				<li><a href="#">Separated link</a></li>
			  </ul>
			</div><!-- /btn-group -->
			<input class="span2" id="appendedPrependedDropdownButton" type="text">
			<div class="btn-group">
			  <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
			  <ul class="dropdown-menu">
				<li><a href="#">Action</a></li>
				<li><a href="#">Another action</a></li>
				<li><a href="#">Something else here</a></li>
				<li class="divider"></li>
				<li><a href="#">Separated link</a></li>
			  </ul>
			</div><!-- /btn-group -->
		  </div><!-- /input-prepend input-append -->
		</form>
<pre class="prettyprint linenums">
&lt;div class="input-prepend input-append"&gt;
  &lt;div class="btn-group"&gt;
    &lt;button class="btn dropdown-toggle" data-toggle="dropdown"&gt;
      Action
      &lt;span class="caret"&gt;&lt;/span&gt;
    &lt;/button&gt;
    &lt;ul class="dropdown-menu"&gt;
      ...
    &lt;/ul&gt;
  &lt;/div&gt;
  &lt;input class="span2" id="appendedPrependedDropdownButton" type="text"&gt;
  &lt;div class="btn-group"&gt;
    &lt;button class="btn dropdown-toggle" data-toggle="dropdown"&gt;
      Action
      &lt;span class="caret"&gt;&lt;/span&gt;
    &lt;/button&gt;
    &lt;ul class="dropdown-menu"&gt;
      ...
    &lt;/ul&gt;
  &lt;/div&gt;
&lt;/div&gt;
</pre>

		<br>
		<h4>Segmented dropdown groups</h4>
		<form class="bs-docs-example">
		  <div class="input-prepend">
			<div class="btn-group">
			  <button class="btn" tabindex="-1">Action</button>
			  <button class="btn dropdown-toggle" data-toggle="dropdown" tabindex="-1">
				<span class="caret"></span>
			  </button>
			  <ul class="dropdown-menu">
				<li><a href="#">Action</a></li>
				<li><a href="#">Another action</a></li>
				<li><a href="#">Something else here</a></li>
				<li class="divider"></li>
				<li><a href="#">Separated link</a></li>
			  </ul>
			</div>
			<input type="text">
		  </div>
		  <div class="input-append">
			<input type="text">
			<div class="btn-group">
			  <button class="btn" tabindex="-1">Action</button>
			  <button class="btn dropdown-toggle" data-toggle="dropdown" tabindex="-1">
				<span class="caret"></span>
			  </button>
			  <ul class="dropdown-menu">
				<li><a href="#">Action</a></li>
				<li><a href="#">Another action</a></li>
				<li><a href="#">Something else here</a></li>
				<li class="divider"></li>
				<li><a href="#">Separated link</a></li>
			  </ul>
			</div>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;form&gt;
  &lt;div class="input-prepend"&gt;
    &lt;div class="btn-group"&gt;...&lt;/div&gt;
    &lt;input type="text"&gt;
  &lt;/div&gt;
  &lt;div class="input-append"&gt;
    &lt;input type="text"&gt;
    &lt;div class="btn-group"&gt;...&lt;/div&gt;
  &lt;/div&gt;
&lt;/form&gt;
</pre>

		<br>
		<h4>Search form</h4>
		<form class="bs-docs-example form-search">
		  <div class="input-append">
			<input type="text" class="span2 search-query">
			<button type="submit" class="btn">Search</button>
		  </div>
		  <div class="input-prepend">
			<button type="submit" class="btn">Search</button>
			<input type="text" class="span2 search-query">
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;form class="form-search"&gt;
  &lt;div class="input-append"&gt;
    &lt;input type="text" class="span2 search-query"&gt;
    &lt;button type="submit" class="btn"&gt;Search&lt;/button&gt;
  &lt;/div&gt;
  &lt;div class="input-prepend"&gt;
    &lt;button type="submit" class="btn"&gt;Search&lt;/button&gt;
    &lt;input type="text" class="span2 search-query"&gt;
  &lt;/div&gt;
&lt;/form&gt;
</pre>

		<br>
		<h3>Control sizing</h3>
		<p>Use relative sizing classes like <code>.input-large</code> or match your inputs to the grid column sizes using <code>.span*</code> classes.</p>

		<br>
		<h4>Block level inputs</h4>
		<p>Make any <code>&lt;input&gt;</code> or <code>&lt;textarea&gt;</code> element behave like a block level element.</p>
		<form class="bs-docs-example" style="padding-bottom: 15px;">
		  <div class="controls">
			<input class="input-block-level" type="text" placeholder=".input-block-level">
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;input class="input-block-level" type="text" placeholder=".input-block-level"&gt;
</pre>

		<br>
		<h4>Relative sizing</h4>
		<form class="bs-docs-example" style="padding-bottom: 15px;">
		  <div class="controls docs-input-sizes">
			<input class="input-mini" type="text" placeholder=".input-mini">
			<input class="input-small" type="text" placeholder=".input-small">
			<input class="input-medium" type="text" placeholder=".input-medium">
			<input class="input-large" type="text" placeholder=".input-large">
			<input class="input-xlarge" type="text" placeholder=".input-xlarge">
			<input class="input-xxlarge" type="text" placeholder=".input-xxlarge">
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;input class="input-mini" type="text" placeholder=".input-mini"&gt;
&lt;input class="input-small" type="text" placeholder=".input-small"&gt;
&lt;input class="input-medium" type="text" placeholder=".input-medium"&gt;
&lt;input class="input-large" type="text" placeholder=".input-large"&gt;
&lt;input class="input-xlarge" type="text" placeholder=".input-xlarge"&gt;
&lt;input class="input-xxlarge" type="text" placeholder=".input-xxlarge"&gt;
</pre>
		<p>
		  <span class="label label-info">Heads up!</span> In future versions, we'll be altering the use of these relative input classes to match our button sizes. For example, <code>.input-large</code> will increase the padding and font-size of an input.
		</p>

		<br>
		<h4>Grid sizing</h4>
		<p>Use <code>.span1</code> to <code>.span12</code> for inputs that match the same sizes of the grid columns.</p>
		<form class="bs-docs-example" style="padding-bottom: 15px;">
		  <div class="controls docs-input-sizes">
			<input class="span1" type="text" placeholder=".span1">
			<input class="span2" type="text" placeholder=".span2">
			<input class="span3" type="text" placeholder=".span3">
			<select class="span1">
			  <option>1</option>
			  <option>2</option>
			  <option>3</option>
			  <option>4</option>
			  <option>5</option>
			</select>
			<select class="span2">
			  <option>1</option>
			  <option>2</option>
			  <option>3</option>
			  <option>4</option>
			  <option>5</option>
			</select>
			<select class="span3">
			  <option>1</option>
			  <option>2</option>
			  <option>3</option>
			  <option>4</option>
			  <option>5</option>
			</select>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;input class="span1" type="text" placeholder=".span1"&gt;
&lt;input class="span2" type="text" placeholder=".span2"&gt;
&lt;input class="span3" type="text" placeholder=".span3"&gt;
&lt;select class="span1"&gt;
  ...
&lt;/select&gt;
&lt;select class="span2"&gt;
  ...
&lt;/select&gt;
&lt;select class="span3"&gt;
  ...
&lt;/select&gt;
</pre>

		<p>For multiple grid inputs per line, <strong>use the <code>.controls-row</code> modifier class for proper spacing</strong>. It floats the inputs to collapse white-space, sets the proper margins, and clears the float.</p>
		<form class="bs-docs-example" style="padding-bottom: 15px;">
		  <div class="controls">
			<input class="span5" type="text" placeholder=".span5">
		  </div>
		  <div class="controls controls-row">
			<input class="span4" type="text" placeholder=".span4">
			<input class="span1" type="text" placeholder=".span1">
		  </div>
		  <div class="controls controls-row">
			<input class="span3" type="text" placeholder=".span3">
			<input class="span2" type="text" placeholder=".span2">
		  </div>
		  <div class="controls controls-row">
			<input class="span2" type="text" placeholder=".span2">
			<input class="span3" type="text" placeholder=".span3">
		  </div>
		  <div class="controls controls-row">
			<input class="span1" type="text" placeholder=".span1">
			<input class="span4" type="text" placeholder=".span4">
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;div class="controls"&gt;
  &lt;input class="span5" type="text" placeholder=".span5"&gt;
&lt;/div&gt;
&lt;div class="controls controls-row"&gt;
  &lt;input class="span4" type="text" placeholder=".span4"&gt;
  &lt;input class="span1" type="text" placeholder=".span1"&gt;
&lt;/div&gt;
...
</pre>

		<br>
		<h3>Uneditable inputs</h3>
		<p>Present data in a form that's not editable without using actual form markup.</p>
		<form class="bs-docs-example">
		  <span class="input-xlarge uneditable-input">Some value here</span>
		</form>
<pre class="prettyprint linenums">
&lt;span class="input-xlarge uneditable-input"&gt;Some value here&lt;/span&gt;
</pre>

		<br>
		<h3>Form actions</h3>
		<p>End a form with a group of actions (buttons). When placed within a <code>.form-actions</code>, the buttons will automatically indent to line up with the form controls.</p>
		<form class="bs-docs-example">
		  <div class="form-actions">
			<button type="submit" class="btn btn-primary">Save changes</button>
			<button type="button" class="btn">Cancel</button>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;div class="form-actions"&gt;
  &lt;button type="submit" class="btn btn-primary"&gt;Save changes&lt;/button&gt;
  &lt;button type="button" class="btn"&gt;Cancel&lt;/button&gt;
&lt;/div&gt;
</pre>

		<br>
		<h3>Help text</h3>
		<p>Inline and block level support for help text that appears around form controls.</p>
		<br>
		<h4>Inline help</h4>
		<form class="bs-docs-example form-inline">
		  <input type="text"> <span class="help-inline">Inline help text</span>
		</form>
<pre class="prettyprint linenums">
&lt;input type="text"&gt;&lt;span class="help-inline"&gt;Inline help text&lt;/span&gt;
</pre>

		<br>
		<h4>Block help</h4>
		<form class="bs-docs-example form-inline">
		  <input type="text">
		  <span class="help-block">A longer block of help text that breaks onto a new line and may extend beyond one line.</span>
		</form>
<pre class="prettyprint linenums">
&lt;input type="text"&gt;&lt;span class="help-block"&gt;A longer block of help text that breaks onto a new line and may extend beyond one line.&lt;/span&gt;
</pre>

        <hr class="bs-docs-separator">
		<br>
	    
		<h2>Form control states</h2>
		<p>Provide feedback to users or visitors with basic feedback states on form controls and labels.</p>

		<br>
		<h3>Input focus</h3>
		<p>We remove the default <code>outline</code> styles on some form controls and apply a <code>box-shadow</code> in its place for <code>:focus</code>.</p>
		<form class="bs-docs-example form-inline">
		  <input class="input-xlarge focused" id="focusedInput" type="text" value="This is focused...">
		</form>
<pre class="prettyprint linenums">
&lt;input class="input-xlarge" id="focusedInput" type="text" value="This is focused..."&gt;
</pre>

		<br>
		<h3>Invalid inputs</h3>
		<p>Style inputs via default browser functionality with <code>:invalid</code>. Specify a <code>type</code>, add the <code>required</code> attribute if the field is not optional, and (if applicable) specify a <code>pattern</code>.</p>
		<p>This is not available in versions of Internet Explorer 7-9 due to lack of support for CSS pseudo selectors.</p>
		<form class="bs-docs-example form-inline">
		  <input class="span3" type="email" placeholder="test@example.com" required>
		</form>
<pre class="prettyprint linenums">
&lt;input class="span3" type="email" required&gt;
</pre>

		<br>
		<h3>Disabled inputs</h3>
		<p>Add the <code>disabled</code> attribute on an input to prevent user input and trigger a slightly different look.</p>
		<form class="bs-docs-example form-inline">
		  <input class="input-xlarge" id="disabledInput" type="text" placeholder="Disabled input here…" disabled>
		</form>
<pre class="prettyprint linenums">
&lt;input class="input-xlarge" id="disabledInput" type="text" placeholder="Disabled input here..." disabled&gt;
</pre>

		<br>
		<h3>Validation states</h3>
		<p>Bootstrap includes validation styles for error, warning, info, and success messages. To use, add the appropriate class to the surrounding <code>.control-group</code>.</p>

		<form class="bs-docs-example form-horizontal">
		  <div class="control-group warning">
			<label class="control-label" for="inputWarning">Input with warning</label>
			<div class="controls">
			  <input type="text" id="inputWarning">
			  <span class="help-inline">Something may have gone wrong</span>
			</div>
		  </div>
		  <div class="control-group error">
			<label class="control-label" for="inputError">Input with error</label>
			<div class="controls">
			  <input type="text" id="inputError">
			  <span class="help-inline">Please correct the error</span>
			</div>
		  </div>
		  <div class="control-group info">
			<label class="control-label" for="inputInfo">Input with info</label>
			<div class="controls">
			  <input type="text" id="inputInfo">
			  <span class="help-inline">Username is taken</span>
			</div>
		  </div>
		  <div class="control-group success">
			<label class="control-label" for="inputSuccess">Input with success</label>
			<div class="controls">
			  <input type="text" id="inputSuccess">
			  <span class="help-inline">Woohoo!</span>
			</div>
		  </div>
		</form>
<pre class="prettyprint linenums">
&lt;div class="control-group warning"&gt;
  &lt;label class="control-label" for="inputWarning"&gt;Input with warning&lt;/label&gt;
  &lt;div class="controls"&gt;
    &lt;input type="text" id="inputWarning"&gt;
    &lt;span class="help-inline"&gt;Something may have gone wrong&lt;/span&gt;
  &lt;/div&gt;
&lt;/div&gt;

&lt;div class="control-group error"&gt;
  &lt;label class="control-label" for="inputError"&gt;Input with error&lt;/label&gt;
  &lt;div class="controls"&gt;
    &lt;input type="text" id="inputError"&gt;
    &lt;span class="help-inline"&gt;Please correct the error&lt;/span&gt;
  &lt;/div&gt;
&lt;/div&gt;

&lt;div class="control-group info"&gt;
  &lt;label class="control-label" for="inputInfo"&gt;Input with info&lt;/label&gt;
  &lt;div class="controls"&gt;
    &lt;input type="text" id="inputInfo"&gt;
    &lt;span class="help-inline"&gt;Username is already taken&lt;/span&gt;
  &lt;/div&gt;
&lt;/div&gt;

&lt;div class="control-group success"&gt;
  &lt;label class="control-label" for="inputSuccess"&gt;Input with success&lt;/label&gt;
  &lt;div class="controls"&gt;
    &lt;input type="text" id="inputSuccess"&gt;
    &lt;span class="help-inline"&gt;Woohoo!&lt;/span&gt;
  &lt;/div&gt;
&lt;/div&gt;
</pre>
	  </article><!-- .content -->
    </div>
  </div>
</section><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="span3 social">
          <h3>Follow Us</h3>
          <p>Follow us in social media</p>
          <a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a>
        </div>
        <div class="span3 newsletter">
          <h3>Newsletter</h3>
          <p>Sign up for newsletter</p>
          <form>
            <input class="input-block-level" type="email">
            <button class="submit"><i class="fa fa-arrow-circle-o-right"></i></button>
          </form>
        </div>
        <div class="span3 nav-box">
          <h3>Information</h3>
		  <nav>
			<ul>
			  <li><a href="#">About us</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">Terms & Condotions</a></li>
			  <li><a href="#">Secure payment</a></li>
			</ul>
		  </nav>
        </div>
        <div class="span3 nav-box">
          <h3>My account</h3>
		  <nav>
			<ul>
			  <li><a href="#">My account</a></li>
			  <li><a href="#">Order History</a></li>
			  <li><a href="#">Wish List</a></li>
			  <li><a href="#">Newsletter</a></li>
			</ul>
		  </nav>
        </div>
      </div>
    </div>
  </div><!-- .footer-top -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="span3 copyright">Copyright &copy; ItemBridge Inc., 2013</div>
        <div class="span3 phone">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#c6c6c6" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			   c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
				M11.001,12H5V2h6V12z"/>
			</svg>
		  </div>
          <strong class="title">Call Us:</strong> +1 (877) 123-45-67 <br>
          <strong>or</strong> +1 (777) 123-45-67
        </div>
        <div class="span3 address">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <g>
				<g>
				  <path fill="#c6c6c6" d="M8,16c-0.256,0-0.512-0.098-0.707-0.293C7.077,15.491,2,10.364,2,6c0-3.309,2.691-6,6-6
					c3.309,0,6,2.691,6,6c0,4.364-5.077,9.491-5.293,9.707C8.512,15.902,8.256,16,8,16z M8,2C5.795,2,4,3.794,4,6
					c0,2.496,2.459,5.799,4,7.536c1.541-1.737,4-5.04,4-7.536C12.001,3.794,10.206,2,8,2z"/>
				</g>
				<g>
				  <circle fill="#c6c6c6" cx="8.001" cy="6" r="2"/>
				</g>
			  </g>
			</svg>
		  </div>
          49 Archdale, 2B Charleston 5655, Excel Tower<br> OPG Rpad, 4538FH
        </div>
        <div class="span3">
          <a href="#" class="up pull-right"><i class="icon-arrow-up icon-white"></i></a>
        </div>
      </div>
    </div>
  </div><!-- .footer-bottom -->
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>