<!DOCTYPE html>
<html>
<head>
  <title>Newsletter Portfolio \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">
  <link href='http://fonts.googleapis.com/css?family=Arimo:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body style="background-color: #ffffff; color: #1e1e1e; font-family: 'Arimo', sans-serif; font-size: 14px; line-height: 22px; margin: 0; padding: 0;">
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; height: 105px;">
    <tr>
      <td style="text-align: left; vertical-align: top; padding-top: 25px;">
        <img src="img/newsletter/logo.png" alt="Logo" style="max-width: 170px;">
      </td>
      <td style="padding: 11px 0; text-align: right; vertical-align: top;">
        <small style="display: block; font-size: 11px; line-height: 16px; margin: 0 0 14px;">Trouble seeing something? <b>View it online</b></small>
        <h1 style="font-size: 18px; font-weight: bold; line-height: 1.3; margin: 0;">Multi-purpose responsive newsletter</h1>
      </td>
    </tr>
  </table>
    
  <div style="background: #f2f2f2; padding: 10px 0;">
    <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; position: relative;">
      <tr>
        <td style="text-align: left; vertical-align: top;">
          <img src="img/newsletter/banner.jpg" alt="Banner" style="max-width: 100%; display: block;">
          <div style="bottom: 0; left: 20px; right: 20px; top: 100px; padding: 28px 20px 20px; position: absolute;">
            <h2 style="background-color: #1e1e1e; background-color: rgba(30,30,30,.8); color: #fff; font-size: 20px; line-height: 24px; display: inline-block; font-weight: bold; margin: 0 0 5px; padding: 2px 5px;">Portfolio</h2>
            <br>
            <p style="background-color: #1e1e1e; background-color: rgba(30,30,30,.6); display: inline-block; clear: both; color: #fff; font-size: 12px; line-height: 18px; padding: 1px 3px; margin: 0">Multi-purpose responsive newsletter</p>
          </div>
        </td>
      </tr>
    </table>
  </div>
  
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; padding: 50px 0;">
    <tr>
      <td style="text-align: center; vertical-align: top; width: 32%;">
        <a href="#" style="text-decoration: none; display: block; line-height: 1; position: relative;">
          <img src="img/newsletter/image-1.jpg" alt="" style="max-width: 100%; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px;">
          <div style="
            background: -moz-linear-gradient(top, rgba(255,255,255,0) 0%, rgba(255,255,255,0.01) 29%, rgba(0,0,0,0.01) 30%, rgba(0,0,0,0.01) 33%, rgba(0,0,0,0.17) 62%, rgba(0,0,0,0.24) 68%, rgba(0,0,0,0.62) 90%, rgba(0,0,0,0.73) 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,255,255,0)), color-stop(29%,rgba(255,255,255,0.01)), color-stop(30%,rgba(0,0,0,0.01)), color-stop(33%,rgba(0,0,0,0.01)), color-stop(62%,rgba(0,0,0,0.17)), color-stop(68%,rgba(0,0,0,0.24)), color-stop(90%,rgba(0,0,0,0.62)), color-stop(100%,rgba(0,0,0,0.73)));
            background: -webkit-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -o-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -ms-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: linear-gradient(to bottom, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
          "></div>
          <div style="bottom: 5px; color: #fff; left: 0; position: absolute; right: 0; text-shadow: 0 1px #000;">
            <h3 style="font-size: 13px; font-weight: bold; line-height: 20px; margin: 0 0 6px;">Fusce tincidunt mollis</h3>
            <i style="font-family: Georgia; font-size: 11px; font-style: italic; line-height: 16px;">Web design</i>
          </div>
        </a>
      </td>
      
      <td style="width: 15px;"></td>
      
      <td style="text-align: center; vertical-align: top; width: 32%;">
        <a href="#" style="text-decoration: none; display: block; line-height: 1; position: relative;">
          <img src="img/newsletter/image-2.jpg" alt="" style="max-width: 100%; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px;">
          <div style="
            background: -moz-linear-gradient(top, rgba(255,255,255,0) 0%, rgba(255,255,255,0.01) 29%, rgba(0,0,0,0.01) 30%, rgba(0,0,0,0.01) 33%, rgba(0,0,0,0.17) 62%, rgba(0,0,0,0.24) 68%, rgba(0,0,0,0.62) 90%, rgba(0,0,0,0.73) 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,255,255,0)), color-stop(29%,rgba(255,255,255,0.01)), color-stop(30%,rgba(0,0,0,0.01)), color-stop(33%,rgba(0,0,0,0.01)), color-stop(62%,rgba(0,0,0,0.17)), color-stop(68%,rgba(0,0,0,0.24)), color-stop(90%,rgba(0,0,0,0.62)), color-stop(100%,rgba(0,0,0,0.73)));
            background: -webkit-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -o-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -ms-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: linear-gradient(to bottom, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
          "></div>
          <div style="bottom: 5px; color: #fff; left: 0; position: absolute; right: 0; text-shadow: 0 1px #000;">
            <h3 style="font-size: 13px; font-weight: bold; line-height: 20px; margin: 0 0 6px;">Fusce tincidunt mollis</h3>
            <i style="font-family: Georgia; font-size: 11px; font-style: italic; line-height: 16px;">Web design</i>
          </div>
        </a>
      </td>
      
      <td style="width: 15px;"></td>
      
      <td style="text-align: center; vertical-align: top; width: 32%;">
        <a href="#" style="text-decoration: none; display: block; line-height: 1; position: relative;">
          <img src="img/newsletter/image-3.jpg" alt="" style="max-width: 100%; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px;">
          <div style="
            background: -moz-linear-gradient(top, rgba(255,255,255,0) 0%, rgba(255,255,255,0.01) 29%, rgba(0,0,0,0.01) 30%, rgba(0,0,0,0.01) 33%, rgba(0,0,0,0.17) 62%, rgba(0,0,0,0.24) 68%, rgba(0,0,0,0.62) 90%, rgba(0,0,0,0.73) 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,255,255,0)), color-stop(29%,rgba(255,255,255,0.01)), color-stop(30%,rgba(0,0,0,0.01)), color-stop(33%,rgba(0,0,0,0.01)), color-stop(62%,rgba(0,0,0,0.17)), color-stop(68%,rgba(0,0,0,0.24)), color-stop(90%,rgba(0,0,0,0.62)), color-stop(100%,rgba(0,0,0,0.73)));
            background: -webkit-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -o-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -ms-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: linear-gradient(to bottom, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
          "></div>
          <div style="bottom: 5px; color: #fff; left: 0; position: absolute; right: 0; text-shadow: 0 1px #000;">
            <h3 style="font-size: 13px; font-weight: bold; line-height: 20px; margin: 0 0 6px;">Fusce tincidunt mollis</h3>
            <i style="font-family: Georgia; font-size: 11px; font-style: italic; line-height: 16px;">Web design</i>
          </div>
        </a>
      </td>
    </tr>
    
    <tr>
      <td colspan="5">
        <br>
      </td>
    </tr>
    
    <tr>
      <td style="text-align: center; vertical-align: top; width: 32%;">
        <a href="#" style="text-decoration: none; display: block; line-height: 1; position: relative;">
          <img src="img/newsletter/image-4.jpg" alt="" style="max-width: 100%; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px;">
          <div style="
            background: -moz-linear-gradient(top, rgba(255,255,255,0) 0%, rgba(255,255,255,0.01) 29%, rgba(0,0,0,0.01) 30%, rgba(0,0,0,0.01) 33%, rgba(0,0,0,0.17) 62%, rgba(0,0,0,0.24) 68%, rgba(0,0,0,0.62) 90%, rgba(0,0,0,0.73) 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,255,255,0)), color-stop(29%,rgba(255,255,255,0.01)), color-stop(30%,rgba(0,0,0,0.01)), color-stop(33%,rgba(0,0,0,0.01)), color-stop(62%,rgba(0,0,0,0.17)), color-stop(68%,rgba(0,0,0,0.24)), color-stop(90%,rgba(0,0,0,0.62)), color-stop(100%,rgba(0,0,0,0.73)));
            background: -webkit-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -o-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -ms-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: linear-gradient(to bottom, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
          "></div>
          <div style="bottom: 5px; color: #fff; left: 0; position: absolute; right: 0; text-shadow: 0 1px #000;">
            <h3 style="font-size: 13px; font-weight: bold; line-height: 20px; margin: 0 0 6px;">Fusce tincidunt mollis</h3>
            <i style="font-family: Georgia; font-size: 11px; font-style: italic; line-height: 16px;">Web design</i>
          </div>
        </a>
      </td>
      
      <td style="width: 15px;"></td>
      
      <td style="text-align: center; vertical-align: top; width: 32%;">
        <a href="#" style="text-decoration: none; display: block; line-height: 1; position: relative;">
          <img src="img/newsletter/image-5.jpg" alt="" style="max-width: 100%; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px;">
          <div style="
            background: -moz-linear-gradient(top, rgba(255,255,255,0) 0%, rgba(255,255,255,0.01) 29%, rgba(0,0,0,0.01) 30%, rgba(0,0,0,0.01) 33%, rgba(0,0,0,0.17) 62%, rgba(0,0,0,0.24) 68%, rgba(0,0,0,0.62) 90%, rgba(0,0,0,0.73) 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,255,255,0)), color-stop(29%,rgba(255,255,255,0.01)), color-stop(30%,rgba(0,0,0,0.01)), color-stop(33%,rgba(0,0,0,0.01)), color-stop(62%,rgba(0,0,0,0.17)), color-stop(68%,rgba(0,0,0,0.24)), color-stop(90%,rgba(0,0,0,0.62)), color-stop(100%,rgba(0,0,0,0.73)));
            background: -webkit-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -o-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -ms-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: linear-gradient(to bottom, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
          "></div>
          <div style="bottom: 5px; color: #fff; left: 0; position: absolute; right: 0; text-shadow: 0 1px #000;">
            <h3 style="font-size: 13px; font-weight: bold; line-height: 20px; margin: 0 0 6px;">Fusce tincidunt mollis</h3>
            <i style="font-family: Georgia; font-size: 11px; font-style: italic; line-height: 16px;">Web design</i>
          </div>
        </a>
      </td>
      
      <td style="width: 15px;"></td>
      
      <td style="text-align: center; vertical-align: top; width: 322px;">
        <a href="#" style="text-decoration: none; display: block; line-height: 1; position: relative;">
          <img src="img/newsletter/image-6.jpg" alt="" style="max-width: 100%; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px;">
          <div style="
            background: -moz-linear-gradient(top, rgba(255,255,255,0) 0%, rgba(255,255,255,0.01) 29%, rgba(0,0,0,0.01) 30%, rgba(0,0,0,0.01) 33%, rgba(0,0,0,0.17) 62%, rgba(0,0,0,0.24) 68%, rgba(0,0,0,0.62) 90%, rgba(0,0,0,0.73) 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,255,255,0)), color-stop(29%,rgba(255,255,255,0.01)), color-stop(30%,rgba(0,0,0,0.01)), color-stop(33%,rgba(0,0,0,0.01)), color-stop(62%,rgba(0,0,0,0.17)), color-stop(68%,rgba(0,0,0,0.24)), color-stop(90%,rgba(0,0,0,0.62)), color-stop(100%,rgba(0,0,0,0.73)));
            background: -webkit-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -o-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: -ms-linear-gradient(top, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            background: linear-gradient(to bottom, rgba(255,255,255,0) 0%,rgba(255,255,255,0.01) 29%,rgba(0,0,0,0.01) 30%,rgba(0,0,0,0.01) 33%,rgba(0,0,0,0.17) 62%,rgba(0,0,0,0.24) 68%,rgba(0,0,0,0.62) 90%,rgba(0,0,0,0.73) 100%);
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
          "></div>
          <div style="bottom: 5px; color: #fff; left: 0; position: absolute; right: 0; text-shadow: 0 1px #000;">
            <h3 style="font-size: 13px; font-weight: bold; line-height: 20px; margin: 0 0 6px;">Fusce tincidunt mollis</h3>
            <i style="font-family: Georgia; font-size: 11px; font-style: italic; line-height: 16px;">Web design</i>
          </div>
        </a>
      </td>
    </tr>
  </table>
  
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
    <tr>
      <td style="text-align: left; vertical-align: top;">
        <hr style="margin: 0; border: 0; border-bottom: 0 none; border-top: 1px solid #e1e1e1;">
      </td>
    </tr>
  </table>
  
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; padding: 50px 0;">
    <tr>
      <td style="text-align: left; vertical-align: top;">
        <h3 style="font-size: 24px; margin: 0 0 15px; font-weight: bold; line-height: 1.3;">
          <a href="#" style="color: #1e1e1e; text-decoration: none;">Home Theater</a>
        </h3>
        <p style="margin: 0 0 22px;">Etiam mollis volutpat odio, id euismod justo gravida. Aliquam erat volutpat. Phasellus faucibus venenatis lorem, vitae commodo elit pretium et. Sed orci nisi, elementum et accumsan at, egestas vel nisi. Duis a orci ligula, quis ultricies ipsum. Pellentesque vitae adipiscing nunc.</p>
        <a href="#" style="color: #fff; text-decoration: none; font-size: 10px; padding: 2px 10px; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; display: inline-block;">More</a>
      </td>
    </tr>
  </table>
    
  <div style="background: #f7f7f7; border-top: 1px solid #e1e1e1; color: #7f7f7f; font-size: 11px; line-height: 20px; padding: 20px 0;">
    <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
      <tr>
        <td style="text-align: left; vertical-align: top;">
          <span>If you no longer wish to receive emails please <b style="color: #1e1e1e;">unsubscribe</b>.
          <br>Copyright © ItemBridge inc., 2013</span>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #3b57a9; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 46px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/facebook.png" alt="facebook" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #1fb8e7; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/twitter.png" alt="twitter" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #eb6447; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/google.png" alt="google" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #2c6bb8; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/in.png" alt="in" style="max-width: 100%;">
          </a>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>
