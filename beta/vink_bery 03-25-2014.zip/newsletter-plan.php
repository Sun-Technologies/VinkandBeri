<!DOCTYPE html>
<html>
<head>
  <title>Newsletter Plan \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">
  <link href='http://fonts.googleapis.com/css?family=Arimo:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body style="background-color: #ffffff; color: #1e1e1e; font-family: 'Arimo', sans-serif; font-size: 14px; line-height: 22px; margin: 0; padding: 0;">
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; height: 105px;">
    <tr>
      <td style="text-align: left; vertical-align: top; padding-top: 25px;">
        <img src="img/newsletter/logo.png" alt="Logo" style="max-width: 170px;">
      </td>
      <td style="padding: 11px 0; text-align: right; vertical-align: top;">
        <small style="display: block; font-size: 11px; line-height: 16px; margin: 0 0 14px;">Trouble seeing something? <b>View it online</b></small>
        <h1 style="font-size: 18px; font-weight: bold; line-height: 1.3; margin: 0;">Multi-purpose responsive newsletter</h1>
      </td>
    </tr>
  </table>
  
  <table cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; width: 100%;">
    <tr>
      <td style="text-align: left; vertical-align: top;">
        <hr style="border: 0; border-bottom: 0 none; border-top: 1px solid #e1e1e1; margin: 0 0 35px;">
      </td>
    </tr>
  </table>
    
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
    <tr>
      <td style="text-align: left; vertical-align: top;">
        <div style="border: 1px solid #e1e1e1; overflow: hidden; padding: 30px;">
          <div style="float: left; width: 310px;">
            <h2 style="font-size: 24px; font-weight: bold; line-height: 1.3; margin: 0 0 22px;">
              <a href="#" style="color: #1e1e1e; text-decoration: none;">Example Package</a>
            </h2>
            <p style="color: #999; font-size: 12px; margin: 0 0 22px;">
              Aenean nec leo quam. Sed convallis  erat, fringilla pharetra metus gravida non. Proin consequat dignissim dui elementum imperdiet. Quisque accumsan justo at massa vestibulum interdum. Lorem ipsum dolor amet.
            </p>
            <div style="font-size: 12px;">
              <span>Starting at</span><br>
              <span style="display: block; line-height: 1; margin: 10px 0;"><span style="font-size: 36px; font-weight: bold;">$199</span>/mouns</span>
            </div>
            <a href="#" style="color: #fff; text-decoration: none; font-size: 10px; padding: 2px 10px; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; display: inline-block;">More</a>
          </div>
          <div style="float: right; padding: 55px 0 0; text-align: center; width: 250px;">
            <img src="img/newsletter/pricing-banner.png" alt="" style="max-width: 100%;">
          </div>
        </div>
      </td>
    </tr>
  </table>
  
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
    <tr>
      <td style="text-align: left; vertical-align: top;">
        <hr style="border: 0; border-bottom: 0 none; border-top: 1px solid #e1e1e1; margin: 40px 0;">
      </td>
    </tr>
  </table>
  
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
    <tr>
      <td style="text-align: left; vertical-align: top;">
        <h3 style="font-size: 16px; font-weight: bold; line-height: 1.3; margin: 0 0 22px; margin-bottom: 7px;"><a href="#" style="color: #1e1e1e; text-decoration: underline;">Pellentesque id augue</a></h3>
        <p style="margin: 0 0 22px; font-size: 12px;">Donec rutrum dignissim metus, et consectetur pellentesque. Aliquam erat volutpat. Phasellus faucibus venenatis lorem, vitae commodo elit pretium et. Duis a orci ligula, quis ultricies ipsum. Pellentesque vitae adipiscing nunc.</p>
      </td>
    </tr>
  </table>
  
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
    <tr>
      <td style="text-align: left; vertical-align: top; padding: 10px 0 40px; width: 32%;">
        <div style="background: #f7f7f7;">
	      <div style="line-height: 32px; padding: 17px 10px 21px;">
            <a href="#" style="color: #1e1e1e; font-size: 22px; font-weight: bold; line-height: 32px; text-decoration: none;">First Package</a>
          </div>
	      <div style="font-size: 12px; line-height: 1; moverflow: hidden; padding: 0 10px 10px;">
            <div style="background: #fff; -webkit-border-radius: 30px; -moz-border-radius: 30px; border-radius: 30px; color: #505050; float: right; height: 60px; text-align: center; width: 60px;">
              <img src="img/newsletter/pricing-1.png" alt="" style="max-width: 100%;">
            </div>
            <div>Starting at</div>
            <div style="font-size: 36px; font-weight: bold; margin: 13px 0 0;">$199<span style="font-size: 12px;">/month</span></div>
	      </div>
	      <ul style="list-style: none; margin: 0; padding: 0;">
            <li style="border-top: 1px solid #e1e1e1; color: #999; height: 39px; line-height: 39px; padding: 0 5px 0 25px; position: relative;">Responsive Design</li>
            <li style="border-top: 1px solid #e1e1e1; color: #999; height: 39px; line-height: 39px; padding: 0 5px 0 25px; position: relative;">Color Customization</li>
            <li style="border-top: 1px solid #e1e1e1; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span>✓</span> HTML5 & CSS3</li>
            <li style="border-top: 1px solid #e1e1e1; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span>✓</span> Styled elements</li>
            <li style="border-top: 1px solid #e1e1e1; color: #999; height: 39px; line-height: 39px; padding: 0 5px 0 25px; position: relative;">Easy Setup</li>
	      </ul>
          <div style="border-top: 1px solid #e1e1e1; overflow: hidden; padding: 9px 9px 10px;">
            <a href="#" style="color: #7f7f7f; display: block; float: left; font-size: 12px; line-height: 1; text-decoration: none;">Read more <span style="font-size: 18px; line-height: 10px; margin: 0 0 0 3px; vertical-align: top;">&#8250;</span></a>
            <div class="rating-box" style="background: url('img/rating-box.png') 0 0 no-repeat; float: right; height: 12px; width: 73px;">
              <div style="background: url('img/rating.png') 0 0 no-repeat; height: 12px; margin: 0; padding: 0; width: 80%"></div>
            </div>	
            <div style="clear: both;"></div>
            <button style="font-weight: bold; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; color: #fff; display: block; margin: 9px 0 0; padding: 16px 45px; font-size: 14px; width: 100%;">Buy Now</button>
	      </div>
	    </div>
      </td>
      
      <td style="width: 15px; text-align: left; vertical-align: top; padding: 0;"></td>
      
      <td style="text-align: left; vertical-align: top; padding: 10px 0 40px; width: 32%;">
        <div style="background: #f8fce8;">
	      <div style="line-height: 32px; padding: 17px 10px 21px;">
            <a href="#" style="color: #84a200; font-size: 22px; font-weight: bold; line-height: 32px; text-decoration: none;">Second Package</a>
          </div>
	      <div style="font-size: 12px; line-height: 1; moverflow: hidden; padding: 0 10px 10px;">
            <div style="background: #fff; -webkit-border-radius: 30px; -moz-border-radius: 30px; border-radius: 30px; color: #505050; float: right; height: 60px; text-align: center; width: 60px;">
              <img src="img/newsletter/pricing-2.png" alt="" style="max-width: 100%;">
            </div>
            <div>Starting at</div>
            <div style="font-size: 36px; font-weight: bold; margin: 13px 0 0;">$299<span style="font-size: 12px;">/month</span></div>
	      </div>
	      <ul style="list-style: none; margin: 0; padding: 0;">
            <li style="border-top: 1px solid #e3ebbe; color: #bbc398; height: 39px; line-height: 39px; padding: 0 5px 0 25px; position: relative;">Responsive Design</li>
            <li style="border-top: 1px solid #e3ebbe; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #84a200;">✓</span> Color Customization</li>
            <li style="border-top: 1px solid #e3ebbe; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #84a200;">✓</span> HTML5 & CSS3</li>
            <li style="border-top: 1px solid #e3ebbe; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #84a200;">✓</span> Styled elements</li>
            <li style="border-top: 1px solid #e3ebbe; color: #bbc398; height: 39px; line-height: 39px; padding: 0 5px 0 25px; position: relative;">Easy Setup</li>
	      </ul>
          <div style="background: #f0f8d0; border-top: 1px solid #e3ebbe; overflow: hidden; padding: 9px 9px 10px;">
            <a href="#" style="color: #84a200; display: block; float: left; font-size: 12px; line-height: 1; text-decoration: none;">Read more <span style="font-size: 18px; line-height: 10px; margin: 0 0 0 3px; vertical-align: top;">&#8250;</span></a>
            <div class="rating-box" style="background: url('img/rating-box.png') 0 -24px no-repeat; float: right; height: 12px; width: 73px;">
              <div style="background: url('img/rating.png') 0 -24px no-repeat; height: 12px; margin: 0; padding: 0; width: 60%"></div>
            </div>	
            <div style="clear: both;"></div>
            <button style="font-weight: bold; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #8aa902; border: 0 none; border-radius: 3px; color: #fff; display: block; margin: 9px 0 0; padding: 16px 45px; font-size: 14px; width: 100%;">Buy Now</button>
	      </div>
	    </div>
      </td>
      
      <td style="width: 15px; text-align: left; vertical-align: top; padding: 10px 0 40px;"></td>
      
      <td style="text-align: left; vertical-align: top; padding: 10px 0 40px; width: 32%;">
        <div style="background: #fcedf2;">
	      <div style="line-height: 32px; padding: 17px 10px 21px;">
            <a href="#" style="color: #d40746; font-size: 22px; font-weight: bold; line-height: 32px; text-decoration: none;">Third Package</a>
          </div>
	      <div style="font-size: 12px; line-height: 1; moverflow: hidden; padding: 0 10px 10px;">
            <div style="background: #fff; -webkit-border-radius: 30px; -moz-border-radius: 30px; border-radius: 30px; color: #505050; float: right; height: 60px; text-align: center; width: 60px;">
              <img src="img/newsletter/pricing-3.png" alt="" style="max-width: 100%;">
            </div>
            <div>Starting at</div>
            <div style="font-size: 36px; font-weight: bold; margin: 13px 0 0;">$199<span style="font-size: 12px;">/month</span></div>
	      </div>
	      <ul style="list-style: none; margin: 0; padding: 0;">
            <li style="border-top: 1px solid #ead2da; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #d40746;">✓</span> Responsive Design</li>
            <li style="border-top: 1px solid #ead2da; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #d40746;">✓</span> Color Customization</li>
            <li style="border-top: 1px solid #ead2da; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #d40746;">✓</span> HTML5 & CSS3</li>
            <li style="border-top: 1px solid #ead2da; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #d40746;">✓</span> Styled elements</li>
            <li style="border-top: 1px solid #ead2da; color: #1e1e1e; height: 39px; line-height: 39px; padding: 0 5px 0 10px; position: relative;"><span style="color: #d40746;">✓</span> Easy Setup</li>
	      </ul>
          <div style="background: #e9c2cf; border-top: 1px solid #ead2da; overflow: hidden; padding: 9px 9px 10px;">
            <a href="#" style="color: #d40746; display: block; float: left; font-size: 12px; line-height: 1; text-decoration: none;">Read more <span style="font-size: 18px; line-height: 10px; margin: 0 0 0 3px; vertical-align: top;">&#8250;</span></a>
            <div class="rating-box" style="background: url('img/rating-box.png') 0 -36px no-repeat; float: right; height: 12px; width: 73px;">
              <div style="background: url('img/rating.png') 0 -36px no-repeat; height: 12px; margin: 0; padding: 0; width: 80%"></div>
            </div>	
            <div style="clear: both;"></div>
            <button style="font-weight: bold; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #d70a49; border: 0 none; border-radius: 3px; color: #fff; display: block; margin: 9px 0 0; padding: 16px 45px; font-size: 14px; width: 100%;">Buy Now</button>
	      </div>
	    </div>
      </td>
    </tr></table><!-- .plan -->
    
  <div style="background: #f7f7f7; border-top: 1px solid #e1e1e1; color: #7f7f7f; font-size: 11px; line-height: 20px; padding: 20px 0;">
    <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
      <tr>
        <td style="text-align: left; vertical-align: top;">
          <span>If you no longer wish to receive emails please <b style="color: #1e1e1e;">unsubscribe</b>.
          <br>Copyright © ItemBridge inc., 2013</span>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #3b57a9; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 46px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/facebook.png" alt="facebook" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #1fb8e7; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/twitter.png" alt="twitter" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #eb6447; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/google.png" alt="google" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #2c6bb8; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/in.png" alt="in" style="max-width: 100%;">
          </a>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>