<!DOCTYPE html>
<html>
<head>
  <title>Vink & Beri LLC | ALOR Aloe Vera Juice</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta content="Vink & Beri LLC (V&B) is US arm of TGI group. TGI Group is one of the most respected groups and has businesses in 11 countries in Africa, Europe, Asia and Middle East besides US. TGI is the leading player in food products in African Continent. TGI has interest in production and trading of Commodities like Cotton, Insecticides, Sesame seeds and bulk Chemicals besides Pharmaceuticals, Deep Sea Fishing and as a support company to the majors companies in Deep Sea Oil Drilling.VINK & BERI LLC Company makes and sells branded plant-based foods and beverages, and premium dairy products throughout North America and Europe. And we do it in a way that's unlike any company in our industry. " name="keywords">
  <link href="img/favicon.png" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <style>
	#top-box,
	.carousel-box .next:hover,
	.carousel-box .prev:hover,
	.product .product-hover,
	#footer .up:hover,
    .btn,
    .btn:visited,
    .slider .slider-nav,
    .active .accordion-heading .accordion-toggle,
    .banner-set .pagination a:hover,
    .employee .employee-hover,
    .carousel-box .pagination a:hover,
    .sidebar .menu li.active > a,
    .pagination ul > li > a:hover,
    .sidebar .tags a:hover,
    .sidebar .banners .banner-text,
    #catalog .category-img .description,
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrapper,
    .product-bottom .related-products header:before,
    #slider.rs-slider .tparrows:hover,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .toolbar .grid-list a.grid:hover,
    .toolbar .grid-list a.list:hover,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a,
    .sidebar .menu li.parent > a .open-sub:before,
    .sidebar .menu li.parent > a .open-sub:after,
    .accordion-heading .accordion-toggle:before,
    .accordion-heading .accordion-toggle:after,
    .new-radio.checked span,
	.list .product .actions a:hover,
	.product-page .span7 .actions a:hover,
	.product-page .image-box .thumblist-box .prev:hover,
	.product-page .image-box .thumblist-box .next:hover,
    .btn.btn-inverse:hover,
    .btn.btn-inverse:focus,
    .btn.btn-inverse:active,
    .btn.btn-inverse.active,
    .btn.btn-inverse.disabled,
    .btn.btn-inverse[disabled],
	.accordion-tab > li > a .open-sub:before,
	.accordion-tab > li > a .open-sub:after,
	.products-tab .accordion-tab > li > a .open-sub:before,
	.products-tab .accordion-tab > li > a .open-sub:after {
	  background-color: #008644;
	}
    .slider .slider-nav {
      background-color: rgba(64,73,155,.97);
    }
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrappe,
	.product .product-hover,
	.rotation .employee-hover {
      background-color: #008644;
    }
    .btn:hover,
    .btn:focus,
    .btn:active,
    .btn.active,
    .btn.disabled,
    .btn[disabled] {
      background-color: #008644;
      background-color: rgba(64,73,155,.8);
    }
    #catalog .category-img .description,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a {
      background-color: rgba(64,73,155,.7);
    }
    .sidebar .banners .banner-text {
      background-color: rgba(64,73,155,.65);
    }
    #slider.rs-slider .tparrows,
	.product-page .add-cart-form .number .regulator a:hover {
      background-color: rgba(64,73,155,.5);
    }
	.pricing .bottom-box {
	  background-color: rgba(64,73,155,.05);
	}
	.pricing {
	  background-color: rgba(64,73,155,.06);
	}
	.pricing .options li,
	.pricing .bottom-box {
	  border-color: rgba(64,73,155,.1);
	}
	.header .cart-header .dropdown-toggle,
	#footer .newsletter input:focus + .submit,
    .icon,
    .big-icon,
    .big-icon:visited,
    .service .icon,
    .close:hover,
    .close:focus,
    .img-thumbnail:hover .bg-images i:before,
    .box-404 h1,
    .gallery-images:hover .bg-images i:before,
    .features-block .header-box .icon-box,
    .features-block .header-box,
    .sidebar .newsletter input:focus + .submit,
	.sidebar .section .selected .close:hover,
    .package .title a,
    .package .price-box .price,
    .package .price-box .icon,
    .pricing .title a,
    .pricing .options li span,
	.pricing .options li.active {
	  color: #008644;
	}
	.pricing .bottom-box .more {
	  color: rgba(64,73,155,.7);
	}
	.pricing .options li {
	  color: rgba(64,73,155,.4);
	}
	.phone-header a svg path,
	.search-header a svg path,
	.product .actions a svg path,
    .product-remove:hover path,
    .sidebar .wishlist .add-cart:hover path,
    .header .cart-header .dropdown-toggle .icon svg path,
    .search-active .search-submit svg path,
    .new-checkbox svg polygon,
	.product-bottom .related-products li .button-box .wishlist:hover svg path,
	.jslider .jslider-pointer svg path,
	.rating-box .rating svg polygon {
	  fill: #008644;
	}
    .carousel-box .pagination a.selected,
    .banner-set .pagination a.selected {
      background: #ccc;
	  background: rgba(0,0,0,.3);
    }
	@media (max-width: 979px) {
	  .header .primary .navbar .nav > .parent.active > a,
	  .header .primary .navbar .nav > .parent.active:hover > a,
	  .header .primary .navbar .nav .open-sub span,
	  .header .primary .navbar .btn-navbar .icon-bar,
	  .header.header-two .primary .navbar .btn-navbar.collapsed .icon-bar,
	  .accordion-tab > .active > a,
	  .accordion-tab > .active:hover > a,
	  .products-tab .accordion-tab > .active > a,
	  .products-tab .accordion-tab > .active:hover > a {
		background-color: #008644;
	  }
	}
	.navbar-inverse .brand,
	.navbar-inverse .nav > li > a,
	.btn-group.btn-select .dropdown-toggle,
	.product .product-hover,
	.employee .employee-hover,
	.slider .slid-content{
	  color: #fff;
	}
	.product .product-hover ul li {
	  background-image: url("img/svg/check-icon-white.svg"), none;
	}
  </style>
  
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body class="fixed-header">
<div class="page-box">
<div class="page-box-content">

<?php include 'header.php'; ?>

<div class="breadcrumb-box">
  <div class="container">
    <ul class="breadcrumb">
      <li><a href="index.html">Home</a> <span class="divider">/</span></li>
      <li><a href="catalog-grid.html">Products</a> <span class="divider">/</span></li>
      <li class="active">ALOR Aloe Vera Juice</li>
    </ul>	
  </div>
</div><!-- .breadcrumb-box -->

<div class="banner-set banner-set-mini load">
  <div class="container">
	<a class="prev" href="#"><i class="icon-arrow-left"></i></a>
	
	<div class="banners">
	  <a href="ALOR_aloevera_juice.php" class="banner">
		<img src="img/content/banner1.jpg" width="253" height="158" alt="">
		<h2 class="title">ALOR Aloe Vera Juice</h2>
	  </a>
	  <a href="ALOR_aloevera_chunks.php" class="banner">
		<img src="img/content/banner2.jpg" width="253" height="158" alt="">
		<h2 class="title">ALOR Aloe Vera Chunks</h2>
	  </a>
	  <a href="ALOR_aloe_vera_ coconut_water.php" class="banner">
		<img src="img/content/banner3.jpg" width="253" height="158" alt="">
		<h2 class="title">ALOR Aloe Vera Coconut Water</h2>
	  </a>
	  <a href="ALOR_coconut _water_with _coconut _chunks.php" class="banner">
		<img src="img/content/banner4.jpg" width="253" height="158" alt="">
		<h2 class="title">ALOR Coconut Water with Coconut Chunks</h2>
	  </a>
	  <a href="ALOR_orange_nector_with_real_mandarin_pieces.php" class="banner">
		<img src="img/content/banner5.jpg" width="253" height="158" alt="">
		<h2 class="title">ALOR Orange nector with real mandarin pieces.</h2>
	  </a>
	</div><!-- .banners -->
	
	<a class="next" href="#"><i class="icon-arrow-right"></i></a>
	<div class="clearfix"></div>
  </div>
</div><!-- .banner-set -->

<div id="main" class="page">
  <header class="page-header">
    <div class="container">
      <h1 class="title">ALOR Aloe Vera Coconut Water with Coconut Chunks</h1>
    </div>	
  </header>
  
  <div class="container">
    <div class="row">
      <article class="content span12 product-page">
		<div class="row">
		  <div class="span5">
			<div class="image-box">
			  <span class="sale top"></span>
			  <div class="general-img">
				<img alt="" src="img/content/single-1.png" data-zoom-image="img/content/single-1.png" width="700" height="700">
			  </div><!-- .general-img -->
			  
			  <div class="thumblist-box load">
				<a href="#" class="prev">
				  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
					<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="8,15.999 9,14.999 2,8 9,1.001 8,0.001 0,8 "/>
				  </svg>
				</a>
				<a href="#" class="next">
				  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
					<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="1,0.001 0,1.001 7,8 0,14.999 1,15.999 9,8 "/>
				  </svg>
				</a>
				
				<div id="thumblist" class="thumblist">
				  <a href="#" data-image="img/content/single-1.png" data-zoom-image="img/content/single-1.png">
					<img alt="" src="img/content/single-1.png" width="700" height="700">
				  </a>
				  <a class="active" href="#" data-image="img/content/single-2.png" data-zoom-image="img/content/single-2.png">
					<img alt="" src="img/content/single-2.png">
				  </a>
				  <a href="#" data-image="img/content/single-3.png" data-zoom-image="img/content/single-3.png">
					<img alt="" src="img/content/single-3.png" width="700" height="700">
				  </a>
				  <a href="#" data-image="img/content/single-1.png" data-zoom-image="img/content/single-1.png">
					<img alt="" src="img/content/single-1.png" width="700" height="700">
				  </a>
				  <a href="#" data-image="img/content/single-2.png" data-zoom-image="img/content/single-2.png">
					<img alt="" src="img/content/single-2.png" width="700" height="700">
				  </a>
				  <a href="#" data-image="img/content/single-3.png" data-zoom-image="img/content/single-3.png">
					<img alt="" src="img/content/single-3.png" width="700" height="700">
				  </a>
				</div><!-- #thumblist -->
			  </div><!-- .thumblist -->
			</div>
		  </div>
		  
		  <div class="span7">
			<h3>Product Description</h3>
			
			<div class="description">
					Introducing Alor Coconut Water wth Coconut Chunks- delicious water and tender coconut pieces together give you a natural burst of energy. Anytime anywhere!<br>

					It is naturally enriched with potassium, electrolytes and minerals to replenish hydration levels within the body. And it's totally devoid of fats. While you enjoy the succulent coconut chunks, the naturally occurring bioactive enzymes helps in digestion and metabolism.<br>

					Discover an active you. Just crack open a pack of Alor Coconut Water with Coconut Chunks.
			</div>
			
			<!--<div class="price-box">
			  <span class="price-old">$150</span> 
			  <span class="price">$119.00</span>
			</div>-->
			
			<h3>Nutrition Facts</h3>
			 
			<img width="300" align="right" src="img/content/Facts.png" alt="" style="margin-top:-120px;">
			
			
			
			<div class="description">
			  ALOE VERA JUICE DRINK WITH ALOE VERA PIECES : Alor Aloe Vera Juice is a All Natural Drink packed with ample benefits and goodness.It made from the real Aloe Vera pieces and contains no artificial colour or flavor. Prepared keeping in mind of providing ultimate taste of the Real Aloe Vera which can boost the energy to the peak.
Now, pick your favorite since it is an anytime drink- the taste and health which you always look for.
			</div>
		  </div>
		  
		  <div class="clearfix"></div>
		  
		  <div class="recommended-product carousel-box load">
			<div class="title-box span12">
			  <h2 class="title">Other Product</h2>
			</div>
			<div class="clearfix"></div>
			<div class="carousel products">
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-1.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html">ALOE VERA PIECES IN SYRUP</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html">ALOE VERA PIECES IN SYRUP</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-1.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>some text</li>
					<li>some text</li>
					<li>some text</li>
					<li>some text</li>
					<li>some text</li>
				  </ul>
			
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			  
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-2.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html">COCONUT WATER</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html">COCONUT WATER</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-2.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>Some Text</li>
					<li>Some Text</li>
					<li>Some Text</li>
					<li>Some Text</li>
					<li>Some Text</li>
				  </ul>
			
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			  
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-3.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html">ALOR ORANGE NECTAR WITH REAL MANDARIN PIECES</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html">ALOR ORANGE NECTAR WITH REAL MANDARIN PIECES</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-3.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>Some Text</li>
					<li>Some Text</li>
					<li>Some Text</li>
					<li>Some Text</li>
					<li>Some Text</li>
				  </ul>
				 
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			  
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-4.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html">COCONUT WATER WITH COCONUT CHUNKS</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html">COCONUT WATER WITH COCONUT CHUNKS</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-4.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>Some text</li>
					<li>Some text</li>
					<li>Some text</li>
					<li>Some text</li>
					<li>Some text</li>
				  </ul>
		
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			  
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-5.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html"> 800 Series Diamond</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html"> 800 Series Diamond</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-5.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>117 cm / 46"LCD TV</li>
					<li>Full HD 3D & 2D</li>
					<li>Sony Internet TV</li>
					<li>Dynamic Edge LED</li>
					<li>1X-Reality PRO</li>
				  </ul>
			
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			  
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-6.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html">AirPlay Hi-Fi system</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html">AirPlay Hi-Fi system</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-6.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>117 cm / 46"LCD TV</li>
					<li>Full HD 3D & 2D</li>
					<li>Sony Internet TV</li>
					<li>Dynamic Edge LED</li>
					<li>1X-Reality PRO</li>
				  </ul>
				  <div class="actions">
					<a href="product-view.html" class="add-cart">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
						<g>
						  <path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
							H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
							c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
							M13.001,14H3V6h10V14z"/>
						  <path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						  <path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						  <path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
						</g>
					  </svg>
					</a>
					<a href="#" class="add-wishlist">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
						s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
						s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					  </svg>
					</a>
					<a href="#" class="add-compare">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
						<path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
						<path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
						<path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					  </svg>
					</a>
				  </div><!-- .actions -->
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			  
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-7.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html">Sony Xperia Z</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html">Sony Xperia Z</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-7.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>117 cm / 46"LCD TV</li>
					<li>Full HD 3D & 2D</li>
					<li>Sony Internet TV</li>
					<li>Dynamic Edge LED</li>
					<li>1X-Reality PRO</li>
				  </ul>
				  <div class="actions">
					<a href="product-view.html" class="add-cart">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
						<g>
						  <path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
							H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
							c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
							M13.001,14H3V6h10V14z"/>
						  <path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						  <path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						  <path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
						</g>
					  </svg>
					</a>
					<a href="#" class="add-wishlist">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
						s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
						s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					  </svg>
					</a>
					<a href="#" class="add-compare">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
						<path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
						<path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
						<path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					  </svg>
					</a>
				  </div><!-- .actions -->
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			  
			  <div class="span3 product rotation">
				<div class="default">
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-8.png" alt="" title="" width="270" height="270">
				  </a>
				  <div class="product-description">
					<div class="vertical">
					  <h3 class="product-name">
					<a href="product-view.html">Xperia miro</a>
					  </h3>
					  <div class="price">$1, 449.00</div>	
					</div>
				  </div>
				</div>
				
				<div class="product-hover">
				  <h3 class="product-name">
					<a href="product-view.html">Xperia miro</a>
				  </h3>
				  <div class="price">$1, 449.00</div>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-8.png" alt="" title="" width="60" height="60">
				  </a>
				  <ul>
					<li>117 cm / 46"LCD TV</li>
					<li>Full HD 3D & 2D</li>
					<li>Sony Internet TV</li>
					<li>Dynamic Edge LED</li>
					<li>1X-Reality PRO</li>
				  </ul>
				  <div class="actions">
					<a href="product-view.html" class="add-cart">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
						<g>
						  <path fill="#1e1e1e" d="M15.001,4h-0.57l-3.707-3.707c-0.391-0.391-1.023-0.391-1.414,0c-0.391,0.391-0.391,1.023,0,1.414L11.603,4
							H4.43l2.293-2.293c0.391-0.391,0.391-1.023,0-1.414s-1.023-0.391-1.414,0L1.602,4H1C0.448,4,0,4.448,0,5s0.448,1,1,1
							c0,2.69,0,7.23,0,8c0,1.104,0.896,2,2,2h10c1.104,0,2-0.896,2-2c0-0.77,0-5.31,0-8c0.553,0,1-0.448,1-1S15.554,4,15.001,4z
							M13.001,14H3V6h10V14z"/>
						  <path fill="#1e1e1e" d="M11.001,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1s-1,0.447-1,1v4C10.001,12.553,10.448,13,11.001,13z"/>
						  <path fill="#1e1e1e" d="M8,13c0.553,0,1-0.447,1-1V8c0-0.553-0.448-1-1-1S7,7.447,7,8v4C7,12.553,7.448,13,8,13z"/>
						  <path fill="#1e1e1e" d="M5,13c0.553,0,1-0.447,1-1V8c0-0.553-0.447-1-1-1S4,7.447,4,8v4C4,12.553,4.448,13,5,13z"/>
						</g>
					  </svg>
					</a>
					<a href="#" class="add-wishlist">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <path fill="#1e1e1e" d="M11.335,0C10.026,0,8.848,0.541,8,1.407C7.153,0.541,5.975,0,4.667,0C2.088,0,0,2.09,0,4.667C0,12,8,16,8,16
						s8-4,8-11.333C16.001,2.09,13.913,0,11.335,0z M8,13.684C6.134,12.49,2,9.321,2,4.667C2,3.196,3.197,2,4.667,2C6,2,8,4,8,4
						s2-2,3.334-2c1.47,0,2.666,1.196,2.666,2.667C14.001,9.321,9.867,12.49,8,13.684z"/>
					  </svg>
					</a>
					<a href="#" class="add-compare">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
						  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
						<path fill="#1e1e1e" d="M16,3.063L13,0v2H1C0.447,2,0,2.447,0,3s0.447,1,1,1h12v2L16,3.063z"/>
						<path fill="#1e1e1e" d="M16,13.063L13,10v2H1c-0.553,0-1,0.447-1,1s0.447,1,1,1h12v2L16,13.063z"/>
						<path fill="#1e1e1e" d="M15,7H3V5L0,7.938L3,11V9h12c0.553,0,1-0.447,1-1S15.553,7,15,7z"/>
					  </svg>
					</a>
				  </div><!-- .actions -->
				</div><!-- .product-hover -->
			  </div><!-- .product -->
			</div>
		  </div><!-- .recommended-product -->
		</div>
      </article><!-- .content -->
    </div>
  </div>
</div><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<?php include 'footer.php'; ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>