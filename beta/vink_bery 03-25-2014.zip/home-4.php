<!DOCTYPE html>
<html>
<head>
  <title>Business Home \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <style>
	#top-box,
	.carousel-box .next:hover,
	.carousel-box .prev:hover,
	.product .product-hover,
	#footer .up:hover,
    .btn,
    .btn:visited,
    .slider .slider-nav,
    .active .accordion-heading .accordion-toggle,
    .banner-set .pagination a:hover,
    .employee .employee-hover,
    .carousel-box .pagination a:hover,
    .sidebar .menu li.active > a,
    .pagination ul > li > a:hover,
    .sidebar .tags a:hover,
    .sidebar .banners .banner-text,
    #catalog .category-img .description,
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrapper,
    .product-bottom .related-products header:before,
    #slider.rs-slider .tparrows:hover,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .toolbar .grid-list a.grid:hover,
    .toolbar .grid-list a.list:hover,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a,
    .sidebar .menu li.parent > a .open-sub:before,
    .sidebar .menu li.parent > a .open-sub:after,
    .accordion-heading .accordion-toggle:before,
    .accordion-heading .accordion-toggle:after,
    .new-radio.checked span,
	.list .product .actions a:hover,
	.product-page .span7 .actions a:hover,
	.product-page .image-box .thumblist-box .prev:hover,
	.product-page .image-box .thumblist-box .next:hover,
    .btn.btn-inverse:hover,
    .btn.btn-inverse:focus,
    .btn.btn-inverse:active,
    .btn.btn-inverse.active,
    .btn.btn-inverse.disabled,
    .btn.btn-inverse[disabled],
	.accordion-tab > li > a .open-sub:before,
	.accordion-tab > li > a .open-sub:after,
	.products-tab .accordion-tab > li > a .open-sub:before,
	.products-tab .accordion-tab > li > a .open-sub:after {
	  background-color: #c10841;
	}
    .slider .slider-nav {
      background-color: rgba(193,8,65,.97);
    }
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrappe,
	.product .product-hover,
	.rotation .employee-hover {
      background-color: rgba(193,8,65,.9);
    }
    .btn:hover,
    .btn:focus,
    .btn:active,
    .btn.active,
    .btn.disabled,
    .btn[disabled] {
      background-color: #c10841;
      background-color: rgba(193,8,65,.8);
    }
    #catalog .category-img .description,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a {
      background-color: rgba(193,8,65,.7);
    }
    .sidebar .banners .banner-text {
      background-color: rgba(193,8,65,.65);
    }
    #slider.rs-slider .tparrows,
	.product-page .add-cart-form .number .regulator a:hover {
      background-color: rgba(193,8,65,.5);
    }
	.pricing .bottom-box {
	  background-color: rgba(193,8,65,.05);
	}
	.pricing {
	  background-color: rgba(193,8,65,.06);
	}
	.pricing .options li,
	.pricing .bottom-box {
	  border-color: rgba(193,8,65,.1);
	}
	.header .cart-header .dropdown-toggle,
	#footer .newsletter input:focus + .submit,
    .icon,
    .big-icon,
    .big-icon:visited,
    .service .icon,
    .close:hover,
    .close:focus,
    .img-thumbnail:hover .bg-images i:before,
    .box-404 h1,
    .gallery-images:hover .bg-images i:before,
    .features-block .header-box .icon-box,
    .features-block .header-box,
    .sidebar .newsletter input:focus + .submit,
	.sidebar .section .selected .close:hover,
    .package .title a,
    .package .price-box .price,
    .package .price-box .icon,
    .pricing .title a,
    .pricing .options li span,
	.pricing .options li.active {
	  color: #c10841;
	}
	.pricing .bottom-box .more {
	  color: rgba(193,8,65,.7);
	}
	.pricing .options li {
	  color: rgba(193,8,65,.4);
	}
	.phone-header a svg path,
	.search-header a svg path,
	.product .actions a svg path,
    .product-remove:hover path,
    .sidebar .wishlist .add-cart:hover path,
    .header .cart-header .dropdown-toggle .icon svg path,
    .search-active .search-submit svg path,
    .new-checkbox svg polygon,
	.product-bottom .related-products li .button-box .wishlist:hover svg path,
	.jslider .jslider-pointer svg path,
	.rating-box .rating svg polygon {
	  fill: #c10841;
	}
    .carousel-box .pagination a.selected,
    .banner-set .pagination a.selected {
      background: #ccc;
	  background: rgba(0,0,0,.3);
    }
	@media (max-width: 979px) {
	  .header .primary .navbar .nav > .parent.active > a,
	  .header .primary .navbar .nav > .parent.active:hover > a,
	  .header .primary .navbar .nav .open-sub span,
	  .header .primary .navbar .btn-navbar .icon-bar,
	  .header.header-two .primary .navbar .btn-navbar.collapsed .icon-bar,
	  .accordion-tab > .active > a,
	  .accordion-tab > .active:hover > a,
	  .products-tab .accordion-tab > .active > a,
	  .products-tab .accordion-tab > .active:hover > a {
		background-color: #c10841;
	  }
	}
	.navbar-inverse .brand,
	.navbar-inverse .nav > li > a,
	.btn-group.btn-select .dropdown-toggle,
	.product .product-hover,
	.employee .employee-hover,
	.slider .slid-content{
	  color: #fff;
	}
	.product .product-hover ul li {
	  background-image: url("img/svg/check-icon-white.svg"), none;
	}
  </style>
  
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body class="fixed-header">
<div class="page-box">
<div class="page-box-content">

<header class="header header-two">
  <div class="container">
	<div class="row">
	  <div class="span2 logo-box">
		<a href="index.html" class="logo">
		  <img src="img/logo.svg" class="logo-img" alt="">
		</a>
	  </div>
	  <div class="span7 primary">
		<div class="navbar">
		  <a class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".primary .nav-collapse">
			<span class="text">Menu</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </a>
		  <nav class="nav-collapse collapse">
			<ul class="nav">
			  <li class="parent">
				<a href="index.html">Home</a>
				<ul class="sub">
				  <li><a href="index.html">Creative</a></li>
				  <li><a href="home-2.html">Paralax</a></li>
				  <li><a href="home-3.html">Simple</a></li>
				  <li><a href="home-4.html">Business</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Pages</a>
				<ul class="sub">
				  <li><a href="sidebar-blocks.html">All sidebar blocks</a></li>
				  <li><a href="full-width.html">Full Width</a></li>
				  <li><a href="left-sidebar.html">Left Sidebar</a></li>
				  <li><a href="right-sidebar.html">Right Sidebar</a></li>
				  <li><a href="about-us.html">About Us</a></li>
				  <li><a href="contact.html">Contact Us</a></li>
				  <li><a href="blog-list.html">Blog List</a></li>
				  <li><a href="blog-view.html">Blog Post View</a></li>
				  <li><a href="404.html">Page 404</a></li>
				  <li><a href="404-2.html">Page 404 (2)</a></li>
				  <li class="parent">
					<a href="#">Portfolio</a>
					<ul class="sub">
					  <li><a href="portfolio-1.html">Portfolio (1 column)</a></li>
					  <li><a href="portfolio-2.html">Portfolio (2 column)</a></li>
					  <li><a href="portfolio-3.html">Portfolio (3 column)</a></li>
					  <li><a href="portfolio-4.html">Portfolio (4 column)</a></li>
					  <li><a href="portfolio-slider.html">Portfolio (Slider)</a></li>
					  <li><a href="portfolio-single.html">Single Project</a></li>
					</ul>
				  </li>
				  <li><a href="gallery-modern.html">Modern Gallery</a></li>
				  <li class="parent">
					<a href="#">Gallery</a>
					<ul class="sub">
					  <li><a href="gallery-1.html">Gallery (1 column)</a></li>
					  <li><a href="gallery-2.html">Gallery (2 column)</a></li>
					  <li><a href="gallery-3.html">Gallery (3 column)</a></li>
					  <li><a href="gallery-4.html">Gallery (4 column)</a></li>
					</ul>
				  </li>
				  <li><a href="pricing.html">Pricing</a></li>
				  <li><a href="team.html">Team</a></li>
				  <li><a href="faq.html">FAQ</a></li>
				  <li><a href="services.html">Services</a></li>
				  <li><a href="careers.html">Careers</a></li>
				  <li><a href="coming-soon.html">Coming Soon</a></li>
				  <li><a href="under-construction.html">Under Construction</a></li>
				  <li><a href="sitemap.html">Sitemap</a></li>
				  <li class="parent">
					<a href="#">Newsletter</a>
					<ul class="sub">
					  <li><a href="newsletter-big-intro.html">Newsletter Big Intro</a></li>
					  <li><a href="newsletter-big-portfolio.html">Newsletter Big Portfolio</a></li>
					  <li><a href="newsletter-columns.html">Newsletter Columns</a></li>
					  <li><a href="newsletter-info.html">Newsletter Info</a></li>
					  <li><a href="newsletter-plan.html">Newsletter Plan</a></li>
					  <li><a href="newsletter-portfolio.html">Newsletter Portfolio</a></li>
					  <li><a href="newsletter-product-list.html">Newsletter Product List</a></li>
					  <li><a href="newsletter-story.html">Newsletter Story</a></li>
					</ul>
				  </li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="shop.html">Shop</a>
				<ul class="sub">
				  <li><a href="catalog-grid.html">Catalog (Grid)</a></li>
				  <li><a href="catalog-list.html">Catalog (List)</a></li>
				  <li><a href="product-view.html">Product View</a></li>
				  <li><a href="product-view-variants.html">Product View (Variants)</a></li>
				  <li><a href="cart.html">Shopping Cart</a></li>
				  <li><a href="checkout.html">Proceed to Checkout</a></li>
				  <li><a href="compare.html">Compare Products</a></li>
				  <li><a href="login.html">Login</a></li>
				</ul>
			  </li>
			  <li class="parent megamenu">
				<a href="#">Mega Menu</a>
				<ul class="sub">
				  <li class="promo-block box">
					<a href="#" class="big-image">
					  <img src="img/content/megamenu-big.png" width="240" height="434" alt="">
					</a>
				  </li><!-- .box.promo-block -->
				  
				  <li class="box first">
					<h6 class="title">Savant Apple Integration</h6>
					<ul>
					  <li><a href="#">iPad, iPod touch, iPhone & Mac Control</a></li>
					  <li><a href="#">iPod touch Remote Control</a></li>
					  <li><a href="#">Savant Host (Mac Mini)</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Audio/Video Control</h6>
					<ul>
					  <li><a href="#">Distributed Audio & Video</a></li>
					  <li><a href="#">Matrix Switchers</a></li>
					  <li><a href="#">Audio/Video Processing</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li><!-- .box -->
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li><!-- .box -->
				</ul><!-- .sub -->
			  </li>
			  <li class="parent">
				<a href="#">Elements</a>
				<ul class="sub">
				  <li><a href="elements-accordions.html">Accordions &amp; Toggles</a></li>
				  <li><a href="elements-animations.html">Animations</a></li>
				  <li><a href="elements-buttons.html">Buttons &amp; Social Icons</a></li>
				  <li><a href="elements-carousel.html">Carousels &amp; Sliders</a></li>
				  <li><a href="elements-charts.html">Charts</a></li>
				  <li><a href="elements-container.html">Container</a></li>
				  <li><a href="elements-content-band.html">Content Band</a></li>
				  <li><a href="elements-dividers.html">Dividers & Gaps</a></li>
				  <li><a href="elements-featured-box.html">Featured Box</a></li>
				  <li><a href="elements-icons.html">Font Awesome Icons</a></li>
				  <li><a href="elements-frames.html">Frames</a></li>
				  <li><a href="elements-maps.html">Google Maps</a></li>
				  <li><a href="elements-media.html">Media</a></li>
				  <li><a href="elements-notification.html">Notification</a></li>
				  <li><a href="elements-person.html">Person</a></li>
				  <li><a href="elements-post-sliders.html">Posts Sliders</a></li>
				  <li><a href="elements-pricing.html">Pricing and Data Tables</a></li>
				  <li><a href="elements-sliders.html">Premium Sliders</a></li>
				  <li><a href="elements-progress-bar.html">Progress Bars</a></li>
				  <li><a href="elements-recent-posts.html">Recent Posts</a></li>
				  <li><a href="elements-shop.html">Shop Elements</a></li>
				  <li><a href="elements-tabs.html">Tabs</a></li>
				  <li><a href="elements-testimonials.html">Testimonials</a></li>
				  <li><a href="elements-works.html">Works</a></li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="#">Bootstrap</a>
				<ul class="sub">
				  <li><a href="typography-styles.html">Typography</a></li>
				  <li><a href="tables-styles.html">Tables</a></li>
				  <li><a href="forms-styles.html">Forms</a></li>
				  <li><a href="buttons-styles.html">Buttons</a></li>
				  <li><a href="tabs-styles.html">Tabs</a></li>
				  <li><a href="tooltips-styles.html">Tooltip</a></li>
				  <li><a href="accordions-styles.html">Accordions</a></li>
				</ul>
			  </li>
			</ul>
		  </nav>
		</div>
	  </div><!-- .primary -->
	  
	  <div class="span3">
		<div class="phone-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			  c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
			  M11.001,12H5V2h6V12z"/>
			</svg>
		  </a>
		</div><!-- .phone-header -->
		
		<div class="search-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </a>
		</div><!-- .search-header -->
	  </div>
	  
	  <div class="phone-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<span class="title">Call Us</span> <strong>+1 (777) 123 45 67</strong>
	  </div>
	  <div class="search-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<form name="search-form">
		  <input class="search-string" type="search" placeholder="Search here" name="search-string">
		  <button class="search-submit">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </button>
		</form>
	  </div>
	</div><!--.row -->
  </div>
</header><!-- .header -->

<div id="slider" class="rs-slider load">
  <div class="tp-banner-container">
	<div class="tp-banner" >
	  <ul>
		<li data-delay="7000" data-transition="fade" data-slotamount="7" data-masterspeed="2000">
		  <div class="elements">
			<div class="tp-caption lfl"
			  data-x="211"
			  data-y="203"
			  data-speed="1000"
			  data-start="1500"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 2">
			  <img src="img/content/slider/rs-slider4-img1.png" alt="">
			</div>
			
			<div class="tp-caption lft"
			  data-x="97"
			  data-y="271"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  <img src="img/content/slider/rs-slider4-img2.png" alt="">
			</div>
			
			<div class="tp-caption lft"
			  data-x="479"
			  data-y="271"
			  data-speed="1000"
			  data-start="1200"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  <img src="img/content/slider/rs-slider4-img2.png" alt="">
			</div>
			
			<div class="tp-caption lfb"
			  data-x="-32"
			  data-y="372"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  <img src="img/content/slider/rs-slider4-img3.png" alt="">
			</div>
			
			<div class="tp-caption lft"
			  data-x="166"
			  data-y="167"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  <img src="img/content/slider/rs-slider4-img4.png" alt="">
			</div>
			
			<div class="tp-caption customin"
			  data-x="177"
			  data-y="62"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 100%;"
			  data-speed="700"
			  data-start="1400"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 3">
			  <img src="img/content/slider/rs-slider4-img5.png" alt="">
			</div>
			
			<div class="tp-caption lft"
			  data-x="487"
			  data-y="69"
			  data-speed="1000"
			  data-start="1500"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 1">
			  <img src="img/content/slider/rs-slider4-img6.png" alt="">
			</div>
			
			<div class="tp-caption lfl"
			  data-x="539"
			  data-y="177"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 3">
			  <img src="img/content/slider/rs-slider4-img7.png" alt="">
			</div>
			
			<div class="tp-caption lfl lft"
			  data-x="-33"
			  data-y="134"
			  data-speed="1000"
			  data-start="1700"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 3">
			  <img src="img/content/slider/rs-slider4-img8.png" alt="">
			</div>
			
			<div class="tp-caption customin"
			  data-x="375"
			  data-y="78"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1000"
			  data-start="1500"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  <img src="img/content/slider/rs-slider4-img9.png" alt="">
			</div>
			
			<div class="tp-caption lfb"
			  data-x="141"
			  data-y="297"
			  data-speed="1000"
			  data-start="1800"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider4-img10.png" alt="">
			</div>
			
			<div class="tp-caption lfl"
			  data-x="428"
			  data-y="356"
			  data-speed="500"
			  data-start="2000"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 3">
			  <img src="img/content/slider/rs-slider4-img11.png" alt="">
			</div>
			
			<div class="tp-caption lfb"
			  data-x="225"
			  data-y="335"
			  data-speed="1000"
			  data-start="1880"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider4-img12.png" alt="">
			</div>
			
			<div class="tp-caption lfb"
			  data-x="258"
			  data-y="341"
			  data-speed="1000"
			  data-start="1960"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider4-img13.png" alt="">
			</div>
			
			<div class="tp-caption lfb"
			  data-x="395"
			  data-y="335"
			  data-speed="1000"
			  data-start="2040"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider4-img14.png" alt="">
			</div>
			
			<h2 class="tp-caption lft skewtotop title span6"
			  data-x="722"
			  data-y="101"
			  data-speed="1000"
			  data-start="1700"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  <strong>DIY</strong>
			</h2>
			
			<div class="tp-caption lfr skewtoright description span6"
			  data-x="722"
			  data-y="189"
			  data-speed="1000"
			  data-start="1500"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  <p>We added <strong>more than 80 items</strong> to the standard page design.<br>
			  You can form the page yourself by placing any information<br>
			  you want – graphs, tables, buttons, slides, animated<br>
			  content, maps and so on.</p>
			</div>

			<a href="#" class="btn cherry tp-caption lfb"
			  data-x="722"
			  data-y="332"
			  data-speed="1000"
			  data-start="1700"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn">
			  Read more
			</a>
		  </div>
		  
		  <img src="img/content/slider/rs-slider4-bg.jpg" alt="" data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
		</li>
		
		<li data-delay="7000" data-transition="fade" data-slotamount="7" data-masterspeed="2000">
		  <div class="elements">
			<div class="tp-caption lfb skewtobottom"
			  data-x="145"
			  data-y="66"
			  data-speed="1000"
			  data-start="500"
			  data-easing="Power4.easeOut"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 3">
			  <img src="img/content/slider/rs-slider1-phone.png" alt="">
			</div>
			
			<div class="tp-caption lfb skewtobottom"
			  data-x="307"
			  data-y="105"
			  data-speed="1000"
			  data-start="500"
			  data-easing="Power4.easeOut"
			  data-endspeed="400"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 1">
			  <img src="img/content/slider/rs-slider1-phone-bg.png" alt="">
			</div>
			
			<h2 class="tp-caption sft skewtotop title span6"
			  data-x="590"
			  data-y="101"
			  data-speed="1000"
			  data-start="500"
			  data-easing="Power4.easeOut"
			  data-endspeed="400"
			  data-endeasing="Power1.easeIn">
			  Clean & Valid code
			</h2>
			
			<div class="tp-caption lfr skewtoright description span6"
			  data-x="590"
			  data-y="189"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="400"
			  data-endeasing="Power1.easeIn">
			  <p>Perfect HTML5 & CSS3. Valid code, latest technologies, always<br>
			  up-to-date. Compatible with the latest desktop and mobile<br>
			  browsers down to IE8. Works perfectly wherever you need<br>
			  and wherever you want.</p>
			</div>

			<a href="#" class="btn tp-caption customin cherry"
			  data-x="590"
			  data-y="332"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1200"
			  data-start="1400"
			  data-easing="Power3.easeInOut"
			  data-endspeed="300"
			  style="z-index: 5">
			  Read more
			</a>

			<div class="tp-caption customin customout"
			  data-x="337"
			  data-y="148"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1200"
			  data-start="800"
			  data-easing="Power3.easeInOut"
			  data-endspeed="300"
			  style="z-index: 5">
			  <img src="img/content/slider/rs-slider1-html5-1.png" alt="">
			</div>
			
			<div class="tp-caption customin"
			  data-x="355"
			  data-y="158"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1200"
			  data-start="1200"
			  data-easing="Power3.easeInOut"
			  data-end="3300"
			  data-endspeed="400"
			  style="z-index: 5">
			  <img src="img/content/slider/rs-slider1-html5-2.png" alt="">
			</div>
			
			<div class="tp-caption customin"
			  data-x="355"
			  data-y="158"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1200"
			  data-start="3700"
			  data-easing="Power3.easeInOut"
			  data-endspeed="100"
			  style="z-index: 5">
			  <img src="img/content/slider/rs-slider1-css3.png" alt="">
			</div>
			
			<div class="tp-caption lfb skewtobottom customin customout phone-text"
			  data-x="359"
			  data-y="325"
			  data-customin="x:0;y:55;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:55;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power0.easeOut"
			  data-end="3500"
			  data-endspeed="400"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 2">
			  HTML5
			</div>
			
			<div class="tp-caption lfb skewtobottom customin customout phone-text"
			  data-x="365"
			  data-y="325"
			  data-customin="x:0;y:55;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:55;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1000"
			  data-start="3600"
			  data-easing="Power0.easeOut"
			  data-endspeed="400"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 2">
			  CSS3
			</div>
		  </div>
		  
		  <img src="img/content/slider/rs-slider1-bg.jpg" alt="" data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
		</li>
		
		<li data-delay="10300" data-transition="fade" data-slotamount="7" data-masterspeed="2000" class="slid2">
		  <div class="elements">
			<h2 class="tp-caption sft skewtotop title span6"
			  data-x="0"
			  data-y="101"
			  data-speed="1000"
			  data-start="1100"
			  data-easing="Power4.easeOut"
			  data-endspeed="400"
			  data-endeasing="Power1.easeIn">
			  Four homepages
			</h2>
			
			<div class="tp-caption lfl skewtoleft description span6"
			  data-x="0"
			  data-y="189"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="400"
			  data-endeasing="Power1.easeIn">
			  <p>We have developed four different homepages for you to choose<br>
			  the most convenient one. Make your choice based on your own<br>
			  taste and sense of style, use extra elements and Twitter<br>
			  Bootstrap to build any page you want.</p>
			</div>

			<a href="#" class="btn btn-primary tp-caption customin"
			  data-x="0"
			  data-y="332"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1200"
			  data-start="1000"
			  data-easing="Power3.easeInOut"
			  data-endspeed="300"
			  style="z-index: 5">
			  Read more
			</a>
			
			<div class="tp-caption lfb skewtobottom customin"
			  data-x="right"
			  data-hoffset="100"
			  data-y="70"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:-360;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1000"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-end="14000"
			  data-endspeed="500"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 3">
			  <img src="img/content/slider/rs-slider2-img.png" alt="">
			</div>
			
			<div class="tp-caption lfb customout"
			  data-x="right"
			  data-hoffset="-126"
			  data-y="70"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="400"
			  data-start="2000"
			  data-easing="Power0.easeOut"
			  data-end="3000"
			  data-endspeed="400"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 2">
			  <img src="img/content/slider/rs-slider2-homepage1.png" alt="">
			</div>
			
			<div class="tp-caption lfb customout"
			  data-x="right"
			  data-hoffset="-126"
			  data-y="70"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="400"
			  data-start="3500"
			  data-easing="Power0.easeOut"
			  data-end="4500"
			  data-endspeed="400"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 2">
			  <img src="img/content/slider/rs-slider2-homepage2.png" alt="">
			</div>
			
			<div class="tp-caption lfb customout"
			  data-x="right"
			  data-hoffset="-126"
			  data-y="70"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="400"
			  data-start="5000"
			  data-easing="Power0.easeOut"
			  data-end="6000"
			  data-endspeed="400"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 2">
			  <img src="img/content/slider/rs-slider2-homepage3.png" alt="">
			</div>
			
			<div class="tp-caption lfb customout"
			  data-x="right"
			  data-hoffset="-126"
			  data-y="70"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="400"
			  data-start="6500"
			  data-easing="Power0.easeOut"
			  data-end="7500"
			  data-endspeed="400"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 2">
			  <img src="img/content/slider/rs-slider2-homepage4.png" alt="">
			</div>
			
			<div class="tp-caption  customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="2300"
			  data-easing="Power0.easeOut"
			  data-end="3800"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-one.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="3800"
			  data-easing="Power0.easeOut"
			  data-end="5300"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-two.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="5300"
			  data-easing="Power0.easeOut"
			  data-end="6800"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-three.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="6800"
			  data-easing="Power0.easeOut"
			  data-end="8000"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-four.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="8200"
			  data-easing="Power0.easeOut"
			  data-end="8300"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-four.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="8400"
			  data-easing="Power0.easeOut"
			  data-end="8500"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-four.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="8600"
			  data-easing="Power0.easeOut"
			  data-end="8700"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-four.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-208"
			  data-y="130"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="8800"
			  data-easing="Power0.easeOut"
			  data-end="8900"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-four.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-239"
			  data-y="187"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="9000"
			  data-easing="Power0.easeOut"
			  data-end="10300"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-quadrate1.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-224"
			  data-y="172"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="9100"
			  data-easing="Power0.easeOut"
			  data-end="10200"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-quadrate2.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-209"
			  data-y="157"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="9200"
			  data-easing="Power0.easeOut"
			  data-end="10100"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-quadrate3.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-194"
			  data-y="142"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="9300"
			  data-easing="Power0.easeOut"
			  data-end="10000"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-quadrate4.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-179"
			  data-y="127"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="9400"
			  data-easing="Power0.easeOut"
			  data-end="9900"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-quadrate5.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-164"
			  data-y="112"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="9500"
			  data-easing="Power0.easeOut"
			  data-end="9800"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-quadrate6.png" alt="">
			</div>
			
			<div class="tp-caption customin customout"
			  data-x="right"
			  data-hoffset="-149"
			  data-y="97"
			  data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:1;transformPerspective:600;transformOrigin:50% 50%;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1"
			  data-start="9600"
			  data-easing="Power0.easeOut"
			  data-end="9700"
			  data-endspeed="1"
			  data-endeasing="Power0.easeIn"
			  data-captionhidden="on"
			  style="z-index: 4">
			  <img src="img/content/slider/rs-slider2-quadrate7.png" alt="">
			</div>
		  </div>
		  
		  <img src="img/content/slider/rs-slider2-bg.jpg" alt="" data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
		</li>
		
		<li data-delay="8000" data-transition="fade" data-slotamount="7" data-masterspeed="2000">
		  <div class="elements">
			<div class="tp-caption lfl skewtoleft"
			  data-x="left"
			  data-hoffset="-127"
			  data-y="bottom"
			  data-speed="1500"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="1000"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 1">
			  <img src="img/content/slider/rs-slider3-pig.png" alt="">
			</div>
			
			<div class="tp-caption lfl skewtoleft"
			  data-x="left"
			  data-hoffset="-127"
			  data-y="bottom"
			  data-speed="1500"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="1000"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 3">
			  <img src="img/content/slider/rs-slider3-pig2.png" alt="">
			</div>

			<h2 class="tp-caption lft skewtotop title span3"
			  data-x="509"
			  data-y="122"
			  data-speed="1500"
			  data-start="1000"
			  data-easing="Power0.easeOut"
			  data-endspeed="1000"
			  data-endeasing="Power1.easeIn">
			  <strong>Save money</strong>
			</h2>
			
			<h2 class="tp-caption lfr skewtoright title span3"
			  data-x="755"
			  data-y="122"
			  data-speed="1500"
			  data-start="1000"
			  data-easing="Power4.easeOut"
			  data-endspeed="1000"
			  data-endeasing="Power1.easeIn">
			  on additional plugin!
			</h2>
			
			<div class="tp-caption customin customout description span6"
			  data-x="509"
			  data-y="196"
			  data-customin="x:0;y:0;z:50;rotationX:90;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0;"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="1000"
			  data-start="1500"
			  data-easing="Back.easeInOut"
			  data-endspeed="400"
			  data-endeasing="Power1.easeIn">
			  <p>Create a responsive or fullwidth slider with must-see-effects.<br>
			  Plugin features tons of unique transition effects, an image<br>
			  preloader, video embedding, autoplay and lots of easy to<br>
			  set options to create your own effects.</p>
			</div>

			<a href="#" class="tp-caption btn orang lfb skewtobottom"
			  data-x="509"
			  data-y="338"
			  data-speed="1000"
			  data-start="1500"
			  data-easing="Power3.easeInOut"
			  data-endspeed="300">
			  Read more
			</a>

			<div class="tp-caption lft customout"
			  data-x="130"
			  data-y="140"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="500"
			  data-start="2200"
			  data-easing="Power4.easeOut"
			  data-end="2400"
			  data-endspeed="100"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 2">
			  <img src="img/content/slider/rs-slider3-coin.png" alt="">
			</div>
			
			<div class="tp-caption lft customout"
			  data-x="130"
			  data-y="30"
			  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			  data-speed="500"
			  data-start="2700"
			  data-easing="Power4.easeOut"
			  data-endeasing="Power1.easeIn"
			  style="z-index: 2">
			  <img src="img/content/slider/rs-slider3-coin.png" alt="">
			</div>
		  </div>
		  
		  <img src="img/content/slider/rs-slider3-bg.jpg" alt="" data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
		</li>
	  </ul>
	  <div class="tp-bannertimer"></div>
	</div>
  </div>
</div><!-- .rs-slider -->

<section id="main">
  <div class="container">
	<article class="content">
	  <div class="row">
		<div class="span12 title-box text-center">
		  <h1 class="title">About Us</h1>
		</div>
		
		<div class="span6 bottom-padding">
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quam facilis odit inventore laudantium eligendi rem architecto possimus cupiditate in.</p>
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque quidem voluptatum distinctio reiciendis blanditiis magni ex dolorum hic soluta sunt laboriosam asperiores architecto est repellat cum explicabo ipsam ab quis quaerat animi accusantium voluptates reprehenderit ipsa consequuntur inventore nobis nisi?</p>
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis debitis mollitia adipisci perspiciatis excepturi nemo id nisi assumenda velit quaerat accusamus soluta vitae animi vero ut odit ipsum aliquam voluptatibus?</p>
		</div>
		
		<div class="span6 bottom-padding">
		  <div class="accordion" id="accordion">
			<div class="accordion-group active" data-appear-animation="fadeInRightBig">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
				  Portfolio Pages
				</a>
			  </div>
			  <div id="collapseOne" class="accordion-body collapse in">
				<div class="accordion-inner">
				  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iure omnis expedita at necessitatibus iusto laudantium rem magni dolore quibusdam veritatis!
				</div>
			  </div>
			</div>
			
			<div class="accordion-group" data-appear-animation="fadeInRightBig">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
				  Gallery Pages
				</a>
			  </div>
			  <div id="collapseTwo" class="accordion-body collapse">
				<div class="accordion-inner">
				  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque natus quaerat voluptate? Asperiores hic dolore voluptate corporis obcaecati reiciendis sunt ipsam iste. Eligendi inventore voluptatibus quia saepe odit deserunt nam?
				</div>
			  </div>
			</div>
			
			<div class="accordion-group" data-appear-animation="fadeInRightBig">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
				  Styles Pages
				</a>
			  </div>
			  <div id="collapseThree" class="accordion-body collapse">
				<div class="accordion-inner">
				  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima quod aliquid aspernatur cumque enim dolores eum inventore quo fugit earum. Tenetur aliquam quos nostrum ad fugiat voluptatum doloribus omnis debitis necessitatibus repellat inventore commodi ut reiciendis ipsam ducimus dicta amet eligendi rem impedit nulla. Repellat corporis aperiam ipsam voluptas possimus quidem tempore laudantium quia incidunt repudiandae ducimus iure dolorum maiores nam unde eveniet obcaecati reiciendis quibusdam quaerat fugiat excepturi debitis culpa asperiores. Culpa provident nemo aliquid modi quo optio accusantium dolor porro cum repudiandae autem blanditiis minus deserunt. Corporis aut sapiente vero earum doloribus rerum velit expedita magni sit repudiandae.
				</div>
			  </div>
			</div>
			
			<div class="accordion-group" data-appear-animation="fadeInRightBig">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapsefour">
				  Shop Pages
				</a>
			  </div>
			  <div id="collapsefour" class="accordion-body collapse">
				<div class="accordion-inner">
				  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur maiores hic voluptatum delectus in cum dolor! Temporibus distinctio tempore optio illum animi. Dignissimos ipsum officia hic itaque rerum dolorem distinctio cupiditate sed temporibus eius facere autem debitis quibusdam qui dolore! Quae unde neque saepe itaque omnis nemo eum similique libero cupiditate eius quod a totam nihil commodi nisi animi eos nam fugiat ipsum dicta ex excepturi id sequi ipsa quaerat rerum culpa iste minima accusamus ad! Libero assumenda adipisci molestias!
				</div>
			  </div>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <div class="row">
		<div class="span12 title-box text-center">
		  <h1 class="title">Our Team</h1>
		</div>
		
		<div class="span6 bottom-padding">
		  <div class="progress progress-warning progress-striped active" data-appear-progress-animation="80%">
			<div class="bar">Web Design 80%</div>
		  </div>
		  
		  <div class="progress progress-danger progress-striped active" data-appear-progress-animation="70%">
			<div class="bar">HTML/CSS 70%</div>
		  </div>
		  
		  <div class="progress progress-success progress-striped active no-margin" data-appear-progress-animation="40%">
			<div class="bar">Opencart 40%</div>
		  </div>
		</div>
		
		<div class="span6 bottom-padding">
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quam facilis odit inventore laudantium eligendi rem architecto possimus cupiditate in.</p>
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque quidem voluptatum distinctio reiciendis blanditiis magni ex dolorum hic soluta sunt laboriosam asperiores architecto est repellat cum explicabo ipsam ab quis quaerat animi accusantium voluptates reprehenderit ipsa consequuntur inventore nobis nisi?</p>
		</div>
	  </div>
	  
	  <div class="carousel-box bottom-padding bottom-padding-mini load overflow">
		<div class="title-box no-margin">
		  <a class="next" href="#">
			<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			  width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="1,0.001 0,1.001 7,8 0,14.999 1,15.999 9,8 "/>
			</svg>
		  </a>
		  <a class="prev" href="#">
			<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			  width="9px" height="16px" viewBox="0 0 9 16" enable-background="new 0 0 9 16" xml:space="preserve">
			  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#fcfcfc" points="8,15.999 9,14.999 2,8 9,1.001 8,0.001 0,8 "/>
			</svg>
		  </a>
		  <h2 class="title">Meet Our Team</h2>
		</div>
		<div class="clearfix"></div>
		<div class="row">
		  <div class="carousel">
			<div class="span3 employee rotation">
			  <div class="default">
				<div class="image">
				  <img src="img/content/team-1.jpg" alt="" title="" width="270" height="270">
				</div>
				<div class="description">
				  <div class="vertical">
					<h3 class="name">Mett Rayan</h3>
					<div class="role">Manager</div>	
				  </div>
				</div>
			  </div>
			  <div class="employee-hover">
				<h3 class="name">Mett Rayan</h3>
				<div class="role">Manager</div>
				<div class="image">
				  <img src="img/content/team-1.jpg" alt="" title="" width="270" height="270">
				</div>
				<div>
				  <p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				  <div class="contact"><b>Email: </b>mett@itembridge.com</div>
				  <div class="contact"><b>Phone: </b>11 555 333 77</div>
				</div>
				<div class="social">
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
				</div>
			  </div><!-- .employee-hover -->
			</div><!-- .employee -->
			
			<div class="span3 employee rotation">
			  <div class="default">
				<div class="image">
				  <img src="img/content/team-2.jpg" alt="" title="" width="270" height="270">
				</div>
				<div class="description">
				  <div class="vertical">
					<h3 class="name">Mett Rayan</h3>
					<div class="role">Manager</div>	
				  </div>
				</div>
			  </div>
			  <div class="employee-hover">
				<h3 class="name">Mett Rayan</h3>
				<div class="role">Manager</div>
				<div class="image">
				  <img src="img/content/team-2.jpg" alt="" title="" width="270" height="270">
				</div>
				<div>
				  <p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				  <div class="contact"><b>Email: </b>mett@itembridge.com</div>
				  <div class="contact"><b>Phone: </b>11 555 333 77</div>
				</div>
				<div class="social">
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
				</div>
			  </div><!-- .employee-hover -->
			</div><!-- .employee -->
			
			<div class="span3 employee rotation">
			  <div class="default">
				<div class="image">
				  <img src="img/content/team-3.jpg" alt="" title="" width="270" height="270">
				</div>
				<div class="description">
				  <div class="vertical">
					<h3 class="name">Mett Rayan</h3>
					<div class="role">Manager</div>	
				  </div>
				</div>
			  </div>
			  <div class="employee-hover">
				<h3 class="name">Mett Rayan</h3>
				<div class="role">Manager</div>
				<div class="image">
				  <img src="img/content/team-3.jpg" alt="" title="" width="270" height="270">
				</div>
				<div>
				  <p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				  <div class="contact"><b>Email: </b>mett@itembridge.com</div>
				  <div class="contact"><b>Phone: </b>11 555 333 77</div>
				</div>
				<div class="social">
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
				</div>
			  </div><!-- .employee-hover -->
			</div><!-- .employee -->
			
			<div class="span3 employee rotation">
			  <div class="default">
				<div class="image">
				  <img src="img/content/team-4.jpg" alt="" title="" width="270" height="270">
				</div>
				<div class="description">
				  <div class="vertical">
					<h3 class="name">Mett Rayan</h3>
					<div class="role">Manager</div>	
				  </div>
				</div>
			  </div>
			  <div class="employee-hover">
				<h3 class="name">Mett Rayan</h3>
				<div class="role">Manager</div>
				<div class="image">
				  <img src="img/content/team-4.jpg" alt="" title="" width="270" height="270">
				</div>
				<div>
				  <p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				  <div class="contact"><b>Email: </b>mett@itembridge.com</div>
				  <div class="contact"><b>Phone: </b>11 555 333 77</div>
				</div>
				<div class="social">
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
				</div>
			  </div><!-- .employee-hover -->
			</div><!-- .employee -->
			
			<div class="span3 employee rotation">
			  <div class="default">
				<div class="image">
				  <img src="img/content/team-5.jpg" alt="" title="" width="270" height="270">
				</div>
				<div class="description">
				  <div class="vertical">
					<h3 class="name">Mett Rayan</h3>
					<div class="role">Manager</div>	
				  </div>
				</div>
			  </div>
			  <div class="employee-hover">
				<h3 class="name">Mett Rayan</h3>
				<div class="role">Manager</div>
				<div class="image">
				  <img src="img/content/team-5.jpg" alt="" title="" width="270" height="270">
				</div>
				<div>
				  <p>Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</p>
				  <div class="contact"><b>Email: </b>mett@itembridge.com</div>
				  <div class="contact"><b>Phone: </b>11 555 333 77</div>
				</div>
				<div class="social">
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a></div>
				  <div class="item"><a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a></div>
				</div>
			  </div><!-- .employee-hover -->
			</div><!-- .employee -->
		  </div>
		</div>
	  </div>
	  
	  <div class="row bottom-padding bottom-padding-mini">
		<div class="span12 title-box text-center">
		  <h1 class="title">Services</h1>
		</div>
		
		<div class="span4 big-services-box">
		  <a href="#">
			<div class="big-icon bg" data-appear-animation="fadeInUp"><i class="fa fa-picture-o"></i></div>
			<h4 class="title">Web Design</h4>
			<div class="text-small">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat.</div>
		  </a>
		</div><!-- .services-box-two -->
		
		<div class="span4 big-services-box">
		  <a href="#">
			<div class="big-icon bg" data-appear-animation="fadeInUp"><i class="fa fa-wrench"></i></div>
			<h4 class="title">Graphic Design</h4>
			<div class="text-small">The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those intereste. It is a long established fact that a reader.</div>
		  </a>
		</div><!-- .services-box-two -->
		
		<div class="span4 big-services-box">
		  <a href="#">
			<div class="big-icon bg" data-appear-animation="fadeInUp"><i class="fa fa-bug"></i></div>
			<h4 class="title">Internet Marketing</h4>
			<div class="text-small">The readable content of a page when looking at its layout. The point of using. Duis aute irure dolor reprehenderit in voluptate velit esse cillum.</div>
		  </a>
		</div><!-- .services-box-two -->
	  </div>
	  
	  <div class="full-width-box bottom-padding">
		<div class="bg"><div class="overlay overlay-100 background-red"></div></div>
		<div class="row">
		  <div class="span6 content-box white">
			<div>Meet the Resr of</div>
			<h2 class="title light">Bring viewing <strong>to life in HD</strong></h2>
			<p class="description">
			  We added more than 80 items to the standard page design.<br>
			  You can form the page yourself by placing any information<br>
			  you want – graphs, tables, buttons, slides, animated
			</p>
			<button class="btn btn-white">Buy now</button>
			<br><br>
		  </div>
		  <div class="span6 images-box">
			<img src="img/content/promo-slider.png" width="568" height="351" alt="">
		  </div>
		</div>
		<div class="clearfix"></div>
	  </div><!-- .full-width-box -->
	  
	  <div class="bottom-padding bottom-padding-mini">
		<div class="title-box text-center">
		  <h1 class="title">Portfolio</h1>
		</div>
		
		<div class="portfolio">
		  <div class="filter-buttons pull-left">
			<a href="#" class="active" data-filter="*">All</a>
			<a href="#" data-filter=".web-design">Web Design</a>
			<a href="#" data-filter=".graphic-design">Graphic Design</a>
			<a href="#" data-filter=".ecommerce">eCommerce</a>
		  </div><!-- .filter-buttons -->
		  
		  <div class="year-regulator pull-right">
			<b>Year:</b>
			<div class="layout-slider span4">
			  <input id="filter" type="slider" name="year" value="2000;2013" />
			</div>
		  </div><!-- .price-regulator -->
		  
		  <div class="clearfix"></div>
	  
		  <div class="row filter-elements">
			<div class="span4 web-design">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-1.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Morbi non lacus ac sapien molestie</h3>
			  <div class="description">Web design</div>
				</div>
			  </a>
			</div>
			<div class="span4 graphic-design">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-2.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Sed at turpis tortor bibendum </h3>
			  <div class="description">Web design</div>
				</div>
			  </a>
			</div>
			<div class="span4 ecommerce">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-3.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Mauris quis sapien mass</h3>
			  <div class="description">Web design</div>
				</div>
			  </a>
			</div>
			<div class="span4 web-design">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-4.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Donec pulvinar pulvinar arcu</h3>
			  <div class="description">Other</div>
				</div>
			  </a>
			</div>
			<div class="span4 web-design">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-5.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Proin faucibus pretium</h3>
			  <div class="description">Web design</div>
				</div>
			  </a>
			</div>
			<div class="span4 graphic-design">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-6.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Pellentesque in dui mauris</h3>
			  <div class="description">Other</div>
				</div>
			  </a>
			</div>
			<div class="span4 ecommerce">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-7.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Vivamus auctor metus porta</h3>
			  <div class="description">Web design</div>
				</div>
			  </a>
			</div>
			<div class="span4 ecommerce">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-8.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Quisque nec lorem vel metus ultrices</h3>
			  <div class="description">Web design</div>
				</div>
			  </a>
			</div>
			<div class="span4 web-design">
			  <a href="portfolio-single.html" class="work">
				<img src="img/content/portfolio-9.jpg" width="370" height="270" alt="">
				<span class="shadow"></span>
				<div class="bg-hover"></div>
				<div class="work-title">
			  <h3 class="title">Proin faucibus pretium</h3>
			  <div class="description">Web design</div>
				</div>
			  </a>
			</div>
		  </div>
		</div>
	  </div>
	  
	  <div class="bottom-padding">
		<div class="title-box text-center">
		  <h1 class="title">Pricing</h1>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio quaerat nemo nam quibusdam doloribus quo minima iure sequi vitae optio consequatur necessitatibus fugit voluptatem voluptas sapiente quis cupiditate. Esse minus sequi molestias qui quibusdam voluptatem minima neque laborum architecto facere.</p>
		<br><br>
		<div class="row pricings">
		  <div class="span3">
			<div class="pricing">
			  <div class="title"><a href="#">First Package</a></div>
			  <div class="price-box">
				<div class="icon pull-right circle"><i class="icon-android"></i></div>
				<div class="starting">Starting at</div>
				<div class="price">$199<span>/month</span></div>
			  </div>
			  <ul class="options">
				<li><span><i class="fa fa-check"></i></span>Responsive Design</li>
				<li><span><i class="fa fa-check"></i></span>Color Customization</li>
				<li class="active"><span><i class="fa fa-check"></i></span>HTML5 & CSS3</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Styled elements</li>
				<li><span><i class="fa fa-check"></i></span>Easy Setup</li>
			  </ul>
			  <div class="bottom-box">
				<a href="#" class="more">Read more <span>&#9002;</span></a>
				<div class="rating-box">
				  <div style="width: 60%" class="rating">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="73px" height="12px"
					viewBox="0 0 73 12" enable-background="new 0 0 73 12" xml:space="preserve">
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="6.5,0 8,5 13,5 9,7.7 10,12 6.5,9.2 3,12 4,7.7 0,5 5,5"/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="66.5,0 68,5 73,5 69,7.7 70,12 66.5,9.2 63,12 64,7.7 60,5 65,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="21.5,0 23,5 28,5 24,7.7 25,12 21.5,9.2 18,12 19,7.7 15,5 20,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="51.5,0 53,5 58,5 54,7.7 55,12 51.5,9.2 48,12 49,7.7 45,5 50,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="36.5,0 38,5 43,5 39,7.7 40,12 36.5,9.2 33,12 34,7.7 30,5 35,5 "/>
					</svg>
				  </div>
				</div>	
				<div class="clearfix"></div>
				<button class="btn btn-large input-block-level">Buy Now</button>
			  </div>
			</div><!-- .pricing -->
		  </div>
		  <div class="span3">
			<div class="pricing prising-info">
			  <div class="title"><a href="#">Second Package</a></div>
			  <div class="price-box">
				<div class="icon pull-right circle"><i class="icon-android"></i></div>
				<div class="starting">Starting at</div>
				<div class="price">$299<span>/month</span></div>
			  </div>
			  <ul class="options">
				<li><span><i class="fa fa-check"></i></span>Responsive Design</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Color Customization</li>
				<li class="active"><span><i class="fa fa-check"></i></span>HTML5 & CSS3</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Styled elements</li>
				<li><span><i class="fa fa-check"></i></span>Easy Setup</li>
			  </ul>
			  <div class="bottom-box">
				<a href="#" class="more">Read more <span>&#9002;</span></a>
				<div class="rating-box">
				  <div style="width: 80%" class="rating">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="73px" height="12px"
					viewBox="0 0 73 12" enable-background="new 0 0 73 12" xml:space="preserve">
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="6.5,0 8,5 13,5 9,7.7 10,12 6.5,9.2 3,12 4,7.7 0,5 5,5"/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="66.5,0 68,5 73,5 69,7.7 70,12 66.5,9.2 63,12 64,7.7 60,5 65,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="21.5,0 23,5 28,5 24,7.7 25,12 21.5,9.2 18,12 19,7.7 15,5 20,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="51.5,0 53,5 58,5 54,7.7 55,12 51.5,9.2 48,12 49,7.7 45,5 50,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="36.5,0 38,5 43,5 39,7.7 40,12 36.5,9.2 33,12 34,7.7 30,5 35,5 "/>
					</svg>
				  </div>
				</div>
				<div class="clearfix"></div>
				<button class="btn btn-info btn-large input-block-level">Buy Now</button>
			  </div>
			</div><!-- .pricing -->
		  </div>
		  <div class="span3">
			<div class="pricing pricing-success">
			  <div class="title"><a href="#">Third Package</a></div>
			  <div class="price-box">
				<div class="icon pull-right circle"><i class="icon-android"></i></div>
				<div class="starting">Starting at</div>
				<div class="price">$399<span>/month</span></div>
			  </div>
			  <ul class="options">
				<li class="active"><span><i class="fa fa-check"></i></span>Responsive Design</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Color Customization</li>
				<li class="active"><span><i class="fa fa-check"></i></span>HTML5 & CSS3</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Styled elements</li>
				<li><span><i class="fa fa-check"></i></span>Easy Setup</li>
			  </ul>
			  <div class="bottom-box">
				<a href="#" class="more">Read more <span>&#9002;</span></a>
				<div class="rating-box">
				  <div style="width: 80%" class="rating">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="73px" height="12px"
					viewBox="0 0 73 12" enable-background="new 0 0 73 12" xml:space="preserve">
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="6.5,0 8,5 13,5 9,7.7 10,12 6.5,9.2 3,12 4,7.7 0,5 5,5"/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="66.5,0 68,5 73,5 69,7.7 70,12 66.5,9.2 63,12 64,7.7 60,5 65,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="21.5,0 23,5 28,5 24,7.7 25,12 21.5,9.2 18,12 19,7.7 15,5 20,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="51.5,0 53,5 58,5 54,7.7 55,12 51.5,9.2 48,12 49,7.7 45,5 50,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="36.5,0 38,5 43,5 39,7.7 40,12 36.5,9.2 33,12 34,7.7 30,5 35,5 "/>
					</svg>
				  </div>
				</div>
				<div class="clearfix"></div>
				<button class="btn btn-success btn-large input-block-level">Buy Now</button>
			  </div>
			</div><!-- .pricing -->
		  </div>
		  <div class="span3">
			<div class="pricing pricing-error">
			  <div class="title"><a href="#">Fourth Package</a></div>
			  <div class="price-box">
				<div class="icon pull-right circle"><i class="icon-android"></i></div>
				<div class="starting">Starting at</div>
				<div class="price">$499<span>/month</span></div>
			  </div>
			  <ul class="options">
				<li class="active"><span><i class="fa fa-check"></i></span>Responsive Design</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Color Customization</li>
				<li class="active"><span><i class="fa fa-check"></i></span>HTML5 & CSS3</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Styled elements</li>
				<li class="active"><span><i class="fa fa-check"></i></span>Easy Setup</li>
			  </ul>
			  <div class="bottom-box">
				<a href="#" class="more">Read more <span>&#9002;</span></a>
				<div class="rating-box">
				  <div style="width: 100%" class="rating">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="73px" height="12px"
					viewBox="0 0 73 12" enable-background="new 0 0 73 12" xml:space="preserve">
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="6.5,0 8,5 13,5 9,7.7 10,12 6.5,9.2 3,12 4,7.7 0,5 5,5"/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="66.5,0 68,5 73,5 69,7.7 70,12 66.5,9.2 63,12 64,7.7 60,5 65,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="21.5,0 23,5 28,5 24,7.7 25,12 21.5,9.2 18,12 19,7.7 15,5 20,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="51.5,0 53,5 58,5 54,7.7 55,12 51.5,9.2 48,12 49,7.7 45,5 50,5 "/>
					  <polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="36.5,0 38,5 43,5 39,7.7 40,12 36.5,9.2 33,12 34,7.7 30,5 35,5 "/>
					</svg>
				  </div>
				</div>
				<div class="clearfix"></div>
				<button class="btn btn-danger btn-large input-block-level">Buy Now</button>
			  </div>
			</div><!-- .pricing -->
		  </div>
		</div>
	  </div>
	  
	  <div class="full-width-box bottom-padding">
		<div class="bg"><div class="overlay overlay-100 background-green"></div></div>
		<div class="title-box text-center title-white">
		  <h1 class="title">Testimonials</h1>
		</div>
		<div class="respond-carousel">
		  <div class="carousel-box load" data-carousel-pagination="true"  data-carousel-one="true" data-carousel-nav="false">
			<div class="row">
			  <div class="carousel">
				<div class="span12 respond border white">
				  <div class="description">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim ducimus eveniet distinctio amet quaerat maxime fugit nesciunt sunt ut quasi nulla.
				  </div>
				  <div class="name">
					<div class="icon"><i class="fa fa-user"></i></div>
					<strong>Admin</strong>,
					<a href="#" class="no-border">Infostyle</a>
				  </div>
				</div>
				
				<div class="span12 respond border white">
				  <div class="description">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim ducimus eveniet distinctio amet quaerat maxime fugit nesciunt sunt ut quasi nulla.
				  </div>
				  <div class="name">
					<div class="icon"><i class="fa fa-user"></i></div>
					<strong>Admin</strong>,
					<a href="#" class="no-border">Infostyle</a>
				  </div>
				</div>
				
				<div class="span12 respond border white">
				  <div class="description">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim ducimus eveniet distinctio amet quaerat maxime fugit nesciunt sunt ut quasi nulla.
				  </div>
				  <div class="name">
					<div class="icon"><i class="fa fa-user"></i></div>
					<strong>Admin</strong>,
					<a href="#" class="no-border">Infostyle</a>
				  </div>
				</div>
			  </div>
			</div>
			<div class="clearfix"></div>
			<div class="pagination switches"></div>
		  </div>
		</div>
		<div class="clearfix"></div>
	  </div><!-- .full-width-box -->
	  
	  <div class="row">
		<div class="span12 title-box text-center">
		  <h1 class="title">Contacts Us</h1>
		</div>
		
		<div class="span12 map-box">
		  <div class="span6 contact-info" data-appear-animation="fadeInLeftBig">
			<address>
			  <div class="title">Address</div>
			  49 Archdale, 2B Charleston, New York City, USA
			</address>
			<div class="row-fluid">
			  <address class="span6">
				<div class="title">Phones</div>
				<div>Support: +777 (100) 1234</div>
				<div>Sales manager: +777 (100) 4321</div>
				<div>Director: +777 (100) 1243</div>
			  </address>
			  <address class="span6">
				<div class="title">Email Addresses</div>
				<div>Support: <a href="mailto:support@example.com">support@example.com</a></div>
				<div>Sales manager: <a href="mailto:manager@example.com">manager@example.com</a></div>
				<div>Director: <a href="mailto:chief@example.com">chief@example.com</a></div>
			  </address>
			</div>
		  </div>
		  
		  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d423284.5905135276!2d-118.41173249999996!3d34.020498899999986!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7cad08b8c00fa4a!2sForest+Lawn+Memorial+Park+%26+Mortuaries!5e0!3m2!1sen!2s!4v1391611006867" height="500" style="border:0"></iframe>
		</div>
	  </div>
	</article>
  </div>
</section><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="span3 social">
          <h3>Follow Us</h3>
          <p>Follow us in social media</p>
          <a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a>
        </div>
        <div class="span3 newsletter">
          <h3>Newsletter</h3>
          <p>Sign up for newsletter</p>
          <form>
            <input class="input-block-level" type="email">
            <button class="submit"><i class="fa fa-arrow-circle-o-right"></i></button>
          </form>
        </div>
        <div class="span3 nav-box">
          <h3>Information</h3>
		  <nav>
			<ul>
			  <li><a href="#">About us</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">Terms & Condotions</a></li>
			  <li><a href="#">Secure payment</a></li>
			</ul>
		  </nav>
        </div>
        <div class="span3 nav-box">
          <h3>My account</h3>
		  <nav>
			<ul>
			  <li><a href="#">My account</a></li>
			  <li><a href="#">Order History</a></li>
			  <li><a href="#">Wish List</a></li>
			  <li><a href="#">Newsletter</a></li>
			</ul>
		  </nav>
        </div>
      </div>
    </div>
  </div><!-- .footer-top -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="span3 copyright">Copyright &copy; ItemBridge Inc., 2013</div>
        <div class="span3 phone">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#c6c6c6" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			   c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
				M11.001,12H5V2h6V12z"/>
			</svg>
		  </div>
          <strong class="title">Call Us:</strong> +1 (877) 123-45-67 <br>
          <strong>or</strong> +1 (777) 123-45-67
        </div>
        <div class="span3 address">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <g>
				<g>
				  <path fill="#c6c6c6" d="M8,16c-0.256,0-0.512-0.098-0.707-0.293C7.077,15.491,2,10.364,2,6c0-3.309,2.691-6,6-6
					c3.309,0,6,2.691,6,6c0,4.364-5.077,9.491-5.293,9.707C8.512,15.902,8.256,16,8,16z M8,2C5.795,2,4,3.794,4,6
					c0,2.496,2.459,5.799,4,7.536c1.541-1.737,4-5.04,4-7.536C12.001,3.794,10.206,2,8,2z"/>
				</g>
				<g>
				  <circle fill="#c6c6c6" cx="8.001" cy="6" r="2"/>
				</g>
			  </g>
			</svg>
		  </div>
          49 Archdale, 2B Charleston 5655, Excel Tower<br> OPG Rpad, 4538FH
        </div>
        <div class="span3">
          <a href="#" class="up pull-right"><i class="icon-arrow-up icon-white"></i></a>
        </div>
      </div>
    </div>
  </div><!-- .footer-bottom -->
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>