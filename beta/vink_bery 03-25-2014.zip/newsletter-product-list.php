<!DOCTYPE html>
<html>
<head>
  <title>Newsletter Product List \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">
  <link href='http://fonts.googleapis.com/css?family=Arimo:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
</head>
<body style="background-color: #ffffff; color: #1e1e1e; font-family: 'Arimo', sans-serif; font-size: 14px; line-height: 22px; margin: 0; padding: 0;">
  <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; height: 105px;">
    <tr>
      <td style="text-align: left; vertical-align: top; padding-top: 25px;">
        <img src="img/newsletter/logo.png" alt="Logo" style="max-width: 170px;">
      </td>
      <td style="padding: 11px 0; text-align: right; vertical-align: top;">
        <small style="display: block; font-size: 11px; line-height: 16px; margin: 0 0 14px;">Trouble seeing something? <b>View it online</b></small>
        <h1 style="font-size: 18px; font-weight: bold; line-height: 1.3; margin: 0;">Multi-purpose responsive newsletter</h1>
      </td>
    </tr>
  </table>
    
  <div style="background: #f2f2f2; padding: 10px 0;">
    <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; position: relative;">
      <tr>
        <td style="text-align: left; vertical-align: top;">
          <img src="img/newsletter/banner.jpg" alt="Banner" style="max-width: 100%; display: block;">
            <div style="bottom: 0; left: 20px; padding: 28px 20px 20px; position: absolute; right: 20px; top: 100px;">
              <h2 style="background-color: #1e1e1e; background-color: rgba(30,30,30,.8); color: #fff; display: inline-block; font-size: 20px; font-weight: bold; line-height: 24px; margin: 0 0 5px; padding: 2px 5px;">Product List</h2>
              <br>
              <p style="background-color: #1e1e1e; background-color: rgba(30,30,30,.6); color: #fff; display: inline-block; font-size: 12px; line-height: 18px; margin: 0; padding: 1px 3px;">Multi-purpose responsive newsletter</p>
            </div>
        </td>
      </tr>
    </table>
  </div>
  
  <table class="content" width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto; padding: 50px 0;">
    <tr>
      <td style="line-height: 1; padding-right: 15px; width: 180px; text-align: left; vertical-align: top;">
        <a href="#" style="color: #2e5481; text-decoration: none;">
          <img src="img/newsletter/product-1.png" alt="" style="max-width: 100%;">
        </a>
      </td>
      <td style="text-align: left; vertical-align: top;">
        <h3 style="font-size: 20px; font-weight: normal; line-height: 30px; margin: 0 0 10px;">
          <a href="#" style="color: #1e1e1e; text-decoration: none;">Sony Led TV KDL-46HX853</a>
        </h3>
        <p style="color: #7f7f7f; font-size: 12px; line-height: 20px; margin: 0 0 15px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean pretium luctus faucibus. Aenean iaculis ante eu purus rhoncus mattis. Praesent gravida auctor ultricies.</p>
        <div style="font-size: 24px; margin-bottom: 10px;">$1199.00</div>
        <a href="#" style="color: #fff; text-decoration: none; font-size: 10px; padding: 2px 10px; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; display: inline-block;">More</a>
      </td>
    </tr>
    
    <tr>
      <td colspan="2" style="height: 30px; text-align: left; vertical-align: top;">
      </td>
    </tr>
    
    <tr>
      <td style="line-height: 1; padding-right: 15px; width: 180px; text-align: left; vertical-align: top;">
        <a href="#" style="color: #2e5481; text-decoration: none;">
          <img src="img/newsletter/product-2.png" alt="" style="max-width: 100%;">
        </a>
      </td>
      <td style="text-align: left; vertical-align: top;">
        <h3 style="font-size: 20px; font-weight: normal; line-height: 30px; margin: 0 0 10px;">
          <a href="#" style="color: #1e1e1e; text-decoration: none;">Sony Led TV KDL-46HX853</a>
        </h3>
        <p style="color: #7f7f7f; font-size: 12px; line-height: 20px; margin: 0 0 15px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean pretium luctus faucibus. Aenean iaculis ante eu purus rhoncus mattis. Praesent gravida auctor ultricies.</p>
        <div style="font-size: 24px; margin-bottom: 10px;">$1199.00</div>
        <a href="#" style="color: #fff; text-decoration: none; font-size: 10px; padding: 2px 10px; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; display: inline-block;">More</a>
      </td>
    </tr>
    
    <tr>
      <td colspan="2" style="height: 30px; text-align: left; vertical-align: top;">
      </td>
    </tr>
    
    <tr>
      <td style="line-height: 1; padding-right: 15px; width: 180px; text-align: left; vertical-align: top;">
        <a href="#" style="color: #2e5481; text-decoration: none;">
          <img src="img/newsletter/product-3.png" alt="" style="max-width: 100%;">
        </a>
      </td>
      <td style="text-align: left; vertical-align: top;">
        <h3 style="font-size: 20px; font-weight: normal; line-height: 30px; margin: 0 0 10px;">
          <a href="#" style="color: #1e1e1e; text-decoration: none;">Sony Led TV KDL-46HX853</a>
        </h3>
        <p style="color: #7f7f7f; font-size: 12px; line-height: 20px; margin: 0 0 15px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean pretium luctus faucibus. Aenean iaculis ante eu purus rhoncus mattis. Praesent gravida auctor ultricies.</p>
        <div style="font-size: 24px; margin-bottom: 10px;">$1199.00</div>
        <a href="#" style="color: #fff; text-decoration: none; font-size: 10px; padding: 2px 10px; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; display: inline-block;">More</a>
      </td>
    </tr>
    
    <tr>
      <td colspan="2" style="height: 30px; text-align: left; vertical-align: top;">
      </td>
    </tr>
    
    <tr>
      <td style="line-height: 1; padding-right: 15px; width: 180px; text-align: left; vertical-align: top;">
        <a href="#" style="color: #2e5481; text-decoration: none;">
          <img src="img/newsletter/product-4.png" alt="" style="max-width: 100%;">
        </a>
      </td>
      <td style="text-align: left; vertical-align: top;">
        <h3 style="font-size: 20px; font-weight: normal; line-height: 30px; margin: 0 0 10px;">
          <a href="#" style="color: #1e1e1e; text-decoration: none;">Sony Led TV KDL-46HX853</a>
        </h3>
        <p style="color: #7f7f7f; font-size: 12px; line-height: 20px; margin: 0 0 15px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean pretium luctus faucibus. Aenean iaculis ante eu purus rhoncus mattis. Praesent gravida auctor ultricies.</p>
        <div style="font-size: 24px; margin-bottom: 10px;">$1199.00</div>
        <a href="#" style="color: #fff; text-decoration: none; font-size: 10px; padding: 2px 10px; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; display: inline-block;">More</a>
      </td>
    </tr>
    
    <tr>
      <td colspan="2" style="height: 30px; text-align: left; vertical-align: top;">
      </td>
    </tr>
    
    <tr>
      <td style="line-height: 1; padding-right: 15px; width: 180px; text-align: left; vertical-align: top;">
        <a href="#" style="color: #2e5481; text-decoration: none;">
          <img src="img/newsletter/product-5.png" alt="" style="max-width: 100%;">
        </a>
      </td>
      <td style="text-align: left; vertical-align: top;">
        <h3 style="font-size: 20px; font-weight: normal; line-height: 30px; margin: 0 0 10px;">
          <a href="#" style="color: #1e1e1e; text-decoration: none;">Sony Led TV KDL-46HX853</a>
        </h3>
        <p style="color: #7f7f7f; font-size: 12px; line-height: 20px; margin: 0 0 15px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean pretium luctus faucibus. Aenean iaculis ante eu purus rhoncus mattis. Praesent gravida auctor ultricies.</p>
        <div style="font-size: 24px; margin-bottom: 10px;">$1199.00</div>
        <a href="#" style="color: #fff; text-decoration: none; font-size: 10px; padding: 2px 10px; -moz-border-radius: 3px; -webkit-border-radius: 3px; background: #1e1e1e; border: 0 none; border-radius: 3px; display: inline-block;">More</a>
      </td>
    </tr>
  </table>
    
  <div style="background: #f7f7f7; border-top: 1px solid #e1e1e1; color: #7f7f7f; font-size: 11px; line-height: 20px; padding: 20px 0;">
    <table width="644" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
      <tr>
        <td style="text-align: left; vertical-align: top;">
          <span>If you no longer wish to receive emails please <b style="color: #1e1e1e;">unsubscribe</b>.
          <br>Copyright © ItemBridge inc., 2013</span>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #3b57a9; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 46px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/facebook.png" alt="facebook" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #1fb8e7; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/twitter.png" alt="twitter" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #eb6447; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/google.png" alt="google" style="max-width: 100%;">
          </a>
        </td>
        <td style="text-align: right; vertical-align: top; width: 50px;">
          <a href="#" style="background: #2c6bb8; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: block; height: 40px; line-height: 42px; margin: 0 0 0 10px; text-align: center; width: 40px; text-decoration: none;">
            <img src="img/newsletter/in.png" alt="in" style="max-width: 100%;">
          </a>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>