<!DOCTYPE html>
<html>
<head>
  <title>Compare Products \ Progressive — Responsive Multipurpose HTML Template</title>
  <meta class="viewport" name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link href="img/favicon.ico" rel="shortcut icon">

  <link rel='stylesheet' href="css/docs.css">
  <link rel='stylesheet' href="css/buttons/social-icons.css">
  <link rel='stylesheet' href="css/buttons/animation.css">
  <link rel='stylesheet' href="css/font-awesome.min.css">
  <link rel='stylesheet' href="css/bootstrap.min.css">
  <link rel='stylesheet' href="css/jslider.css">
  <link rel='stylesheet' href="css/settings.css">
  <link rel='stylesheet' href="css/jquery.fancybox.css">
  <link rel='stylesheet' href="css/animate.css">
  <link rel='stylesheet' href="css/video-js.css">
  <link rel='stylesheet' href="css/morris.css">
  <link rel='stylesheet' href="css/style.css">
  <link rel='stylesheet' href="css/responsive.css">
  <link rel='stylesheet' href="css/pages.css">
    
  <style>
	#top-box,
	.carousel-box .next:hover,
	.carousel-box .prev:hover,
	.product .product-hover,
	#footer .up:hover,
    .btn,
    .btn:visited,
    .slider .slider-nav,
    .active .accordion-heading .accordion-toggle,
    .banner-set .pagination a:hover,
    .employee .employee-hover,
    .carousel-box .pagination a:hover,
    .sidebar .menu li.active > a,
    .pagination ul > li > a:hover,
    .sidebar .tags a:hover,
    .sidebar .banners .banner-text,
    #catalog .category-img .description,
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrapper,
    .product-bottom .related-products header:before,
    #slider.rs-slider .tparrows:hover,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .toolbar .grid-list a.grid:hover,
    .toolbar .grid-list a.list:hover,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a,
    .sidebar .menu li.parent > a .open-sub:before,
    .sidebar .menu li.parent > a .open-sub:after,
    .accordion-heading .accordion-toggle:before,
    .accordion-heading .accordion-toggle:after,
    .new-radio.checked span,
	.list .product .actions a:hover,
	.product-page .span7 .actions a:hover,
	.product-page .image-box .thumblist-box .prev:hover,
	.product-page .image-box .thumblist-box .next:hover,
    .btn.btn-inverse:hover,
    .btn.btn-inverse:focus,
    .btn.btn-inverse:active,
    .btn.btn-inverse.active,
    .btn.btn-inverse.disabled,
    .btn.btn-inverse[disabled],
	.accordion-tab > li > a .open-sub:before,
	.accordion-tab > li > a .open-sub:after,
	.products-tab .accordion-tab > li > a .open-sub:before,
	.products-tab .accordion-tab > li > a .open-sub:after {
	  background-color: #40499b;
	}
    .slider .slider-nav {
      background-color: rgba(64,73,155,.97);
    }
    .county-days-wrapper,
    .county-hours-wrapper,
    .county-minutes-wrapper,
    .county-seconds-wrappe,
	.product .product-hover,
	.rotation .employee-hover {
      background-color: rgba(64,73,155,.9);
    }
    .btn:hover,
    .btn:focus,
    .btn:active,
    .btn.active,
    .btn.disabled,
    .btn[disabled] {
      background-color: #40499b;
      background-color: rgba(64,73,155,.8);
    }
    #catalog .category-img .description,
    .toolbar .sort-catalog .dropdown-toggle,
    .toolbar .grid-list .grid,
    .toolbar .grid-list .list,
    .toolbar .up-down,
    .toolbar .up-down.active,
    .pagination ul > .active > a,
    .pagination ul > .active > span,
    .sidebar .tags a {
      background-color: rgba(64,73,155,.7);
    }
    .sidebar .banners .banner-text {
      background-color: rgba(64,73,155,.65);
    }
    #slider.rs-slider .tparrows,
	.product-page .add-cart-form .number .regulator a:hover {
      background-color: rgba(64,73,155,.5);
    }
	.pricing .bottom-box {
	  background-color: rgba(64,73,155,.05);
	}
	.pricing {
	  background-color: rgba(64,73,155,.06);
	}
	.pricing .options li,
	.pricing .bottom-box {
	  border-color: rgba(64,73,155,.1);
	}
	.header .cart-header .dropdown-toggle,
	#footer .newsletter input:focus + .submit,
    .icon,
    .big-icon,
    .big-icon:visited,
    .service .icon,
    .close:hover,
    .close:focus,
    .img-thumbnail:hover .bg-images i:before,
    .box-404 h1,
    .gallery-images:hover .bg-images i:before,
    .features-block .header-box .icon-box,
    .features-block .header-box,
    .sidebar .newsletter input:focus + .submit,
	.sidebar .section .selected .close:hover,
    .package .title a,
    .package .price-box .price,
    .package .price-box .icon,
    .pricing .title a,
    .pricing .options li span,
	.pricing .options li.active {
	  color: #40499b;
	}
	.pricing .bottom-box .more {
	  color: rgba(64,73,155,.7);
	}
	.pricing .options li {
	  color: rgba(64,73,155,.4);
	}
	.phone-header a svg path,
	.search-header a svg path,
	.product .actions a svg path,
    .product-remove:hover path,
    .sidebar .wishlist .add-cart:hover path,
    .header .cart-header .dropdown-toggle .icon svg path,
    .search-active .search-submit svg path,
    .new-checkbox svg polygon,
	.product-bottom .related-products li .button-box .wishlist:hover svg path,
	.jslider .jslider-pointer svg path,
	.rating-box .rating svg polygon {
	  fill: #40499b;
	}
    .carousel-box .pagination a.selected,
    .banner-set .pagination a.selected {
      background: #ccc;
	  background: rgba(0,0,0,.3);
    }
	@media (max-width: 979px) {
	  .header .primary .navbar .nav > .parent.active > a,
	  .header .primary .navbar .nav > .parent.active:hover > a,
	  .header .primary .navbar .nav .open-sub span,
	  .header .primary .navbar .btn-navbar .icon-bar,
	  .header.header-two .primary .navbar .btn-navbar.collapsed .icon-bar,
	  .accordion-tab > .active > a,
	  .accordion-tab > .active:hover > a,
	  .products-tab .accordion-tab > .active > a,
	  .products-tab .accordion-tab > .active:hover > a {
		background-color: #40499b;
	  }
	}
	.navbar-inverse .brand,
	.navbar-inverse .nav > li > a,
	.btn-group.btn-select .dropdown-toggle,
	.product .product-hover,
	.employee .employee-hover,
	.slider .slid-content{
	  color: #fff;
	}
	.product .product-hover ul li {
	  background-image: url("img/svg/check-icon-white.svg"), none;
	}
  </style>
  
  <!--[if IE]>
	<link rel='stylesheet' href="css/ie/ie.css">
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

  <!--[if IE 9 ]>
    <link rel='stylesheet' href="css/ie/ie9.css">
  <![endif]-->
</head>
<body class="fixed-header hidden-top">
<div class="page-box">
<div class="page-box-content">
  
<div id="top-box">
  <div class="container">
    <div class="pull-left">
      <div class="btn-group language btn-select">
		<a class="btn dropdown-toggle" role="button" data-toggle="dropdown" href="#">
		  <span class="desktop">Language</span><span class="tablet">Lang</span>: English
		  <span class="caret"></span>
		</a>
		<ul class="dropdown-menu">
		  <li><a href="#"><img src="img/eng-flag.png" alt="">English</a></li>
		  <li><a href="#"><img src="img/fra-flag.png" alt="">France</a></li>
		  <li><a href="#"><img src="img/ger-flag.png" alt="">Germany</a></li>
		</ul>
	  </div>

	  <div class="btn-group currency btn-select">
		<a class="btn dropdown-toggle" role="button" data-toggle="dropdown" href="#">
		  <span class="desktop">Currency</span><span class="tablet">Curr</span>: USD
		  <span class="caret"></span>
		</a>
		<ul class="dropdown-menu">
		  <li><a href="#">USD</a></li>
		  <li><a href="#">EUR</a></li>
		  <li><a href="#">GBP</a></li>
		</ul>
      </div>
    </div>
    
    <div class="my-account navbar navbar-inverse pull-right">
      <div class="navbar-inner">
		<nav>
		  <ul class="nav">
			<li><a href="#">My account</a></li>
			<li><a href="#">My Wishlist</a></li>
			<li><a href="#">Checkout</a></li>
			<li><a href="#">Log in</a></li>
		  </ul>
		</nav>
      </div>
    </div><!-- .my-account -->
  </div>
</div><!-- #top-box -->

<?php include 'header.php'; ?>

<div class="breadcrumb-box breadcrumb-none"></div>

<div class="banner-set banner-set-mini load">
  <div class="container">
	<a class="prev" href="#"><i class="icon-arrow-left"></i></a>
	
	<div class="banners">
	  <a href="#" class="banner">
		<img src="img/content/banner1.jpg" width="253" height="158" alt="">
		<h2 class="title">Home Theater</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner2.jpg" width="253" height="158" alt="">
		<h2 class="title">Multiroom</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner3.jpg" width="253" height="158" alt="">
		<h2 class="title">Lighting Control</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner4.jpg" width="253" height="158" alt="">
		<h2 class="title">Amazing Sound</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner5.jpg" width="253" height="158" alt="">
		<h2 class="title">Home Theater</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner6.jpg" width="253" height="158" alt="">
		<h2 class="title">Multiroom</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner7.jpg" width="253" height="158" alt="">
		<h2 class="title">Lighting Control</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner8.jpg" width="253" height="158" alt="">
		<h2 class="title">Amazing Sound</h2>
	  </a>
	  <a href="#" class="banner">
		<img src="img/content/banner5.jpg" width="253" height="158" alt="">
		<h2 class="title">Home Theater</h2>
	  </a>
	</div><!-- .banners -->
	
	<a class="next" href="#"><i class="icon-arrow-right"></i></a>
	<div class="clearfix"></div>
  </div>
</div><!-- .banner-set -->

<div id="main" class="page">
  <header class="page-header">
    <div class="container">
      <h1 class="title">Compare Products</h1>
    </div>	
  </header>
  <div class="container">
    <div class="row">
      <article class="content span12">
		<div class="table-box">
		  <table id="compare-table" class="table table-bordered">
			<thead>
			  <tr class="remove">
				<td></td>
				<td>
				  <a href="#" class="product-remove">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
						<path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
						<path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
						c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
						H5V2z M12,14H4V5h8V14z"/>
					  </g>
					</svg>
				  </a><!-- .product-remove -->
				</td>
				<td>
				  <a href="#" class="product-remove">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
						<path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
						<path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
						c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
						H5V2z M12,14H4V5h8V14z"/>
					  </g>
					</svg>
				  </a><!-- .product-remove -->
				</td>
				<td>
				  <a href="#" class="product-remove">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
						<path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
						<path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
						c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
						H5V2z M12,14H4V5h8V14z"/>
					  </g>
					</svg>
				  </a><!-- .product-remove -->
				</td>
			  </tr>
			  <tr>
				<th class="first">Product Name</th>
				<th><a href="product-view.html" class="product-name">Dolor sit amet consectetur adipiscing elit</a></th>
				<th><a href="product-view.html" class="product-name">Fusce interdum posuere quam eget fringilla pharetra</a></th>
				<th><a href="product-view.html" class="product-name">Phasellus malesuada bibendum sapien id rhoncus</a></th>
			  </tr>
			</thead>
			<tbody>
			  <tr class="images">
				<td class="first"><strong>Image</strong></td>
				<td>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-1.png" alt="" title="" width="90" height="90">
				  </a>
				</td>
				<td>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-2.png" alt="" title="" width="90" height="90">
				  </a>
				</td>
				<td>
				  <a href="product-view.html" class="product-image">
					<img src="img/content/product-3.png" alt="" title="" width="90" height="90">
				  </a>
				</td>
			  </tr>
			  <tr>
				<td class="first"><strong>Price</strong></td>
				<td>
				  <div class="price-old">$750.00</div>
				  <div class="price">$750.00</div>
				</td>
				<td>
				  <div class="price-old">$750.00</div>
				  <div class="price">$750.00</div>
				</td>
				<td>
				  <div class="price-old">$750.00</div>
				  <div class="price">$750.00</div>
				</td>
			  </tr>
			  <tr>
				<td class="first"><strong>Model</strong></td>
				<td>Dolor sit amet consectetur adipiscing elit</td>
				<td>Fusce interdum posuere quam eget fringilla pharetra</td>
				<td>Phasellus malesuada bibendum sapien id rhoncus</td>
			  </tr>
			  <tr>
				<td class="first"><strong>Brand</strong></td>
				<td>One</td>
				<td>Two</td>
				<td>Three</td>
			  </tr>
			  <tr>
				<td class="first"><strong>Availbility</strong></td>
				<td>In Stock</td>
				<td>In Stock</td>
				<td>In Stock</td>
			  </tr>
			  <tr>
				<td class="first"><strong>Rating</strong></td>
				<td>
				  <div class="rating-box">
					<div style="width: 80%" class="rating">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="73px" height="12px"
					  viewBox="0 0 73 12" enable-background="new 0 0 73 12" xml:space="preserve">
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="6.5,0 8,5 13,5 9,7.7 10,12 6.5,9.2 3,12 4,7.7 0,5 5,5"/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="66.5,0 68,5 73,5 69,7.7 70,12 66.5,9.2 63,12 64,7.7 60,5 65,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="21.5,0 23,5 28,5 24,7.7 25,12 21.5,9.2 18,12 19,7.7 15,5 20,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="51.5,0 53,5 58,5 54,7.7 55,12 51.5,9.2 48,12 49,7.7 45,5 50,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="36.5,0 38,5 43,5 39,7.7 40,12 36.5,9.2 33,12 34,7.7 30,5 35,5 "/>
					  </svg>
					</div>
				  </div>
				</td>
				<td>
				  <div style="width: 100%" class="rating">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="73px" height="12px"
					  viewBox="0 0 73 12" enable-background="new 0 0 73 12" xml:space="preserve">
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="6.5,0 8,5 13,5 9,7.7 10,12 6.5,9.2 3,12 4,7.7 0,5 5,5"/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="66.5,0 68,5 73,5 69,7.7 70,12 66.5,9.2 63,12 64,7.7 60,5 65,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="21.5,0 23,5 28,5 24,7.7 25,12 21.5,9.2 18,12 19,7.7 15,5 20,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="51.5,0 53,5 58,5 54,7.7 55,12 51.5,9.2 48,12 49,7.7 45,5 50,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="36.5,0 38,5 43,5 39,7.7 40,12 36.5,9.2 33,12 34,7.7 30,5 35,5 "/>
					  </svg>
					</div>
				</td>
				<td>
				  <div style="width: 100%" class="rating">
					  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="73px" height="12px"
					  viewBox="0 0 73 12" enable-background="new 0 0 73 12" xml:space="preserve">
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="6.5,0 8,5 13,5 9,7.7 10,12 6.5,9.2 3,12 4,7.7 0,5 5,5"/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="66.5,0 68,5 73,5 69,7.7 70,12 66.5,9.2 63,12 64,7.7 60,5 65,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="21.5,0 23,5 28,5 24,7.7 25,12 21.5,9.2 18,12 19,7.7 15,5 20,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="51.5,0 53,5 58,5 54,7.7 55,12 51.5,9.2 48,12 49,7.7 45,5 50,5 "/>
						<polygon fill-rule="evenodd" clip-rule="evenodd" fill="#1e1e1e" points="36.5,0 38,5 43,5 39,7.7 40,12 36.5,9.2 33,12 34,7.7 30,5 35,5 "/>
					  </svg>
					</div>
				</td>
			  </tr>
			  <tr class="description">
				<td class="first"><strong>Description</strong></td>
				<td>
				  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pharetra faucibus congue. Aenean luctus dolor et purus malesuada luctus. Quisque ullamcorper ante viverra lectus fermentum quis rutrum erat sollicitudin. Fusce tortor massa.</p>
				  <p>Cras ullamcorper nisl non odio congue accumsan. Class aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
				</td>
				<td>
				  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pharetra faucibus congue. Aenean luctus dolor et purus malesuada luctus. Quisque ullamcorper ante viverra lectus fermentum quis rutrum erat sollicitudin. Fusce tortor massa.</p>
				  <p>Cras ullamcorper nisl non odio congue accumsan. Class aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
				</td>
				<td>
				  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pharetra faucibus congue. Aenean luctus dolor et purus malesuada luctus. Quisque ullamcorper ante viverra lectus fermentum quis rutrum erat sollicitudin. Fusce tortor massa.</p>
				  <p>Cras ullamcorper nisl non odio congue accumsan. Class aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
				</td>
			  </tr>
			  <tr>
				<td></td>
				<td><button class="btn">Add to Cart</button></td>
				<td><button class="btn">Add to Cart</button></td>
				<td><button class="btn">Add to Cart</button></td>
			  </tr>
			  <tr class="remove remove-bottom">
				<td></td>
				<td>
				  <a href="#" class="product-remove">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
						<path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
						<path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
						c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
						H5V2z M12,14H4V5h8V14z"/>
					  </g>
					</svg>
				  </a><!-- .product-remove -->
				</td>
				<td>
				  <a href="#" class="product-remove">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
						<path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
						<path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
						c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
						H5V2z M12,14H4V5h8V14z"/>
					  </g>
					</svg>
				  </a><!-- .product-remove -->
				</td>
				<td>
				  <a href="#" class="product-remove">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
					width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
					  <g>
						<path fill="#7f7f7f" d="M6,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S5,6.447,5,7v5C5,12.553,5.447,13,6,13z"/>
						<path fill="#7f7f7f" d="M10,13c0.553,0,1-0.447,1-1V7c0-0.553-0.447-1-1-1S9,6.447,9,7v5C9,12.553,9.447,13,10,13z"/>
						<path fill="#7f7f7f" d="M14,3h-1V1c0-0.552-0.447-1-1-1H4C3.448,0,3,0.448,3,1v2H2C1.447,3,1,3.447,1,4s0.447,1,1,1
						c0,0.273,0,8.727,0,9c0,1.104,0.896,2,2,2h8c1.104,0,2-0.896,2-2c0-0.273,0-8.727,0-9c0.553,0,1-0.447,1-1S14.553,3,14,3z M5,2h6v1
						H5V2z M12,14H4V5h8V14z"/>
					  </g>
					</svg>
				  </a><!-- .product-remove -->
				</td>
			  </tr>
			</tbody>
		  </table><!-- #compare-table -->
		</div>
      </article><!-- .content -->
    </div>
  </div>
</div><!-- #main -->

</div><!-- .page-box -->
</div><!-- .page-box-content -->

<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="span3 social">
          <h3>Follow Us</h3>
          <p>Follow us in social media</p>
          <a class="sbtnf sbtnf-rounded color color-hover icon-facebook" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-twitter" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-gplus" href="#"></a>
          <a class="sbtnf sbtnf-rounded color color-hover icon-linkedin" href="#"></a>
        </div>
        <div class="span3 newsletter">
          <h3>Newsletter</h3>
          <p>Sign up for newsletter</p>
          <form>
            <input class="input-block-level" type="email">
            <button class="submit"><i class="fa fa-arrow-circle-o-right"></i></button>
          </form>
        </div>
        <div class="span3 nav-box">
          <h3>Information</h3>
		  <nav>
			<ul>
			  <li><a href="#">About us</a></li>
			  <li><a href="#">Privacy Policy</a></li>
			  <li><a href="#">Terms & Condotions</a></li>
			  <li><a href="#">Secure payment</a></li>
			</ul>
		  </nav>
        </div>
        <div class="span3 nav-box">
          <h3>My account</h3>
		  <nav>
			<ul>
			  <li><a href="#">My account</a></li>
			  <li><a href="#">Order History</a></li>
			  <li><a href="#">Wish List</a></li>
			  <li><a href="#">Newsletter</a></li>
			</ul>
		  </nav>
        </div>
      </div>
    </div>
  </div><!-- .footer-top -->
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="span3 copyright">Copyright &copy; ItemBridge Inc., 2013</div>
        <div class="span3 phone">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#c6c6c6" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			  c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
			  M11.001,12H5V2h6V12z"/>
			</svg>
		  </div>
          <strong class="title">Call Us:</strong> +1 (877) 123-45-67 <br>
          <strong>or</strong> +1 (777) 123-45-67
        </div>
        <div class="span3 address">
          <div class="footer-icon">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			  width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <g>
				<g>
				  <path fill="#c6c6c6" d="M8,16c-0.256,0-0.512-0.098-0.707-0.293C7.077,15.491,2,10.364,2,6c0-3.309,2.691-6,6-6
				  c3.309,0,6,2.691,6,6c0,4.364-5.077,9.491-5.293,9.707C8.512,15.902,8.256,16,8,16z M8,2C5.795,2,4,3.794,4,6
				  c0,2.496,2.459,5.799,4,7.536c1.541-1.737,4-5.04,4-7.536C12.001,3.794,10.206,2,8,2z"/>
				</g>
				<g>
				  <circle fill="#c6c6c6" cx="8.001" cy="6" r="2"/>
				</g>
			  </g>
			</svg>
		  </div>
          49 Archdale, 2B Charleston 5655, Excel Tower<br> OPG Rpad, 4538FH
        </div>
        <div class="span3">
          <a href="#" class="up pull-right"><i class="icon-arrow-up icon-white"></i></a>
        </div>
      </div>
    </div>
  </div><!-- .footer-bottom -->
</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.0.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/price-regulator/jshashtable-2.1_src.js"></script>
<script src="js/price-regulator/jquery.numberformatter-1.2.3.js"></script>
<script src="js/price-regulator/tmpl.js"></script>
<script src="js/price-regulator/jquery.dependClass-0.1.js"></script>
<script src="js/price-regulator/draggable-0.1.js"></script>
<script src="js/price-regulator/jquery.slider.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.touchSwipe.min.js"></script>
<script src="js/jquery.elevateZoom-2.5.5.min.js"></script>
<script src="js/jquery.imagesloaded.min.js"></script>
<script src="js/jquery.themepunch.plugins.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/jquery.sparkline.min.js"></script>
<script src="js/jquery.easy-pie-chart.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.knob.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/country.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael.min.js"></script>
<script src="js/video.js"></script>
<script src="js/selectBox.js"></script>
<script src="js/blur.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>