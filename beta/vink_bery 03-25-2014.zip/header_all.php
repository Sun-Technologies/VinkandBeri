<header class="header header-two">
  <div class="container">
	<div class="row">
	  <div class="span3 logo-box">
		<a href="index.php" class="logo">
		  <img src="img/logo.svg" class="logo-img" alt="">
		</a>
	  </div>
	  <div class="span7 primary">
		<div class="navbar">
		  <a class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".primary .nav-collapse">
			<span class="text">Menu</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		  </a>
		  <nav class="nav-collapse collapse">
			<ul class="nav">
			  <li class="parent">
				<a href="index.php">Home</a>
				<!--<ul class="sub">
				  <li><a href="index.php">Creative</a></li>
				  <li><a href="home-2.php">Paralax</a></li>
				  <li><a href="home-3.php">Simple</a></li>
				  <li><a href="home-4.php">Business</a></li>
				</ul>-->
			  </li>
			  <li class="parent">
				<a href="#">About</a>
				<ul class="sub">
				  <li><a href="sidebar-blocks.php">All sidebar blocks</a></li>
				  <li><a href="full-width.php">Full Width</a></li>
				  <li><a href="left-sidebar.php">Left Sidebar</a></li>
				  <li><a href="right-sidebar.php">Right Sidebar</a></li>
				  <li><a href="about-us.php">About Us</a></li>
				  <li><a href="contact.php">Contact Us</a></li>
				  <li><a href="blog-list.php">Blog List</a></li>
				  <li><a href="blog-view.php">Blog Post View</a></li>
				  <li><a href="404.php">Page 404</a></li>
				  <li><a href="404-2.php">Page 404 (2)</a></li>
				  <li class="parent">
					<a href="#">Portfolio</a>
					<ul class="sub">
					  <li><a href="portfolio-1.php">Portfolio (1 column)</a></li>
					  <li><a href="portfolio-2.php">Portfolio (2 column)</a></li>
					  <li><a href="portfolio-3.php">Portfolio (3 column)</a></li>
					  <li><a href="portfolio-4.php">Portfolio (4 column)</a></li>
					  <li><a href="portfolio-slider.php">Portfolio (Slider)</a></li>
					  <li><a href="portfolio-single.php">Single Project</a></li>
					</ul>
				  </li>
				  <li><a href="gallery-modern.php">Modern Gallery</a></li>
				  <li class="parent">
					<a href="#">Gallery</a>
					<ul class="sub">
					  <li><a href="gallery-1.php">Gallery (1 column)</a></li>
					  <li><a href="gallery-2.php">Gallery (2 column)</a></li>
					  <li><a href="gallery-3.php">Gallery (3 column)</a></li>
					  <li><a href="gallery-4.php">Gallery (4 column)</a></li>
					</ul>
				  </li>
				  <li><a href="pricing.php">Pricing</a></li>
				  <li><a href="team.php">Team</a></li>
				  <li><a href="faq.php">FAQ</a></li>
				  <li><a href="services.php">Services</a></li>
				  <li><a href="careers.php">Careers</a></li>
				  <li><a href="coming-soon.php">Coming Soon</a></li>
				  <li><a href="under-construction.php">Under Construction</a></li>
				  <li><a href="sitemap.php">Sitemap</a></li>
				  <li class="parent">
					<a href="#">Newsletter</a>
					<ul class="sub">
					  <li><a href="newsletter-big-intro.php">Newsletter Big Intro</a></li>
					  <li><a href="newsletter-big-portfolio.php">Newsletter Big Portfolio</a></li>
					  <li><a href="newsletter-columns.php">Newsletter Columns</a></li>
					  <li><a href="newsletter-info.php">Newsletter Info</a></li>
					  <li><a href="newsletter-plan.php">Newsletter Plan</a></li>
					  <li><a href="newsletter-portfolio.php">Newsletter Portfolio</a></li>
					  <li><a href="newsletter-product-list.php">Newsletter Product List</a></li>
					  <li><a href="newsletter-story.php">Newsletter Story</a></li>
					</ul>
				  </li>
				</ul>
			  </li>
			  <li class="parent">
				<a href="shop.php">Products</a>
				<ul class="sub">
				  <li><a href="ALOR_aloevera_juice.php">ALOR Aloe Vera Juice</a></li>
				  <li><a href="catalog-grid.php">ALOR Aloe Vera Chunks</a></li>
				  <li><a href="catalog-grid.php">ALOR Aloe Vera Coconut Water</a></li>
				  <li><a href="catalog-grid.php">ALOR Coconut Water with Coconut Chunks</a></li>
				  <!--<li><a href="catalog-list.php">Catalog (List)</a></li>
				  <li><a href="product-view.php">Product View</a></li>
				  <li><a href="product-view-variants.php">Product View (Variants)</a></li>
				  <li><a href="cart.php">Shopping Cart</a></li>
				  <li><a href="checkout.php">Proceed to Checkout</a></li>
				  <li><a href="compare.php">Compare Products</a></li>
				  <li><a href="login.php">Login</a></li>-->
				</ul>
			  </li>
			  <li class="parent megamenu">
				<a href="Social_Care.php">Social Care</a>
				<!--<ul class="sub">
				  <li class="promo-block box">
					<a href="#" class="big-image">
					  <img src="img/content/megamenu-big.png" width="240" height="434" alt="">
					</a>
				  </li>
				  
				  <li class="box first">
					<h6 class="title">Savant Apple Integration</h6>
					<ul>
					  <li><a href="#">iPad, iPod touch, iPhone & Mac Control</a></li>
					  <li><a href="#">iPod touch Remote Control</a></li>
					  <li><a href="#">Savant Host (Mac Mini)</a></li>
					</ul>
				  </li>
				  <li class="box">
					<h6 class="title">Savant Audio/Video Control</h6>
					<ul>
					  <li><a href="#">Distributed Audio & Video</a></li>
					  <li><a href="#">Matrix Switchers</a></li>
					  <li><a href="#">Audio/Video Processing</a></li>
					</ul>
				  </li>
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li>
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li>
				  <li class="box first">
					<h6 class="title">Savant Display Solutions</h6>
					<ul>
					  <li><a href="#">Video Tiling</a></li>
					  <li><a href="#">On-Screen Display</a></li>
					  <li><a href="#">Digital Messaging</a></li>
					</ul>
				  </li>
				  <li class="box">
					<h6 class="title">Savant Sound</h6>
					<ul>
					  <li><a href="#">Distributed Audio Controller</a></li>
					  <li><a href="#">Multi-channel Amplifiers</a></li>
					  <li><a href="#">Architectural Speakers</a></li>
					</ul>
				  </li>
				</ul> -->
			  </li>
			  <li class="parent">
				<a href="careers.php">Career</a>
				<!--<ul class="sub">
				  <li><a href="elements-accordions.php">Accordions &amp; Toggles</a></li>
				  <li><a href="elements-animations.php">Animations</a></li>
				  <li><a href="elements-buttons.php">Buttons &amp; Social Icons</a></li>
				  <li><a href="elements-carousel.php">Carousels &amp; Sliders</a></li>
				  <li><a href="elements-charts.php">Charts</a></li>
				  <li><a href="elements-container.php">Container</a></li>
				  <li><a href="elements-content-band.php">Content Band</a></li>
				  <li><a href="elements-dividers.php">Dividers & Gaps</a></li>
				  <li><a href="elements-featured-box.php">Featured Box</a></li>
				  <li><a href="elements-icons.php">Font Awesome Icons</a></li>
				  <li><a href="elements-frames.php">Frames</a></li>
				  <li><a href="elements-maps.php">Google Maps</a></li>
				  <li><a href="elements-media.php">Media</a></li>
				  <li><a href="elements-notification.php">Notification</a></li>
				  <li><a href="elements-person.php">Person</a></li>
				  <li><a href="elements-post-sliders.php">Posts Sliders</a></li>
				  <li><a href="elements-pricing.php">Pricing and Data Tables</a></li>
				  <li><a href="elements-sliders.php">Premium Sliders</a></li>
				  <li><a href="elements-progress-bar.php">Progress Bars</a></li>
				  <li><a href="elements-recent-posts.php">Recent Posts</a></li>
				  <li><a href="elements-shop.php">Shop Elements</a></li>
				  <li><a href="elements-tabs.php">Tabs</a></li>
				  <li><a href="elements-testimonials.php">Testimonials</a></li>
				  <li><a href="elements-works.php">Works</a></li>
				</ul>-->
			  </li>
			  <li class="parent">
				<a href="contact.php">Contact</a>
				<!--<ul class="sub">
				  <li><a href="typography-styles.php">Typography</a></li>
				  <li><a href="tables-styles.php">Tables</a></li>
				  <li><a href="forms-styles.php">Forms</a></li>
				  <li><a href="buttons-styles.php">Buttons</a></li>
				  <li><a href="tabs-styles.php">Tabs</a></li>
				  <li><a href="tooltips-styles.php">Tooltip</a></li>
				  <li><a href="accordions-styles.php">Accordions</a></li>
				</ul>-->
			  </li>
			  <li class="parent">
				<a href="#">Blog</a>
			  </li>
			</ul>
		  </nav>
		</div>
	  </div><!-- .primary -->
	  
	  <!--<div class="span3">
		<div class="phone-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
			width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M11.001,0H5C3.896,0,3,0.896,3,2c0,0.273,0,11.727,0,12c0,1.104,0.896,2,2,2h6c1.104,0,2-0.896,2-2
			  c0-0.273,0-11.727,0-12C13.001,0.896,12.105,0,11.001,0z M8,15c-0.552,0-1-0.447-1-1s0.448-1,1-1s1,0.447,1,1S8.553,15,8,15z
			  M11.001,12H5V2h6V12z"/>
			</svg>
		  </a>
		</div><!-- .phone-header -->
		
		<!--<div class="search-header">
		  <a href="#">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </a>
		</div><!-- .search-header 
	  </div>-->
	  
	  <div class="phone-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<span class="title">Call Us</span> <strong>+1 (777) 123 45 67</strong>
	  </div>
	  <div class="search-active span9">
		<a href="#" class="close"><span>close</span>&#215;</a>
		<form name="search-form">
		  <input class="search-string" type="search" placeholder="Search here" name="search-string">
		  <button class="search-submit">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" enable-background="new 0 0 16 16" xml:space="preserve">
			  <path fill="#231F20" d="M12.001,10l-0.5,0.5l-0.79-0.79c0.806-1.021,1.29-2.308,1.29-3.71c0-3.313-2.687-6-6-6C2.687,0,0,2.687,0,6
			  s2.687,6,6,6c1.402,0,2.688-0.484,3.71-1.29l0.79,0.79l-0.5,0.5l4,4l2-2L12.001,10z M6,10c-2.206,0-4-1.794-4-4s1.794-4,4-4
			  s4,1.794,4,4S8.206,10,6,10z"/>
			</svg>
		  </button>
		</form>
	  </div>
	</div><!--.row -->
  </div>
</header><!-- .header -->